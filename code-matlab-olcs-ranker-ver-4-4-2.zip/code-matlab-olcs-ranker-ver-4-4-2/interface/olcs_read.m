function  olcs_read(varargin)
% read data from a text or Excel file
%
% Inputs:
%    varargin{2*i-1}: a string, the parameter name;
%    varargin{2*i}: the parameter value of varargin{2*i-1}; for i=1, 2, ...
%    the optional arguments are as follows:
%      '-l': a sting, delimiter of the data fields of text data file
%      '-p': a string indicating the leading prefix of the protein fields
%        of a decoy PSM,  default 'Reverse';   
%        i.e., if PSM  with the protein field begining with the given
%        prefix, then it is labeled -1 (decoy PSM),  otherwise it is
%        labeled as a  1 (target PSM);  
%        This parameter is effective if no label feature exists in the data
%        file.
%      '-w':  a positive integer, indexing the title row; default value 1; 
%      '-e': 1 or 0, indicating whether employ the feature enzN and enzC;
%           default 1;
%      '-n': 1 or 0, indicating whether employ the feature numProt; 
%           default 1;
%      '-v':  0, 2 or 3
%        0: do not print any information to command window;       
%        2: put out progress information briefly to command window;
%        3: put out detailed progress information to command window;
%  
%   The last two inputs:
%
%   dataFile: name of text or Excel file containing the data of PSMs;
%
%   matDataFile: file name of mat data file which contains the
%       following  DATA and TEXT struct.
%     data: a structure containing the numeric data:
%         data.input: a matrix, with each column the values of a feature;
%           besides the data of columns of the data file, it also appends
%           certain calculated features; 
%         data.input_feature: a string cell array(row array), with the i-th
%           element  the feature name of the i-th column of the matrix
%           DATA.INPUT;  
%         data.output: the column vector of the labels; 1: decoy; -1: target
%     text: a structure containing the data of strings.


persistent argHash

[par_new,varargin_par ] = identifyPar(varargin{:});

arg = struct();
len_arg = length(par_new); 
if len_arg>0
    arg = assignStruct('', par_new(1:2:len_arg),par_new(2:2:len_arg));
end

% verify and set path
if isfield(arg,'path_user_data')    
    if ~isdir(arg.path_user_data)
        error('The dictionary %s is not a folder.',arg.path_user_data);
    end
    arg.path_cranker_data = arg.path_user_data;
      %path_cranker_data: path to store data files of canker
    path_user_data = arg.path_user_data;
    path_cranker_data = arg.path_cranker_data;
    userSetting('path_user_data',path_user_data,'path_cranker_data',path_cranker_data);
        % this setting effects all the following commands, including
        %   olcs_solve(), olcs_write(), etc. 
else  % if user has not set the path, use the default path
    [path_cranker_data, path_user_data] = ...
        problemArg('path_cranker_data','path_user_data');
end

% get dataFile and matDataFile
if length(varargin_par)<2
    error('There should be 2 inputs variables: dataFile and matDataFile.');
end
dataFile = varargin_par{1};
matDataFile = varargin_par{2};

% reset dataFile
[pathstr_user, name] = fileparts(dataFile);
if isempty(pathstr_user) % there is no file path contained in the dataFile name
	dataFile = [addFileSep(path_user_data)  dataFile];
end
% check whether the data file exist
if ~exist(dataFile,'file')
	error('OLCS-Ranker do not find the data file: %s',dataFile);
end

 % get verbose
if isfield(arg,'verbose')
    verbose = arg.verbose;
else
    verbose = problemArg('verbose');
end

% read and save original data contained in the data file
if verbose>=2
    fprintf(1,'Reading PSM records from %s...\n',dataFile);
end
if ~exist(path_cranker_data,'dir')
    flag_mkdir = 1;
    try
        mkdir(path_cranker_data);
    catch
        flag_mkdir = 0; % failed to make the dir
    end
    if ~flag_mkdir
        if verbose>0
            warning(sprintf('Not succeed to make the directory: %s',...
                path_cranker_data));
            fprintf(1,'The directory of the dataFile is reset at current path.\n');
        end
        path_cranker_data = '.';
    end
end
% reset matDataFile
[pathstr_mat, name, ext] = fileparts(matDataFile);
if isempty(pathstr_mat)
    if ~isempty(path_cranker_data)
        matDataFile = [addFileSep(path_cranker_data)  name '.mat'];
    else
        matDataFile = [ name '.mat'];
    end
else
    matDataFile = [ addFileSep(pathstr_mat)  name '.mat'];
end
if ~strcmp(ext,'.mat')
    if verbose>0
        warning('The output data file has been changed to mat file: %s',matDataFile);
    end
end

alg = 'MD5'; 
if isempty(argHash) 
    argHash.file_str = hash_file(dataFile,alg);
    argHash.arg_str  = hash_struct(arg,alg);
    argHash.matFile_str = hash_file(matDataFile,alg); 
else 
    argHash2.file_str = hash_file(dataFile,alg);
    argHash2.arg_str  = hash_struct(arg,alg);
    argHash2.matFile_str = hash_file(matDataFile,alg);
    if strcmp(argHash2.file_str,argHash.file_str) && strcmp(argHash2.arg_str,argHash.arg_str) && strcmp(argHash2.matFile_str,argHash.matFile_str)...
         && exist(matDataFile,'file') % the matDataFile has exist and not need to be read the data again 
        if verbose>=1
            fprintf(1,'The existed data file %s has been found, and not read the data from %s again. \n',matDataFile,dataFile);            
        end        
        return
    end 
end

    [data,text] = readData(dataFile,arg);

% check the obtained data
if isempty(data.input)
    error('No numeric feature values read from the data file.');
end
if nnz(isnan(data.input))>0 % exist NaN in data.input
    error('Exist NaN in the input ');
end
if isempty(data.output)|| nnz(data.output==-1)==0
    [feature_name_protein,feature_name_label,decoyPrefix] = ...
        problemArg('feature_name_protein','feature_name_label','decoyPrefix');  
    
    str = sprintf('Check the spell of protein feature, which should be named ``%s''',feature_name_protein);
    str = [str sprintf('or add a feature ''%s'' made up by 1 (target PSM) and -1 (decoy PSM)',feature_name_label)];
 
    str0 = 'Could not identify target or decoy PSM records.';
    if ~isempty(data.output) % nnz(data.output==-1)==0
        str1 = 'No decoy PSMs (with label -1) is identified. ';
        str1 = [str1 'Correctly specify the prefix of the decoy proteins  by ''-p'' parameter,'];
        str1 = [str1 sprintf('default value: ''%s''',decoyPrefix)];
        str1 = [str1 'If a PSM has the protein field beginning with the given prefix, then it is labeled as'
                '-1 (false PSM), otherwise it is labeled as 1 (target PSM)'];
        error('%s %s', str1);
    else % isempty(data.output)
        error('%s %s',str0, str);
    end    
end
nnz_label_illegal = length(data.output)-nnz(abs(data.output)==1);
if  nnz(data.output==-1)>0 && nnz_label_illegal>0
    str = 'The labels should be made up by 1 (indicating target PSM) and -1 (decoy PSM). ';
    str1 = sprintf('All the remain %d label values are revised as 1 (target PSM).',nnz_label_illegal);
    warning([str str1]);
    data.output(abs(data.output)~=1)=1;
end

save(matDataFile,'data','text'); % save the read data

% append the calculated numeric features
addFeature(matDataFile,matDataFile,0,arg);

% update the hash 
    argHash.file_str = hash_file(dataFile,alg);
    argHash.arg_str  = hash_struct(arg,alg);
    argHash.matFile_str = hash_file(matDataFile,alg); 

if verbose>=1
    load(matDataFile,'data');
    fprintf('There are %d features: ',length(data.input_feature));
    fprintf('%s\t',data.input_feature{:});
    fprintf('\n');
end
    
if verbose>=1
   % fprintf(1,'Finished to read PSM records and append new features.\n');
    fprintf(1,'PSM records: total:%d\ttarget:%d\t decoy:%d \n',...
        length(data.output),nnz(data.output==1),nnz(data.output==-1));
end
    
end
