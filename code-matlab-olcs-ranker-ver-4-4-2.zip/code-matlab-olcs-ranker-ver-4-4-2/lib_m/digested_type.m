function [flag]= digested_type(peptide_str)
% identify the type of the given peptide (full, half or non-digested)
% Inputs:
% peptide_str: the character array of the given peptide, e.g.
%      'K.HSLAESIQNAGILQSYWENEIPQKR.S'
%       |                         |
%       |                         |
%      (N terminal:tryptic)  (C terminal:tryptic)
%     hence, this is a full digested peptide.
% Outputs:
% flag: 2: the given peptide is full digested;
%       1: the given peptide is half digested;
%       0: the given peptide is non digested;
% Note:
%  full digested peptide: both N and C terminus are K and R residues;
%  half digested peptide: only either N terminus or C terminal is K or R
%        residue;
%  non digested peptide: neither K nor R at both terminus

peptide_str = strtrim(peptide_str);
char_split = '.'; % character to split the peptide array
p_array = strfind(peptide_str,char_split);

% get the first and the last position of the char_split
len_p_array = length(p_array);
p_l = 0; p_r = 0;
if len_p_array==1
    p = p_array(1);
    if p==2
        p_l = p;
    elseif p==length(peptide_str)-1
        p_r = p;
    end
elseif len_p_array>=2
    p_l = p_array(1);
    p_r = p_array(len_p_array);
end
% get the C and N terminal residues
N_residue = '';
C_residue = '';
if p_l>1
    N_residue = peptide_str(p_l-1);
end
if p_r>1 %&& p_r<length(peptide_str)  
    C_residue = peptide_str(p_r-1);
end

% identify the peptide style
flag = 0;
if strcmpi(N_residue, 'K') || strcmpi(N_residue, 'R')
    flag = flag + 1;
end    

if strcmpi(C_residue,'K') ||strcmpi(C_residue,'R')
    flag = flag + 1;    
end

end

