function score = phi_fx(fx)
    persistent coef_score;
    if isempty(coef_score)
        coef_score = problemArg('coef_score');
    end
    score= (2/pi)*sign(fx).*atan(coef_score*abs(fx));   
end