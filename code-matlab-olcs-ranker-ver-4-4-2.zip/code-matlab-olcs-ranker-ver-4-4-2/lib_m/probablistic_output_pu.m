function prob_v  = probablistic_output_pu(fx_v,label_v,flag_pos_correct)
% Inputs:
%   fx_v: a vector of discriminant function values, fx_v(i): = f(x_i) 
%   label_v: a vector of labels consisting of +1 and -1
%   flag_pos_correct: whether the positive labels (+1) are correct 
%       1: positive labels are correct
%       0: negative labels are correct
% Outputs:
%   prob_v: probability that P( y_i = +1|x_i) 

% P(y=1|x) = 1/ (1+ exp( Af(x)+B)), with B=0;

verbose = 2; % 0, 1, or 2

max_act_sample = 20000; % maximum number of discriminant function values used to calculate the optimal value of A

n_sample = numel(fx_v);

fx_v = columnVec(fx_v);
label_v = columnVec(label_v);

% 0.1 check the size of fx_v and label_v 
if  n_sample ~= length(label_v) 
    error('fx_v and lable_v should have the common size.');
end   

% 0.2 check whether all the labels are +1 or -1
if nnz(label_v ==1) + nnz(label_v==-1) ~= n_sample
    error( ' The labels label_v should consist of +1 or -1.');
end


% 1. calculate the optimal value of A 

 % select part of discriminant function values with correct label
 if flag_pos_correct
    ind_act = find(label_v == 1);    
 else
    ind_act = find(label_v == -1);
 end
 n_act = nnz(ind_act);

 % check whether there exists negative discriminant function values if flag_pos_correct==1
    % or there exists positive discriminant function values if flag_pos_correct== -1
if flag_pos_correct   
    ind_sv =  find(fx_v(ind_act)<0);
    ind_non_sv = find(fx_v(ind_act)>=0);
else
    ind_sv =  find(fx_v(ind_act)>0);
    ind_non_sv = find(fx_v(ind_act)<=0);
end
ind_sv = ind_act(ind_sv);
ind_non_sv = ind_act(ind_non_sv);

n_sv = length(ind_sv);
n_non_sv = length(ind_non_sv);

ratio_sv = n_sv/n_act; % ratios of SVs
 
if n_act <=max_act_sample
    ind_act_select = ind_act;
else
    n_sv_select = ceil(ratio_sv * max_act_sample);
    n_non_sv_select = min(max_act_sample - n_sv_select,n_non_sv); 
    
    % select part of sv and non-svs
    ind_sv_select = [];
    if n_sv>0
        p = randperm(n_sv,n_sv_select);
        ind_sv_select = ind_sv(p);
    end
    ind_non_sv_select = [];
    if n_non_sv>0        
        p = randperm(n_non_sv,n_non_sv_select);
        ind_non_sv_select = ind_non_sv(p);
    end
    ind_act_select = [ind_sv_select; ind_non_sv_select];
end
 
 % solve the optimal value of A 
 if n_sv ==0
     if flag_pos_correct
         A_opt = -1;
     else
         A_opt = 1;
     end
     exitflag = 10;
 else     
     A_min = -5;
     A_max = 5;     
     exp_fx_select = exp(fx_v(ind_act_select));
     [A_opt, fA_opt,exitflag]  = fminbnd(@log_likelihood,A_min,A_max);
 end

    function fA = log_likelihood(A)
        % fA = sum_i log(1+exp(A fx_i), with i in ind_act_select        
            fA = sum(log(exp_fx_select.^A+1));
    end

if verbose>=2
    fprintf(1,'A_opt: %.3f\t,exitflag: %d\n',A_opt,exitflag);
end

% 2. put out the probability of P(y_i=1 | x=x_i)
    B_opt = 0;
    prob_v  = 1./ (1+ exp( A_opt*fx_v+B_opt));
    if ~flag_pos_correct
        prob_v = 1-prob_v;
    end
end