function [par_new, output_var_c] = identifyPar(varargin)
% identify the values of specified parameters
% Inputs:
%  varargin: a string cell array including the parameters and input
%     varialbes, in the following format:
%     {parameterName1}, {parameterValue1}, {parameterName2}, {parameterValue2}, ...
%     {parameterNameN}, {parameterValueN}, {variable1}, ..., {variableM}
%   all the parameter names, values and variables are strings;
%   parameter names (parameterName1, ..., parameterNameN) are started by
%     '-', e.g.,  '-v', '-cdecoy', '-ctarget', '-ctarget'
%   all  parameter names are case-insensitive 
% Outputs:
%   par_new: a cell array, contains the pairs of parameter names and
%      values;
%   output_var_c: a  cell array, including {variable1},...,{varialbeN}
% Usage:
%   [par_new output_var_c] = identifyPar( '-v', '2', '-cdecoy','1.0', 'data.txt' )
%
% version information:
%   2018.9.8 revision to support non-string input parameter; 


debug_mode = 0;

par_new = {};
 

input_var_c  = varargin(:);
output_var_c = {};


% % % check the validity of input_var_c
% % % if ~iscellstr(input_var_c)
% % %     error('All the inputs should be strings.');
% % % end
% % % ischar_v = cellfun(@ischar,input_var_c,'UniformOutput',1);
% % % p = find(~ischar_v,1);
% % % if p>0
% % %     input_var_c = input_var_c(1:p-1); % neglect the remaining non-string inputs    
% % % end

if isempty(input_var_c)  
    return;
end
flag_empty_vars = 0; % whether no variables (only input parameter names and values)  

f = @(x) double( ischar(x) & strncmp('-',x,1));
flag_v = cellfun(f,input_var_c,'UniformOutput',1);

n_input = length(input_var_c);
ind = 1:2:n_input;

id_name = find(flag_v(ind)==0,1,'first'); 
  % find the first odd index that not started with '-'

err_str1 = ['The parameters should be set as the format:' ...
 '''parName1''  ''parValue1'' ... ''parNameN'' ''parValueN'' variable1 ... variableN.'];
err_str2 = 'A parameter name is indicated by beginning with ''-''.';
if isempty(id_name) % all the odd index are started with '-'
    if mod(n_input,2)==1 % n_input is odd
        err_str0 = 'The last input should not be a variable name.';
        error('%s%s',err_str0,err_str1);
    else % n_input is even
        flag_empty_vars = 1; 
        id_name = n_input + 1; 
    end
else
    id_name = ind(id_name); 
    % update id_name: the first odd index of input_var_c that not started with '-'
end


   % check whether the even (2, 4, ..., id_name-1) elements of input_var_c
   %   started with '-' 
if id_name>1   
    ind = 2:2:id_name;
    id = find(flag_v(ind),1,'first');   
        % the first even elements of input_var_c not started with '-'
    if ~isempty(id)
        id = ind(id)-1; 
        str_id = ordinal_str(id);
        error('A parameter value should be followed after the parameter name ''%s'' (%s input).',...
            input_var_c{id}, str_id);
    end
end

   % check whether the remaining (even) inputs contains parameter names
if id_name < n_input 
    % if id_name==n_input, since id_name is odd integer, no need to check
    ind = id_name:n_input;
    id = find(flag_v(ind),1,'first');
    if ~isempty(id) 
        error('%s%s',err_str1,err_str2);
    end
end


% check and set the values of specified parameters
%   Note that all parameter names should use lower characters here
par_c = { ... 
    'path_user_data',   '-path',   'string';
    'delimiter',        '-l',      'string';
    'decoyPrefix',      '-p',      'string';
    'titleRow',         '-w',      'integer';
    'flag_enz',          '-e',      'integer'; %%%
    'flag_numProt',      '-n',      'integer'; %%%
 %%%   'flag_xcorrR',       '-o',      'integer'; %%%
    'train_test_rate',  '-t',      'float';
    'fdr',              '-fdr',    'float';
    'verbose',          '-v',      'integer';
    'cdecoy',               '-cdecoy',     'float';
    'ctarget',               '-ctarget',     'float';
    'cp',               '-cp',     'float';
    'cu',               '-cu',     'float';    
    'lambda'            '-lambda'  'float'; % added
    'classPrior'        '-pi'      'float'; % added
    'svm_theta_solver'   '-s'        'string'; % added    
    'n_initial_cardinality_S',  '-Sinitial'     'float'; % added
    'mu_safe'           '-musafe' 'float' ; % added
    'mu_safetarget'     '-musafetarget'  'float' ; % added
     'mu_pos'           '-mupos' 'float' ; % added
    'mu_neg'     '-muneg'  'float' ; % added
    'tol_violating_pair_initial' '-tauinitial' 'float'; % added
    'tol_violating_pair_min'    '-taumin'       'float'; % added    
    'fix_train_test_set' '-fixtraintestset' 'integer'; % added
    'fix_train_order'   '-fixtrainorder'    'integer'; % added
    'tolFun_foapl'    '-tolfun'  'float'; % added    
    'r1',               '-r',      'float';
    'flag_split_train_test', '-f', 'integer';
    'flag_standardize', '-g',      'integer';
    'maxTrainSize_cv',     '-z',      'float';   %  the maximum number of samples used for cross validation;   
    'fold_k',           '-k'       'integer';       %  value of k for k-fold cross validation
    'num_submodel',     '-m',      'float';
    'weight_xcorr',     '-x ',     'float'}; 
    % parameter names, bias and its attribute

par_name_c = strtrim(lower(input_var_c(1:2:id_name-1))); % parameter bias    
par_name_caseSensitive_c = strtrim(input_var_c(1:2:id_name-1)); % parameter bias

%par_val_c  = strtrim_ex(input_var_c(2:2:id_name-1),'"'''); % parameter values
par_val_c  =  input_var_c(2:2:id_name-1) ; % parameter values

% remove the leading and trailing characters: '"'' '
for ii=1:length(par_val_c)
    if ischar(par_val_c{ii})
        par_val_c{ii} = strtrim_ex(par_val_c{ii},'"'' ');
    end
end
     
if debug_mode
     fwritef(1,'par_val_c',par_val_c,'','par_name_c',par_name_c,'');
end
     
   % check the existence of parameter bias
[v,id_p] = ismember(par_name_c,par_c(:,2));
ind = find(v==0);
if ~isempty(ind)    
    switch length(ind)
        case 1
            str0 = par_name_caseSensitive_c{ind}; 
        case 2
            str0 = [par_name_caseSensitive_c{ind(1)} ', ' par_name_caseSensitive_c{ind(2)}];     
        otherwise
            str0 = par_name_caseSensitive_c{ind(1)};
            for ii=2:length(ind)
                str0 = [str0 ', ' par_name_caseSensitive_c{ind(ii)}];
            end            
    end
    error('There is no parameter %s for setting. Check the usage.',str0);
end

   % check the validity of parameter attributes and transform the values
for ii=1:length(par_val_c)
    attrib = par_c{id_p(ii),3};
    if strcmpi(par_val_c{ii},'inf') % deal with the value of Inf
        par_val_c{ii} = Inf;
    elseif strcmp(attrib,'integer')
        flag = is_integer_or_integerstr(par_val_c{ii});
        if  ~flag
            error('The parameter value of %s should be integer.',par_name_caseSensitive_c{ii});
        end
        if flag ==2            
            par_val_c{ii} = round(str2double(par_val_c{ii})); % convert to integer 
        end
    elseif strcmp(attrib,'float')
        if ~isnumber(par_val_c{ii}) 
            error('The parameter value of %s should be a number.',par_name_caseSensitive_c{ii});
        end
        if ischar(par_val_c{ii})
            par_val_c{ii} = str2double(par_val_c{ii}); % convert to a float number
        end
    end
end

% set the parameter values 
par_new = cell(id_name-1,1);
par_new(1:2:id_name-1) = par_c(id_p,1);
par_new(2:2:id_name-1) = columnVec(par_val_c);
% % % userSetting(par_new);

if debug_mode
     fwritef(1,'par_new',par_new,'');
end

% outputs
if ~flag_empty_vars
    %output_var_c = input_var_c(id_name:n_input);
    output_var_c = varargin(id_name:nargin);
end

end

function flag = is_integer_or_integerstr(t)
% wheter t is an integer or a char of integers (eg. '702')
% output:
%  flag: 0:  t is not an interger and not a char of integers
%        1:  t is an integer
%        2:  t is string of integers   
flag = 0;
if ischar(t)
    if isinteger_str(t)
        flag =2;
    end
else
    if isnumeric(t)
        flag = abs(t-int32(t))<1e-15;
    end
end        
end

 