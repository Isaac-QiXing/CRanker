function [num_ensemble,num_rbf,num_linear] = cranker_ensemble(matTrainFile,matTestFile,matScoreFile,par_cranker,arg)
% ensemble linear and nonlinear classifiers for peptide identification
%  Inputs:
%   matTrainFile, and testFile: name of file (with extension .mat) which
%       consists of the training samples and test samples, refer to the
%       outputs of cranker_split() for details of the variables therein
%   matScoreFile: name of file  (with extension .mat) which contains the calculated
%       scores and trained model;
%  par_cranker: a struct indicating the cranker model and algorithm parameters
%       used for generating base classifiers
%   the struct includes the following fields:
%        .cdecoy:     weight of empirical loss of the decoys
%        .ctarget_cdecoy_ratio:  ratio of ctarget to cdecoy
%        .lambda_ctarget_ratio:  ratio of lambda to ctarget
%       .r1_linear: kernel parameter r1 for linear kernel, set []
%           if do not employ  linear classifiers for ensembling
%       .r1_rbf: kernel parameter r1 for rbf kernel, set []
%           if do not employ rbf-kernel-based  classifiers for ensembling
%       .lambda_mode_rbf: optional, mode to iterate lambda with rbf kernel, 'Fix' or 'SPL'
%           default 'Fix';
%       .n_ite_lambda_rbf: optional, number of iterated lambda values, effective only if
%           par_cranker.lambda_mode_rbf ='SPL', default value 1;
%           it is required that
%              'n_ite_lambda_rbf' and 'n_ite_lambda_rbf' should be a string
%              and a scalar number, resp.
%
%       Note that
%       (1) each field the first 5 fields of par_cranker is a scalar number  or a string  for .lambda_mode_rbf
%
%       (2) for linear kernel, .lambda_mode would be set 'Fix'
%
%        Then the number of linear classifiers are
%      length(arg.k_fold_linear)*length(cdecoy)*length(ctarget_cdecoy_ratio)...
%           *length(lambda_ctarget_ratio)*length(r1_linear)
%       the number of nonlinear classifiers are similar as above
%           expect that the number of k-fold is  length(arg.k_fold_nonlinear), and number of searched r1 values
%           are length(r1_nonlinear),
%       the total number of base classifiers =
%               number of linear classifiers + number of nonlinear classifiers
%
%   arg: struct of parameters
%       .k_fold_linear: optional, positiver integer, number of linear learners,
%          default value 3;
%       .k_fold_rbf: optional, positiver integer, number of nonlinear learners,
%          default value 3;
%       .maxTrainSize, optional, a positive integer,  maximum number of samples used for cross validation,
%           default 5000;
%       .fdr_v: optional, a vector of fdr levels to caculate the number of TPs and FPs
%           default [0.01];
%       .verbose: optional, 0 or 1; default 1;
% Outputs:
%   num_ensemble: struct array of size n_set-by-n_method-by-n_FDR, consisting number of TP, FPs
%       with n_set =3 (train, test, total), n_method = 2 (mean, median), n_FDR = length(arg.fdr_v)
%   num_linear: struct array of size n_set-by-n_method-by-n_FDR, consisting number of TP, FPs
%       with n_set = 3, n_method = arg.k_fold_linear,
%   num_rbf: struct array of size n_set-by-n_method-by-n_FDR, consisting number of TP, FPs
%       with n_set = 3, n_method = arg.k_fold_rbf;
%
% Operation:
%
%   save(matScoreFile,'score_linear','score_rbf', 'ind_train','ind_test', 'model','acc','num');
%       model: a struct array of length n_par (number of  parameters to search for both linear kernel and nonlinear kernel)
%           with the fields
%           'alpha', 'ind', 'b', 'r1', 'kernelType', 'w'
%        model(i).alpha is a n_subtrain-by-k_fold matrix, with n_subtain the  number of PSMs to train base classifier,
%                  k_fold the number, each column is a solution vector of  base submodel by cross validation
%        model(i).ind   a matrix with the same size as model.alpha
%        model(i).b    a vector with length k_fold, the intersept of each base  classifier
%        model(i).r1   a scalar, the kernel parameter
%        model(i).kernelType  a string, indicating the kernel function
%        model(i).w:  a vector of feature weights
%          for i=1,... n_par
% version
%   2018.10.20.
%       * ensemble the q-values of PSMs by base predictors
%       * exclude the bad base predictors


%    ------------ Future Version ----
%      each field the first 5 fields of par_cranker could be  set as
%           a vector or string cell array for .lambda_mode_rbf
%   ---------------------------------

debug_mode = 0; %1; %0;

arg = completeArg(arg,{'n_linear','n_nonlinear','maxTrainSize','fdr_v','verbose'},{3,3,5000,0.01,1});
par_cranker = completeArg(par_cranker,{'lambda_mode_rbf','n_ite_lambda_rbf'},{'Fix',1});

% 0. set parameters

[r1_linear,r1_rbf] = getArgument(par_cranker,{'r1_linear','r1_rbf'});

% 0.1 set par_alg_linear and par_alg_rbf
par_alg_linear = struct('kernelType',  'linear', 'lambda_mode',  'Fix',...
    'n_ite_lambda',1);
par_alg_rbf = struct('kernelType',  'rbf', 'lambda_mode',   par_cranker.lambda_mode_rbf,...
    'n_ite_lambda',par_cranker.n_ite_lambda_rbf);

% 0.2 set par_search
ratio_base = [0 1 0 2];
% ratio_base(4)==2: the 4-th field (lambda) is setting based on the ratio to 2nd field (ctarget)
par_search_linear = struct( 'cdecoy',par_cranker.cdecoy,...
    'ctarget', par_cranker.ctarget_cdecoy_ratio,...        % ratios of ctarget to  cdecoy
    'r1', r1_linear,...
    'lambda', par_cranker.lambda_ctarget_ratio,...
    'ratio_base',ratio_base);

par_search_rbf = par_search_linear;
par_search_rbf.r1 = r1_rbf;

% 0.3 set alg and h_bestResult
alg = @cranker_predict;
h_bestResult = @findBestResult; % in fact, we do not need  to find  bestResut

% 0.4 get ind_train and ind_test
trainData = load(matTrainFile, 'ind','y');
testData = load(matTestFile, 'ind','y');
ind_train = trainData.ind;
ind_test  = testData.ind;
n_train_total = length(ind_train);
n_test_total = length(ind_test);
y_total = zeros(n_train_total+n_test_total,1);
y_total(ind_train) = trainData.y;
y_total(ind_test) = testData.y;

% 1.1 train the linear models
if ~isempty(r1_linear)
    [~,~,ite_linear_c]= crossValidate(alg,matTrainFile, par_alg_linear, par_search_linear,...
        'k',arg.k_fold_linear,'n',arg.maxTrainSize,'bestResult',h_bestResult,'flag_equal_fold_size',1,'flag_excel',0,...
        'verbose',arg.verbose,'flag_mat',0);
end
%1.2 train the nonlinear models use the   commen training set
if ~isempty(r1_rbf)
    [~,~,ite_rbf_c]= crossValidate(alg,matTrainFile, par_alg_rbf, par_search_rbf,...
        'k',arg.k_fold_rbf,'n',arg.maxTrainSize,'bestResult',h_bestResult,'flag_equal_fold_size',1,'flag_excel',0,...
        'verbose',arg.verbose,'flag_mat',0);
end


% 1.3 calcualte the scores of PSMs in matTrainFile (only part of them used for cross validation)
%    and in matTestFile
ite_linear_c = cellfun(@cal_train_score,ite_linear_c,'uniformOutput',false);
ite_rbf_c = cellfun(@cal_train_score,ite_rbf_c,'uniformOutput',false);



    function ite2_s = cal_train_score(ite_s)
        % calculate the scores of PSMs in matTrainFile
        % ite_s is the struct of the iterated models, parameters, ...
        ite2_s = ite_s;
        % assign the model
        model0.alpha =  ite_s.model.alpha(:,end);
        model0.b  =     ite_s.model.b(end);
        % in 'SPL' mode, the trained model may put out a serious of solutions with various lambda value
        model0.ind = columnVec(ite_s.index_train_cv);  % note that ind must be a column vector
        % assign the parameters
        arg_cal_score.trainFile = matTrainFile;
        arg_cal_score.testFile = matTestFile;
        arg_cal_score.kernelType = ite_s.arg.kernelType;
        arg_cal_score.r1 = ite_s.arg.r1;
        arg_cal_score.w = ite_s.arg.w;
        arg_cal_score.flagOutput = 'train_test';
        % put the calculated scores of PSMs in matTrainFile and matTestFile to
        %      ite2_s.score_train_total
        % and  ite2_s.score_test_total,   resp.
        % % % % %        %%% save('temp2.mat','model0','arg_cal_score','ite_s');
        [ite2_s.score_train_total,ite2_s.score_test_total]= calulate_score(model0,arg_cal_score);
    end

% 1.4 the trained sub-models and  scores

score_train_linear = [];
if ~isempty(r1_linear)
    [model_linear,Score_linear] = transform_ite_2_struct(ite_linear_c);
end
score_train_rbf = [];
if ~isempty(r1_rbf)
    [model_rbf,Score_rbf] = transform_ite_2_struct(ite_rbf_c);
end

% model_linear and model_rbf   struct of trained model
%   .alpha  a matrix with each column a solution vector of a base model
%   .ind: same size as model_linear.alpha, the indices of PSMs
%   .b:   a row vector with length the number of base  models  the intercept of each base model


% 3. ensemble the scores
% calculate q-values
q_value_linear = cal_q_value(Score_linear,y_total);
q_value_rbf = cal_q_value(Score_rbf,y_total);
if debug_mode
    save('temp20181020.mat','q_value_linear','q_value_rbf');
end
%Score_ensemble = ensemble_score(Score_linear,Score_rbf);
%q_value_ensemble = ensemble_score(q_value_linear,q_value_rbf);
q_value_ensemble = ensemble_q_value(q_value_linear,q_value_rbf); % exclude the ``bad'' predicted q_values, and ensemble the remain q-values
Score_ensemble = 1-q_value_ensemble;

% 4. calculate the accuracies
digestIndex = [];
arg_acc.fdr = arg.fdr_v;  %% [0.01, 0.05];
arg_acc.index = {ind_train,ind_test};
[acc_ensemble,num_ensemble] = accuracyIndex(Score_ensemble,y_total,digestIndex,arg_acc);
[acc_linear,num_linear] = accuracyIndex(Score_linear,y_total,digestIndex,arg_acc);
[acc_rbf,num_rbf]       = accuracyIndex(Score_rbf,y_total,digestIndex,arg_acc);

% 4 save scores,  models, parameters and accuracies to matScoreFile
save(matScoreFile,'Score_linear', 'Score_rbf','Score_ensemble',...
    'acc_linear','acc_rbf','acc_ensemble',...
    'num_linear','num_rbf','num_ensemble',...
    'ind_train','ind_test', 'model_linear','model_rbf');


    function [model0_s,Score_m] = transform_ite_2_struct(ite_c)
        % transform a cell of iterated information to struct
        %   each cell includes a struct wit the fields:
        %         'score_train','score_test',  'ind_train','ind_test','weight','arg','model','timestamp'
        %         'score_train_total', 'score_test_total'
        % Score_m: matrix of scores
        
        Score_m = [];
        [n_par_search,k_fold] = size(ite_c);
        %  -----------    Caveat     -----------------
        %  current version only support n_par_search == 1
        %  -----------------------------------------
        if n_par_search~=1
            error('current version only support n_par_search == 1.');
        end
        
        %%for i_par = n_par_search:-1:1
        i_par = 1;
        for i_fold =k_fold:-1:1
            %ind = sub2ind(size(ite_c), i_par,i_fold);
            ind = i_fold;
            % cononstruct model0_s
            index_train_cv = columnVec(ite_c{i_par,i_fold}.index_train_cv );
            %         index_test_cv = columnVec(ite_c{i_par,i_fold}.index_test_cv );
            model0_s.alpha(:,ind) = columnVec(ite_c{i_par,i_fold}.model.alpha(:,end));
            model0_s.b(1,ind) =     ite_c{i_par,i_fold}.model.b(end);
            % in 'SPL' mode, the trained model may put out a serious of
            % solutions with various lambda value
            
            % model0_s.ind(:,ind)   =  columnVec(ite_c{i_par,i_fold}.ind_train   );   % NOT correct
            model0_s.ind(:,ind) = index_train_cv;
            model0_s.trainFile = matTrainFile;  % model0_s.ind based on PSMs in matTrainFile
            % note that
            %    model0_s.ind is the the indices of the training samples
            %    (to produce the ``model'') in the samples of X,y of
            %    matTrainFile
            %    (rather than the indices of orginal data set)
            % initialize Score_m
            if i_par==n_par_search && i_fold==k_fold
                Score_m = zeros(n_train_total + n_test_total, k_fold);
            end
            % assigning to Score_m
            Score_m(ind_train,ind) = columnVec(ite_c{i_par,i_fold}.score_train_total );
            Score_m(ind_test,ind) = columnVec(ite_c{i_par,i_fold}.score_test_total );
        end
    end % end function of transform_ite_2_struct


end % end function of cranker_ensemble


function  Score_ensemble = ensemble_score(Score_linear,Score_rbf)
% Score_linear, Score_rbf: matrices of scores with same number of rows (n_psm rows)
%       each column is a score vector of the PSMs
%   Outputs:
%    Score_ensemble:  a n_psm-by-2 matrix of scores

n_psm = size(Score_linear,1);
Score_ensemble = zeros(n_psm,2);
Score_ensemble(:,1) = mean([Score_linear Score_rbf],2);
Score_ensemble(:,2) = median([Score_linear Score_rbf],2);
end

function  Score_ensemble = ensemble_q_value(q_value_linear,q_value_rbf)
%   Outputs:
%    Score_ensemble:  a n_psm-by-2 matrix of scores

fdr_threshold = 0.01;
n_psm = size(q_value_linear,1);
Score_ensemble = zeros(n_psm,2);

% exclude the bad classifiers
%    TP numbers under fdr = 0.01
q_value_m = [q_value_linear,q_value_rbf];
n_classifier = size(q_value_m,2);
TP_v = zeros(1,n_classifier);
for ii=1:n_classifier
    i_TP = find(q_value_m(:,ii)<=fdr_threshold,1,'last');
    if ~isempty(i_TP)
        TP_v(ii) = i_TP;
    end
end
isoutlier_v    = isoutlier(TP_v);
ind_col = find(~isoutlier_v);


%     Score_ensemble(:,1) = mean([Score_linear Score_rbf],2);
%     Score_ensemble(:,2) = median([Score_linear Score_rbf],2);
Score_ensemble(:,1) = mean(q_value_m(:,ind_col),2);
Score_ensemble(:,2) = median(q_value_m(:,ind_col),2);
end