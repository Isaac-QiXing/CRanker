function score = sigmoid_scale(fx)
    score=  2/(1+exp(-fx))-1;   
end