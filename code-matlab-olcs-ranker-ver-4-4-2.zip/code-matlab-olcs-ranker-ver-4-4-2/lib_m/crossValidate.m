function [result_opt,par_opt,varargout]= crossValidate(alg,matTrainFile, par_alg, par_search,varargin)
% a general algorithm of cross validation to choose a good group of parameter values
% Inputs:
%  alg:  function handle indicating the  algorithm object
%      The algorithm has the format
%       [result_test,varargout] = alg(matTrainFile,matTestFile, par_alg)
%      matTrainFile, matTestFile: mat file name for traing and test,
%       it contain  the same data variables;
%      par_alg: a struct of algorithm  parameters
%      result_test: a struct of the predicted results on test sets
%          Each field  of result_test is a numeric scalar.
%      varargout{1} of alg(): optional, a truct, the iterated information of alg            ,
%           all the iterated inforamtion of the submodels in cross
%           validation would be putout in varargout{1} of crossValidate()
%           Besides the struct has the following two fields:
%              .index_train_cv: indices of samples in matTrainFile used for training 
%              .index_validate_cv:  indices of samples in matTrainFile used for validation
%  matTrainFile: mat file name containing the  training data
%  par_alg:  a struct indicating the  parameters of function ALG;
%       note that the   parameter  that contained in PAR_SEARCH do
%       not take effects.
%  par_search:  a struct indicating the parameters to determine the numerical values by   cross validation
%       the algorithm test all the combinations of the parameters in   default;
%       par_search has a build-in field named 'ratio_base' to set parameter
%       values by multiplying a specified ratio of another parameter
%       par_search.ratio_base is a vector of length == number of parameters to search;
%
%       The values of par_search should be a numeric vector.
%
%      Support at most 2 ratio bases in currect version;
%
%    E.g.
%       par_search = struct( 'cdecoy',[   1  2  3 ],...
%           'ctarget', [ 0.2 0.5],...        % ratios of ctarget to  cdecoy
%           'r1',[  2  6],...
%           'ratio_base',[0 1 0]);
%       then the 1st parameter cdecoy, do not apply 'ratio_base', as  par_search.ratio_base(1) =0;
%       the parameter values of cdecoy are [1,2,3];
%       the 2nd paramter ctarget,  has ratio_base: 1, as par_search.ratio_base(2) =1;
%        indicating the parameter values of ctarget for grid search  are set as
%        the  values of 1st parameter * specified ratios, i.e.,
%
%        when cdecoy=1,  then ctarget = cdecoy*[0.2 0.5] = [0.2 0.5];
%        when cdecoy=2,   then ctarget = cdecoy*[0.2 0.5] = [0.4 1.0];
%        when cdecoy=3,   then ctarget = cdecoy*[0.2 0.5] = [0.6 1.5];
%
%      the 3rd parameter r1, do not apply 'ratio_base', as
%         par_search.ratio_base(3) =0.
%      Illegal settings:
%       (1) Users should avoid the case of `looped bases' cases. e.g.,
%       ratio_base =[0 3 2]  (illegal)
%           then the 2nd prameter has the 3rd parameter as ratio base;
%           and the 3rd parameter has the 2nd parameter as ratio base;
%      (2) ratio_base = [0 2 0] (illegal)
%          it means the 2nd prameter has the 2rd parameter (itself) as ratio base (illegal);
%      (3) ratio_base = [0 1 2 3] (illegal)
%          current function support at most 2 ratio bases
%      (4) Users should avoid use a non-numeric valued feature as ratio base feature
%
%  varargin: the names and values of parameters of cross validation
%    varargin{2*i-1}: a string, the argument name;
%    varargin{2*i}:  a vector indicating the   values of the argument
%     of varargin{2*i-1}; for i=1, 2, ...
%
%    supported parameters:
%       'n': optional, a positve interger, maximum number of samples for cross
%           validation;
%           default value: the max length of matrices and vectors contained
%           in the matTrainFile;
%
%       'k': optional, a positive integer (k>=2), number of folds;
%           default value: 5;
%       'flag_equal_fold_size': optional, 1 or 0, whether ensures each fold 
%               have the common size, default 0; 
%       'flag_excel': optional, 1 or 0, whether put out the cross validation results to excel file,
%              default value: problemArg('flag_put_out_2_excel'); 
%       'flag_mat': optional, 1 or  0, whether save the crossvalidation   result to MAT file, defualt value 1
%       'saveFileFun': optional, a function handle to save training or validating samples to an independent mat files.
%           The function handle has the following format:
%              saveFileFun(matFileName, matDataFileName,index_v,n)
%
%           matFileName:     a string, mat file name to save the specified data   samples
%           matDataFileName: a string, mat file name that saved the samples
%           index_v:         a vector of indices between 1 to N, the indices of  samples to save;
%           n:               Optional, maximum number of instances for cross validation
%
%           default function handle:
%           save  the specified indices of ALL  the matrices and vectors of lenght N contained in the matTrainFile
%           as an independent mat file; the variable names hold the same.
%       'bestResult': optional, a function handle to find the best result with format
%           i_opt = bestResult(result_st)
%         with result_st a struct array of the result output by ALG()
%           i_opt: an index of the best result
%         Default function handle find the maximum value of the first item of result_st
%       'par_second_round': optional, a string, parameter name (one field of
%        par_search) for  second round of detailed grid search, default
%        value: ''.
%           the searching values of the specified field on 2nd round grid search is
%           determined by par_search.(arg.par_second_round)
%           * the 2nd round  search only supports grid searching of one parameter
%           *  the 2nd round  search increase the covered interval compared with par_search.(arg.par_second_round)
%           * In the following cases, it will cancel the 2nd round search
%               case (1) arg.par_second_round is not a filed of par_search;
%               case (2) par_search.(arg.par_second_round) ==[0] or is empty;
%      'verbose': optional, default 1;
%           0: do not print any information
%           1: print brief information
%
% Outputs:
%   result_opt: the optimal reach result on validation sets
%   par_opt: a struct indicating the parameter values with optimal accuracy
%   varargout{1}: a cell array of size n_search-by-K iterated information for each submodel
%           with n_search the number of groups of searching values 
%           K: number of folds (K-fold cross validation)
%   
% Usage example:
%   E.g.1   search (lambda, r1)= (0.1,0,1), (5.0,0.1), (0.1,0,2), (5.0,0.2),  (0.1,1.0), (5.0,1.0)
%
%    par_search = struct( 'lambda',[0.1 5.0],'r1',[0.1 0.2 1.0]);
%    [result_opt,par_opt]= crossValidate(alg,  matTrainFile, par_alg, par_search,'k',5)
%
%    [result_opt,par_opt]= crossValidate(alg,  matTrainFile, par_alg, par_search)
%  
%    [result_opt,par_opt,ite_c]= crossValidate(alg,  matTrainFile, par_alg, par_search)
%
% version
%   2019.12.3: fix a bug: Line 381. ��Ƕ�׺���֮�乲������.
%       Shared variables in parent function and nested function need to be initialized
%       explicitly; 
%   2018.10.20: add a parameter 'verbose', 'save_to_file'
%   2018.10.10: add a parameter 'flag_excel'
%    2018.10.3: add an output of iterated inforamtion, ite_c, output by alg
%   2018.9.14  Add second round of grid search (detailed grid search); add
%   parameter 'par_second_round' ;
%   2018.9.12  fix a bug of string valued parameters
% future version:
%  * support   cell arrays   to search (rather than merely numeric array);

% % % In future version:
% % %   E.g. 2 search r1 = 0.1, 0.2 and 1.0 resp. with  kernelType   'rbf'
% % %
% % %     par_search = struct( 'kernelType',{'rbf'},'r1',[0.1 0.2 1.0]);
% % %    [result_opt,par_opt]= crossValidate(alg,  matTrainFile, par_alg, par_search)
% % %

global debug_crossValidate

debug_crossValidate = 0; % whether debug the function


[flag_put_out_2_excel,num_grid_cv_2nd_round]= problemArg('flag_put_out_2_excel','num_grid_cv_2nd_round');


result_opt = [];
par_opt = [];
if isempty(flag_put_out_2_excel)
    flag_put_out_2_excel = 1;
end
if isempty(num_grid_cv_2nd_round)
    num_grid_cv_2nd_round = 11;
end

% 0.1 get user provided prameters
arg = struct();
len_argin = length(varargin);
if len_argin>0
    arg = assignStruct(arg, varargin(1:2:len_argin),varargin(2:2:len_argin));
end
% set default values
arg = completeArg(arg, ...
    {'n','k','saveFileFun','bestResult',  'par_second_round','flag_equal_fold_size','flag_excel',       'verbose','flag_mat'},...
    {[], 5,   @saveFileFun,   @bestResult, '',                0,                    flag_put_out_2_excel,   1,      1 });

fold_k = arg.k;
saveFileFun_h = arg.saveFileFun;
verbose_crossVal = arg.verbose; % print brief information

% 0.2 get parameter names and values for grid search
% % %
% % % if mod(len_arg,2)~=0
% % %     error('the input parameter-values should be given as  ''parameter-1,value-1,...,parameter-N,value-N'' format)' );
% % % end
ratio_base = [];
if isfield(par_search,'ratio_base')
    ratio_base = par_search.ratio_base;
    par_search = rmfield(par_search,'ratio_base'); % remove the field ratio_base
end

par_name_c = fieldnames(par_search);
par_val_c = struct2cell(par_search);
n_par_name =  length(par_name_c);


h = @(x) max(numel(x),1);
n_parVal_v = cellfun(h, par_val_c);
n_parVal_v = rowVec(n_parVal_v);

% number of tested values of each parameter
n_parVal_total = prod(n_parVal_v);
% total number of group of parameter values to test
%  note that  ratio_base setting do not affect the number of parameters

if debug_crossValidate
    fwritef(1,'par_name_c',par_name_c,'' ,'par_val_c',par_val_c,'','n_parVal_v',n_parVal_v,'','arg',arg,'');
end

% check the variable type of par_val_c
par_type_v = zeros(1,n_par_name); % 0: illegal type;  1: numeric array;  2: cell array
for ii=1:n_par_name
    if isnumeric(par_val_c{ii})
        par_type_v(ii) = 1;
    elseif iscell(par_val_c{ii})
        par_type_v(ii) = 2;
    end
end

% if nnz(~par_type_v )>0
%     error('Only support numeric array or cell array for specifying searching values.');
% end

if nnz(par_type_v~=1)>0
    error('Only support numeric   values to search.');
end


% 0.3 check  the 'ratio_base' mode
order_par = 1:n_par_name;
if ~isempty(ratio_base)
    % check length
    if length(ratio_base) ~= n_par_name
        error('ratio_base should be a vector of eqaul length with parameter names.');
    end
    % check the case ratio_base(i) ==i
    if nnz(ratio_base==1:n_par_name)>0
        error('ratio_base(i) should not be i, for each i.');
    end
    % check the number of ratio bases
    if nnz(ratio_base)>2
        error('current function support at most 2 ratio bases.');
    end
    
    %  check whether the specified ratio base featurs are not numeric
    %  (in future version)
    
    % check the order of the specified bases
    
    if nnz(ratio_base)>0
        ind = find(ratio_base);
        % reset the order to set  parameter values
        if nnz(ratio_base) ==1
            if ratio_base(ind) > ind
                % ensure ratio_base(ind) < ind ,such that
                % calculating the values of ratio_base(ind)-th
                % parameter before the ind-th paramether
                order_par = swap(order_par, ind, ratio_base(ind)); % interchange the two indidces of order_par
            end
        elseif nnz(ratio_base) ==2
            if ratio_base(ind(1)) == ind(2)
                if ratio_base(ind(2)) ==ind(1)
                    error('Illegal ratio_base: loop bases occur.');
                else %ratio_base(ind(2)) ~=ind(1)
                    order_par_1_to_3 = [ratio_base(ind(2)) ind(2) ind(1)];
                end
            else %ratio_base(ind(1))~= ind(2)
                if ratio_base(ind(2))== ind(1)
                    order_par_1_to_3 = [ratio_base(ind(1))  ind(1) ind(2) ];
                else
                    order_par_1_to_3 = [ratio_base(ind(1))  ind(1) ratio_base(ind(2)) ];
                end
            end
            order_par(order_par_1_to_3) = [];
            order_par = [order_par_1_to_3  order_par];
        end
        
    end
end

if debug_crossValidate
    fwritef(1,'ratio_base',ratio_base,'','order_par',order_par,'');
end

% 0.4 initialization
len_arg = length(par_val_c);
n_par = len_arg; % number of groups of parameters for grid search


% % % Acc_m = zeros(n_parVal_total,fold_k);  % save the accuracy on each fold
Par_c = cell(n_parVal_total,1);


% 1. assign the parameter values to test
ind_v = cell(n_par,1);
par0_c = cell(n_par,1); % store a group of parameter values
isempty_ratio_base = isempty(ratio_base);
for ii_par = 1:n_parVal_total
    % assign each group of parameter values
    [ind_v{1:n_par}]  = ind2sub(n_parVal_v,ii_par); % ind_v: index of vector form for i_par
    % receive multiple outputs by cell array
    for j=1:n_par
        k = order_par(j); % k: the k-the feature (parameter)
        %if par_type_v(k)==1 %  par_val_c{k} is numeric array
        par0_c{k} =  par_val_c{k}(ind_v{k});
        %else % par_type_v(k)==2 %  par_val_c{k} is cell array
        %    par0_c{k} =  par_val_c{k}{ind_v{k}};
        %end
        if ~isempty_ratio_base && ratio_base(k)>0
            par0_c{k} =  par0_c{k}* par0_c{ratio_base(k)};
            % note that par0_c{ratio_base(k)} should been calculated
            % before par0_c{k}
        end
    end
    Par_c{ii_par}= par0_c;
end

if debug_crossValidate
    fwritef(1,'Par_c',Par_c,'','par_name_c',par_name_c,'');
end

% 2. generate indices of training set and validation set

% 2.1   determine the value of N (number of total samples)
is_matrix_or_vec = @(x) (size(x,3)==1); % whether x is a 2-dimensional array
max_len_data = 0;
if isequal(saveFileFun_h,@saveFileFun)|| isempty(arg.n)
    % check the maximum size of the matrices and vectors contained in matTrainFile
    data_st = load(matTrainFile);  % load data
    v1 = structfun(@isnumeric,data_st); %
    v2 = structfun(is_matrix_or_vec,data_st); %
    ind_mat_vec = find(v1&v2);
    fieldname_c = fieldnames(data_st);
    % max length of matrices and vectors in data_st
    max_len_data = 0;
    for ii=1:length(ind_mat_vec)
        i_field = ind_mat_vec(ii);
        max_len_data = max(max_len_data,length(data_st.(fieldname_c{i_field})));
    end
    if debug_crossValidate
        fwritef(1,'isequal_saveFileFun',isequal(saveFileFun_h,@saveFileFun),'');
    end
end



n_sample = max_len_data;
if debug_crossValidate
    fwritef(1,'n_sample',n_sample,'','fold_k',fold_k,'');
end

% 2.2 generate cross validation indices
index = crossValidateIndex(n_sample,fold_k,arg.n,arg.flag_equal_fold_size);
if n_sample<fold_k
    error('The number of training samples should greater than the number of folds.');
end
if verbose_crossVal>0
    fprintf(1,'Cross validation: %d samples.  %d-fold, %d-group of parameters.\n',arg.n,fold_k,n_parVal_total);
end

% 3.  k-fold  cross validation to find a group of good parameter values

date_str = datestr(now,30);
%path_str = [pwd filesep];

[path_str,dataset_name,~] =  fileparts(matTrainFile);
path_str = [path_str filesep];

matTrainFile_split = [path_str date_str '_' dataset_name '_crossVal_train.mat'];
matValidateFile_split =  [path_str date_str '_' dataset_name '_crossVal_validate.mat'];
% % % matScoreFile = [path_str date_str '_crossVal_score.mat'];

bestResult_h = arg.bestResult;

% 1st search: loose grid search
i_parVal_start =1;
i_parVal_end = n_parVal_total;
par_alg_st =struct([]); % initialized as a 0-by-0  struct 
if nargout==1
    [result_1_st] = grid_search(i_parVal_start,i_parVal_end);
else
    [result_1_st,ite_1_c] = grid_search(i_parVal_start,i_parVal_end);
end
i0_opt =  bestResult_h(result_1_st);
i1_opt = i0_opt; % for saving in mat file
if ~isempty(i0_opt) && i0_opt>0 % i_opt ==-1: no qulified  results found
    result_opt = result_1_st(i0_opt,:);
    par_opt = par_alg_st(i0_opt);
end
if debug_crossValidate
    fwritef(1,'i0_opt',i0_opt,'',   'result_1_st',result_1_st,'');
end

% 2nd round of grid search: detailed grid search
r1 = arg.par_second_round;
if ~ischar(r1)
    warning('par_second_round parameter should be a string');
end
ind_r1_par_name = find(strcmpi( r1 ,par_name_c));
% index of arg.par_second_round in par_name_c (==fieldnames(par_search))

r1_search_round_2 = [];
if ~isempty(i0_opt) && i0_opt>0 && ~isempty(r1) && ~isempty(ind_r1_par_name)...
        && ~isempty(par_search.(r1))&& ~isequal(par_search.(r1),0)
    if verbose_crossVal
        fprintf(1,'2nd search: detailed grid search.\n');
    end
    % determine the searching values of the 2nd round searching parameter
    
    r1_search_v =   zeros(1,length(par_search.(r1))+2);
    r1_search_v(2:end-1) = sort(par_search.(r1),'ascend');
    % add two searching values: a minimum value and a maximum value
    if r1_search_v(2)>=0
        r1_search_v(1) = r1_search_v(2)*0.5;
    else %r1_search_v(2)<0
        r1_search_v(1) = r1_search_v(2)*1.5;
    end
    if r1_search_v(end-1)>=0
        r1_search_v(end) = r1_search_v(end-1)*1.5;
    else %r1_search_v(end-1)<0
        r1_search_v(end) = r1_search_v(end-1)*0.5;
    end
    % get the optimal value of  arg.par_second_round on the 1st round
    % search
    par_opt_round1_c = Par_c{i0_opt};
    r1_opt_round_1  =  par_opt_round1_c{ind_r1_par_name};
    ind_r1_search_opt = find( abs(r1_search_v - r1_opt_round_1)<1E-15, 1);
    % determine the searching values of arg.par_second_round
    if isempty(ind_r1_search_opt)
        %%%warning('Not found r1_opt_round_1 in par_search.');
        r1_search_round_2 =   r1_search_v;
    else % i_opt is not empty
        lb = r1_search_v(ind_r1_search_opt-1);
        ub = r1_search_v(ind_r1_search_opt+1); % note that 2<=i_opt <=length(par_search.r1)+1
        r1_search_round_2 = linspace(lb,ub,num_grid_cv_2nd_round);
    end
    % searching parameters
    n_search_round_2 = length(r1_search_round_2);
    Par_c(n_parVal_total+1:n_parVal_total+n_search_round_2) = Par_c(i0_opt);
    for ii = n_parVal_total+1 : n_parVal_total+n_search_round_2
        Par_c{ii}{ind_r1_par_name}=r1_search_round_2(ii-n_parVal_total);
    end
    
    if debug_crossValidate
        fwritef(1,'Par_c',Par_c,'','r1_search_round_2 ',r1_search_round_2 ,'');
    end
    % grid search
    i_parVal_start =n_parVal_total+1;
    i_parVal_end = n_parVal_total+n_search_round_2;
    if nargout==1
        [result_2_st] = grid_search(i_parVal_start,i_parVal_end);
    else        
        [result_2_st,ite_2_c] = grid_search(i_parVal_start,i_parVal_end);
    end
    % merge   the results of 1st and 2nd round searches
    result_total = result_1_st;
    result_total(n_parVal_total+1 : n_parVal_total+n_search_round_2,:) = result_2_st(:,:);
    if nargout>1
        ite_total_c = ite_1_c; % merge ite_1_c and ite_2_c
        ite_total_c(n_parVal_total+1 : n_parVal_total+n_search_round_2,:) = ite_2_c;
    end
    % reset n_parVal_total
    n_parVal_total = n_parVal_total + n_search_round_2;
    i2_opt =  bestResult_h(result_total);
    if ~isempty(i2_opt) && i2_opt>0 % i2_opt ==-1: no qulified  results found
        result_opt = result_total(i2_opt,:);
        par_opt = par_alg_st(i2_opt);
    end
    i_opt_last = i2_opt;
    result_opt_last = result_total;
else % no second round search
    i_opt_last = i1_opt;
    result_opt_last = result_1_st;
    result_total = result_1_st;
    if nargout>1
        ite_total_c = ite_1_c; 
    end
end

if nargout>1
	varargout{1} = ite_total_c;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if arg.flag_mat
    matResultFile =  [path_str 'result_crossVal_' dataset_name '_' date_str '.mat'];
    stamp = datestr(now,30);
    save(matResultFile,'par_alg_st', 'result_opt_last', 'i_opt_last','par_opt','result_opt',...
        'stamp','r1_search_round_2','n_parVal_total','matTrainFile','par_alg', 'par_search');
    if nargout>1
        save(matResultFile,'ite_total_c','-append');
    end

end


if verbose_crossVal
    fprintf(1,'optimal parameter and results:\n');
    fwritef(1,'par',par_opt,'');
    if arg.flag_mat
        fprintf(1,'The cross-validation results have been saved to %s.\n', matResultFile);
    end
end


% delete tempary files
if exist(matTrainFile_split,'file')
    delete(matTrainFile_split);
end
if exist(matValidateFile_split,'file')
    delete(matValidateFile_split);
end


% * print out the results to Excel file
if arg.flag_excel
    resultFile = [path_str 'result_crossVal_' dataset_name '_' date_str '.xlsx'];
    start_row_body = '6'; % start row of the main results
    sheetName = 'sheet1';
    % *.01 print out train file name
    xlswrite(resultFile,  {matTrainFile,date_str},'A1:B1',sheetName);
    % *.02 print out the best parameter:
    xlswrite(resultFile, { 'Best parameter index:' ,i_opt_last},'A2:B2',sheetName);
    %fwritexls(resultFile, {}, par_opt,'A3',sheetName,'h');
    
    % *.1 print out the parameters: par_alg_st
    par_alg2_st(1:fold_k:n_parVal_total*fold_k) = par_alg_st;
    
    id_c = cell(n_parVal_total*fold_k,1);
    id_c(1:fold_k:n_parVal_total*fold_k) = num2cell(1:n_parVal_total)';
    fwritexls(resultFile,{'id'},id_c,['A' start_row_body],sheetName,'h');
    
    [coverSize] = fwritexls(resultFile,'',par_alg2_st,['B' start_row_body],sheetName,'h');
    
    % *.2 print out the results: result_total
    startCell =   [char('B'+ coverSize(2)) start_row_body];
    fwritexls(resultFile, '', reshape(result_total',[],1),startCell,sheetName,'h');
    
    if verbose_crossVal
        fprintf(1,'The cross-validation results have been put out to %s.\n', resultFile);
    end
end


    function [result_st,varargout] = grid_search(i_parVal_start,i_parVal_end)
        % grid search
        % i_parVal_start: starting index of the parameter to search
        % i_parVal_end: ending index of the parameter to search
        % result_st: a struct array of length i_parVal_end-i_parVal_start+1
        
        ite_c = [];
        for i_fold = 1:fold_k
            if verbose_crossVal > 0
                fprintf(1,' fold %d/%d:\t',i_fold,fold_k);
            end
            % 3.1  % save the data to tempary train file and validation file
            saveFileFun(matTrainFile_split,    matTrainFile,  index(i_fold).train);
            saveFileFun(matValidateFile_split, matTrainFile,  index(i_fold).test);
            % 3.2  loop all the parameter  values
            for i_par = i_parVal_start :i_parVal_end
                if verbose_crossVal > 0
                    fprintf(1,'+');
                end
                % set the values of the group of parameters
                par0_c = Par_c{i_par} ;
                %  assign the parameter struct
                if i_fold==1
                    par_alg_ii = completeArg(par_alg,  par_name_c,    par0_c,[],1);
                    % compulsory assignment:
                    %    all the ITEMs of par_alg specified in par_name_c would be reset as the values
                    %    of par0_c
                    if i_par==i_parVal_start
                        if isempty(par_alg_st)
                            par_alg_st = par_alg_ii;
                        end
                        par_alg_st(i_parVal_end) = par_alg_ii; % initialize the struct array
                    end
                    par_alg_st(i_par) = par_alg_ii;
                else%  i_fold>1
                    par_alg_ii = par_alg_st(i_par);
                end
                
                if debug_crossValidate
                    fwritef(1,'par_alg_ii',par_alg_ii,'');
                end
                if nargout==1
                    [result_0] = alg(matTrainFile_split,matValidateFile_split, par_alg_ii);
                else % nargout ==2
                    [result_0, ite_0] = alg(matTrainFile_split,matValidateFile_split, par_alg_ii);
                    ite_0.index_train_cv = index(i_fold).train;
                    ite_0.index_test_cv = index(i_fold).test;
                end
                
                if i_par==i_parVal_start && i_fold==1
                    result_st(i_parVal_end-i_parVal_start+1,fold_k) = result_0;
                    ite_c = cell(i_parVal_end-i_parVal_start+1,fold_k); 
                end
                result_st(i_par-i_parVal_start+1,i_fold) = result_0;
                if nargout>1
                    ite_c{i_par-i_parVal_start+1,i_fold} = ite_0;
                end
            end % end loop of parameters
            if verbose_crossVal > 0
                fprintf(1,'\n');
            end
        end % end loop of i_fold
        if nargout>1
            varargout{1} = ite_c; 
        end
    end % end function of grid_search

end % end function of crossValidate

function n_saved_var = saveFileFun(matFileName, matDataFileName,index_v)
% save  the specified indices of ALL  the matrices and vectors of lenght N contained in the matTrainFile
%           as an independent mat file; the variable names hold the same.
%   matFileName: a string, mat file name to save the specified data   samples
%   matDataFileName: a string, mat file name that saved the samples
%   index_v: a vector of indices between 1 to N, the indices of  samples to save;
% Outputs:
%   n_saved_var, Optional, number of saved  variables of data matrices and
%       vectors

%%%debug_crossValidate = 1;
global debug_crossValidate

is_matrix_or_vec = @(x) (size(x,3)==1); % whether x is a 2-dimensional array
data_st = load(matDataFileName);  % load data
v1 = structfun(@isnumeric,data_st); %
v2 = structfun(is_matrix_or_vec,data_st); %
ind_mat_vec = find(v1&v2);
fieldname_c = fieldnames(data_st);

if isempty(ind_mat_vec)
    error('No data matrix or vector found in the specified file %s',matDataFleName);
end
% get size of data matrices and vectors
size_data_v = zeros(length(ind_mat_vec),2); % size of each data matrix and vector
for ii=1:length(ind_mat_vec)
    i_field = ind_mat_vec(ii);
    size_data_v(ii,:) = size(data_st.(fieldname_c{i_field}));
end

% get the index of fileds that achive the maximum data length
max_len_data = max(max(size_data_v));
% % % ind_max_len_data = ind_mat_vec(max(size_data_v,[],2) == max_len_data);

if debug_crossValidate
    fwritef(1,'max_len_data',max_len_data,'','size_data_v',size_data_v,'',...%'ind_max_len_data',ind_max_len_data,'',...
        'ind_mat_vec', ind_mat_vec,'',     'index_v',index_v,'');
end

% % %     n_saved_var = length(ind_max_len_data);
% % %     for ii=1:n_saved_var
% % %         i_field = ind_max_len_data(ii);
% % %         is_1_dim_reach_max_len =  size_data_v(i_field,1) == max_len_data;
n_data_v = length(size_data_v);
for ii=1:n_data_v
    
    i_field = ind_mat_vec(ii);
    is_1_dim_reach_max_len =  size_data_v(ii,1) == max_len_data;
    if is_1_dim_reach_max_len
        data_st.(fieldname_c{i_field}) = data_st.(fieldname_c{i_field})(index_v,:);
    elseif  size_data_v(ii,2) == max_len_data; % the 2nd dimension has max length
        data_st.(fieldname_c{i_field}) = data_st.(fieldname_c{i_field})(:,index_v);
    end
end

% save the data matrices and vectors to file
save(matFileName,'-struct','data_st');
end


function i_opt = bestResult(result_st)
%  default function handle to  find the maximum value of the first  item of result_st
%  Inputs:
%   result_st: a struct array size n_parVal_total  * k_fold   of the result output by ALG()
%  Outputs:
%   i_opt: an index of the best result

i_opt = [];
names = fieldnames(result_st);
[n_result,k] = size(result_st);
result_c = cell(n_result,k);
if ~isempty(names)
    [result_c{:,:}] = result_st(:,:).(names{1});
    result_m = cell2mat(result_c);
    [~,i_opt] = max(mean(result_m,2));
end
end

