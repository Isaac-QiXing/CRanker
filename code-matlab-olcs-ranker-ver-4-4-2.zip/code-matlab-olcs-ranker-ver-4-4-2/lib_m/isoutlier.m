function is_v = isoutlier(v)
%meann = mean(v);
meann = median(v);
stdd = mad(v);


%is_v = bsxfun(@gt, abs(bsxfun(@minus, v, meann)), 2*stdd);
% meann
% stdd

is_v =  abs(v - meann)>2*stdd;