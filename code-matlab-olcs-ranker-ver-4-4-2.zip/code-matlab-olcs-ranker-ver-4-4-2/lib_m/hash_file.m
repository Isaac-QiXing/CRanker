function h = hash_file(s,alg)
% Convert the state (bytes, dates etc.) of a file into a message digest using any of 
%        several common hash algorithms 
% Inputs:
% s:   a string of a file name (including path)
% alg: hash algorithm, which is one of the following: 
%        'MD2', 'MD5', 'SHA-1', 'SHA-256', 'SHA-384', or 'SHA-512'  
% Outputs:
% h    = hash digest output, in hexadecimal notation; 
%   h = '', if the file does not exist 
%   
% 
% USAGE e.g.  h = hash_struct('./data/mydata.txt','MD5') 

h  = '';
if ~exist(s,'file')
    return;
end

stat = dir(s);

h = hash_struct(stat,alg); 


