function [ionsNum] = transformIons(ions_cell)
% Transform the ions into decimal format
% Argument
% Input: a string cell array, with each string in date format, e.g.,
%   '2012-11-12', or  a number '0.72';%       
% Output: a vector with the same size as ions_cell, in decimal format
ionsNum = [];
if ~isempty(ions_cell)
    if isnumber(ions_cell{1}) % the string is already composed by numbers 0--9
        ionsNum = cellfun(@str2num,ions_cell,'UniformOutput',true);
    else
        ionsNum = cellfun(@Date2Num,ions_cell,'UniformOutput',true);
    end
end
