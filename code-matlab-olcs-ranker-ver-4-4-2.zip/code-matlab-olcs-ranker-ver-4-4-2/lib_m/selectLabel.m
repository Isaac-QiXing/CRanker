function [ind]= selectLabel(y,sampleSize,negative_rate)
% select certain number of labels randomly
% Inputs:
%  y: a vector of labels, consisting of 1 and -1; 
%  sampleSize: a positive integer, indicating the number of labels to select
%  negative_rate: number of negative sample / whole number of samples
%       in the selected subset of labels;
% Outputs:
%   ind: a column vector of the indices of selected labels
 

negative_set = find(y==-1);
positive_set = find(y==1);
% the number of negatives and  positives to sample
num_negative_sub = min(length(negative_set),round(sampleSize*negative_rate));      
num_positive_sub = min(length(positive_set),sampleSize-num_negative_sub);
% sampling
negative_sub = subVector(negative_set,num_negative_sub);
positive_sub = subVector(positive_set,num_positive_sub);
ind = [positive_sub; negative_sub];


end