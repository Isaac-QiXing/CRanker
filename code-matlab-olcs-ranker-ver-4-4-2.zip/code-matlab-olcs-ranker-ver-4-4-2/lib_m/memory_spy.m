function mem_spy = memory_spy(flag)
% Input:
%   flag: 0 or 1: 
%       0: start to watch the memory used by Matlab
%       1: stop watching, output the memory used in the interval between 
%           memeoy_spy(0)   and memory_spy(1)
% Output:       
%   mem_spy:  
%       if flag ==0, return []; 
%       else return the memory (Mb) used by Matlab  

persistent spy_timer mem_initial mem_max mb



if flag == 0 
%     secondsBreak = 30;
% secondsBreakInterval = 600;
    secondsPerHour = 60^2;
    secondsWorkTime = 8*secondsPerHour;
    mb = 2^20;
    
    spy_timer  = timer;
    spy_timer.StartFcn = @timerStart;
    spy_timer.TimerFcn = @timerRun;
    spy_timer.StopFcn = @timerStop;
    spy_timer.Period = 1.0;
    spy_timer.TasksToExecute = round(secondsWorkTime/spy_timer.Period);
    spy_timer.ExecutionMode = 'fixedRate';
    start(spy_timer);
    mem_spy =[];
else % flag ==1
    if isempty(spy_timer)
        error('start memory_spy by ``memory_spy(0)'' first. ');
    end
    stop(spy_timer);

    mem_spy = mem_max-mem_initial;

    spy_timer = [];
end
    


     function timerStart(~,~)
         % initialize   mem_initial and       mem_max
         userview = memory; 
         mem_initial = userview.MemUsedMATLAB / mb;
         mem_max = mem_initial;
     end
 
    function timerRun(~,~)
         userview = memory; 
         mem_i = userview.MemUsedMATLAB / mb;
         mem_max = max(mem_max,mem_i);
    end

    function timerStop(~,~)
         userview = memory; 
         mem_i = userview.MemUsedMATLAB / mb;
         mem_max = max(mem_max,mem_i);
    end

end

