function [ flag ] = isSubString(str,subString )
% determine whether a substring exist in another string
%
%  version 1.   2019.12.12
% Inputs:
%  str: a string or string cell array
% Outputs:
% flag: a logical value if STR is a string; 
%       a logical array if STR is a string cell array; 
    
    if ischar(str)
        flag = ~isempty(strfind(str, subString));
    else
        k_c = strfind(str, subString);
        flag = cellfun(@isempty,k_c);
        flag = ~flag; 
    end
end

