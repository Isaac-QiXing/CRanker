function [Xp] = standardize(X)
% make each column of X zero-mean and unit-variance

d = size(X,2);
Xp = zeros(size(X));   
    for i=1:d       
        std_i = std(X(:,i));
        Xp(:,i)=(X(:,i)-mean(X(:,i)))/(std_i+~std_i);    % std_i+~std_i: deal with the case that  that std_i == 0
    end
