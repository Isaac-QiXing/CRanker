function st2= gather_struct(flag_double,st)
% transform a scalar struct with  gpuArray fields to local workspace
% Inputs:
%   st: a scalar struct of  gpuArray fields
%  flag_double: 1 or 0, indicate whether to return numeric arrays of double float  type
% Outputs:
%   st2: a scalar struct with numeric fields  in local workspace

st2 = st; 

fieldnames_c = fieldnames(st2);

for ii=1:length(fieldnames_c)
    field = fieldnames_c{ii};
    if flag_double
        st2.(field) = double(gather(st2.(field)));
    else
        st2.(field) = gather(st2.(field));
    end
end

end 