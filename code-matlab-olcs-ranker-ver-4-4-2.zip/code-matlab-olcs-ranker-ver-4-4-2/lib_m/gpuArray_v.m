function varargout = gpuArray_v(flag_single,varargin)
% transform a group of   numeric arrays to gpuArray
% Inputs:
%  flag_single: 1 or 0, indicate whether to return single gpuArray
% Outputs:
%   the transformed gpuArrays
% Usage: 
%   [a,b,c] = gpuArray_v(1,zeros(2,2),magic(5,5),[1,2,3]);
%       a,b,c are three gpuArrays, with 
%       a = zeros(2,2,'single','gpuArray')
%       b = magic(5,5,'single','gpuArray')
%       c = gpuArray(single([1,2,3]));

varargout = cell(size(varargin));
if nargin>1
    for ii=1:nargin-1
        if flag_single
            varargout{ii} = gpuArray(single(varargin{ii}));
        else
            varargout{ii} = gpuArray(varargin{ii});
        end
    end
end

end