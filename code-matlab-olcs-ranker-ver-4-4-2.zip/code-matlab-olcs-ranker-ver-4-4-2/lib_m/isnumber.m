function flag = isnumber(str)
% check whether a string is composed by numbers 0--9, or '.', '+', '-'
%   ('+','-s' only occur at the beginning);
% % % if ~ischar(str)
% % %     flag = 0;
% % %     warning('The input should be a string.');
% % %     return
% % % end
if ischar(str)
    flag = ~isempty(regexp(str,'^[-+]?[\d\.]+$','match'));
else
    flag = isnumeric(str);
end

end