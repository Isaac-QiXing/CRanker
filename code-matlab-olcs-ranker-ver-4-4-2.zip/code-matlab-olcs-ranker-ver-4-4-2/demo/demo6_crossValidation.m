%demo_crossValidation.m
clear 
clc

flag_have_try = 1;%0;%

% path = 'E:\data_psm\';
path = '.\';

if flag_have_try
    dataset_c = {'ups1'};
else
    %dataset_c = {'yeast','ups1','tal08','tal08_large','pbmc_orbit_mips','pbmc_orbit_nomips','pbmc_velos_mips','pbmc_velos_nomips'};
     dataset_c = {'ups1','tal08','yeast','tal08_large'};
    dataset_c = {'ups1'};
end

if flag_have_try
%     par_search = struct( 'cdecoy',[   2^(-1)   2^1   ],...
%         'c3_c1_ratio', [  0.35   0.75   ],...        % ratios of ctarget to  cdecoy
%         'r1',[   1    2^2 ]);
 par_search = struct( 'cdecoy',[  0.3],...
        'ctarget_cdecoy_ratio', [  0.225/0.3     ],...        % ratios of ctarget to  cdecoy
        'r1',[   4.0      ],...
        'lambda_ctarget_ratio', [2.0 4.0]);
    %      train_test_rate = 5/1; 
%         k_fold = 5;
          train_test_rate = 1/5; 
          k_fold = 2;
else
    % for ups1
    par_search(1) = struct( 'cdecoy',[  0.2  0.6  1.0  2.0   ],...
        'ctarget_cdecoy_ratio', [   0.1  0.3  0.6  ],...        % ratios of ctarget to  cdecoy
        'r1',[  1.0    2     2^2      ],...
        'lambda_ctarget_ratio', [1.0 1.5 2.0]);
    
    % for tal08
    par_search(2) = struct( 'cdecoy',[2^(-2)  1    2^2   2^4  ],...
        'ctarget_cdecoy_ratio', [   0.1  0.3  0.5  0.75  ],...        % ratios of ctarget to  cdecoy
        'r1',[  1.0    2^2 ],...
        'lambda_ctarget_ratio', [2.0]);
    % for yeast 
    par_search(3) = struct( 'cdecoy',[ 2^(-1)    2^2   2^4 ],...
        'ctarget_cdecoy_ratio', [   0.1  0.3  0.5  0.75  ],...        % ratios of ctarget to  cdecoy
        'r1',[  1.0    2^2 ],...
        'lambda_ctarget_ratio', [2.0]);
    
    % for tal08_large
    par_search(4) = struct( 'cdecoy',[2^(-1)  1    2^2   ],...
        'ctarget_cdecoy_ratio', [   0.1  0.3  0.6  ],...        % ratios of ctarget to  cdecoy
        'r1',[  2.0    2^3  ],...
        'lambda_ctarget_ratio', [1.0 1.5 2.0]);    
    
      train_test_rate = 5/1; 
      k_fold = 3; %5;
end



% for i_set =1:length(dataset_c)
for i_set =1:1
    dataset = dataset_c{i_set};
    dataFile = [path dataset '.mat'];
     rawFileName = [path dataset '.xlsx'];
% 
%     %   read PSM records
     olcs_read(rawFileName,dataFile); 

    [trainFile,~] = olcs_split(dataFile,'train_test_rate',train_test_rate);
   % trainFile = dataFile;
    olcs_cv('-k',k_fold,'-z','20000','-v',1,trainFile,par_search(i_set),@findBestResult);
end