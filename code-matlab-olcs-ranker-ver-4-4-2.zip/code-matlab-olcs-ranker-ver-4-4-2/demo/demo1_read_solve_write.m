% demo_cranker.m
% A demo to call 
%       olcs_read, olcs_solve and olcs_write

clear
 
 rawFileName = 'yeast.xlsx';  % data file containing records of PSMs
 rawFileName = 'ups1.xlsx';
%fileName = 'ups1.xlsx';  
 

matDataFile = 'myPSMdata.mat'; % Mat file name to store PSM records
matScoreFile = 'myPSMscore.mat'; % Mat file name to store the scores of identified PSMs

 
% 1. read PSM records
olcs_read(rawFileName,matDataFile); 
%olcs_read('-l','\b\t',fileName,dataFile); %-l: seperation character of different attribute values of PSM record 
%olcs_read('-w','1','-v','3','-e','0','-n','0',rawFileName,matDataFile); % -w: title row, -v: verbose

% 2. identify reliable target PSMs
olcs_solve(matDataFile,matScoreFile); 
% olcs_solve('-v','2',matDataFile,matScoreFile); % -v: verbose
% olcs_solve('-t','3',matDataFile,matScoreFile); %-t: train/test rate, 
% olcs_solve('-f','0',matDataFile,matScoreFile); %-f: whether split train and test 
% olcs_solve('-ctarget','0.1',matDataFile,matScoreFile);
% olcs_solve('-z','600','-m','3',matDataFile,matScoreFile);%-z: maximum train size; -m: number of submodels
%  olcs_solve('-x','0','-f','0','-v','3',matDataFile,matScoreFile); %-x: relateive feature weight of xcorr and deltacn

% 3. put out identified PSM records 
 resultFile = olcs_write(matDataFile,matScoreFile);
% olcs_write('-fdr','0.04','-v','0',matDataFile,matScoreFile);
 
 
