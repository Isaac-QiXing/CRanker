function path_str1 = removeFileSep(path_str)
% remove filesep at the end of a directory string if it does exist 
%  ('/' or '\')

path_str1 = path_str;
if ~isempty(path_str)
    path_str=strtrim(path_str);    
    len = length(path_str);
    end_char = path_str(len);
    if end_char=='\' || end_char=='/'
        if len>1
            path_str1 = path_str1(1:len-1);
        else
            path_str1 = '';
        end
    end
end

end