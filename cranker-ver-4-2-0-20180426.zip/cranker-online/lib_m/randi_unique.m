function v = randi_unique(imax,n)
% sample n different integer numbers randomly from [1,imax]
% Inputs:
%   imax,n: two positive integers with n<=imax;
% Outputs:
%   v: a column vector containing the sampled n numbers;

if n==imax
    v = (1:n)';
    return
end

r = n/imax;
if r>=0.3
    v = randperm(imax);
    v = v(1:n)';
else
    v = randi(imax,round(n*1.3),1);
    v = unique(v);    
    if length(v)>=n
        v = v(1:n)';
    else % this case is of little probability
        v = randperm(imax);
        v = v(1:n)';
    end
end

end