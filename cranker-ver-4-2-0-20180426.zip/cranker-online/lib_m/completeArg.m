function arg = completeArg(arg,arg_cell,arg_default_val,i_arg)
% complete values and items of a struture (or structure array) with given values
% Inputs:
%  arg: a structure or a structure array;
%  arg_cell: a string cell array, indicating the fields to complete;
%  arg_default_val: 
%    (1) a cell array with the same size as arg_cell, indicating
%        the values of the corresponding fields;
%    (2) or a structure, indicating the values with corresponding items;
%  i_arg: Optional, a vector of indices indicating the struct to complete
%     when arg is a struct array;
%     i.e.
%     the function complete the struct array arg as follows:
%     for all k = 1,2,...
%     if arg(k).item_i is not set and k belongs to i_arg
%       then complete the value of arg(k).item_i;
%     elseif arg(k).item_i is not set and k does not belongs to i_arg
%       then set arg(k).item_i = [];
%     Default value of i_arg: 1:length(arg); 
% Operation:
%  for each field, ITEM, indicated by arg_cell{i}, i =1,2,... 
%   if arg(k).ITEM is not exist or has empty value,  assign
%       arg(k).ITEM = arg_default_val{i}; for all k

if isempty(arg)
    arg = struct();   % this initialization should be previous than Line 29: i_arg = 1:length(arg); 
end
if nargin<=3 || isempty(i_arg)
    i_arg = 1:length(arg); % set default value of i_arg
end

flag_is_cell_default_val = iscell(arg_default_val);
for ii=1:length(arg_cell)
    fieldName = arg_cell{ii};
    for k_arg = 1:length(arg)
        in_i_arg = ismember(k_arg,i_arg);       
        if in_i_arg && (~isfield(arg,fieldName) || isempty(arg(k_arg).(fieldName)))
            if flag_is_cell_default_val
                arg(k_arg).(fieldName) = arg_default_val{ii};
            else % arg_default_val is struct
                if isfield(arg_default_val,fieldName)
                    arg(k_arg).(fieldName) = arg_default_val.(fieldName);
                else
                    arg(k_arg).(fieldName) = [];
                end
            end
        elseif ~in_i_arg && ~isfield(arg,fieldName) 
            arg(k_arg).(fieldName) = [];
        end
    end
end

end