function [acc num id] = accuracyMerge(num1,num2,id1,id2)
% merge the accuracy indices of two subsets
% Inputs:
%   num1, id1: num and id  accuracy structure array of the first set;
%   num1, id1: num and id  accuracy structure array of the second
%     set;
% Outputs:
%   acc, num, id: the accuracies, number's and id's on the set of 
%       the union of two sets;

len_num = length(num1);
fd_cell = fieldnames(num1);
for k=1:len_num
    for ii=1:length(fd_cell)
        fd = fd_cell{ii};
        num(k).(fd) = num1(k).(fd) + num2(k).(fd);
        id(k).(fd) = union(id1(k).(fd),id2(k).(fd));
    end
    acc(k).FDR = 2*num(k).FP/(num(k).FP + num(k).TP);
    acc(k).TPR = num(k).TP/(num(k).TP + num(k).FN);
    acc(k).FPR = num(k).FP/(num(k).FP + num(k).TN);
end
end