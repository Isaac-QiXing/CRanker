function [varargout]= calulate_score(fun,arg)
   %#function phi_fx    
%
% calculate the score of the given samples
%
% Inputs:
%  fun:
%       1) a function handle of the discriminant function;
%    or 
%       2) a struct containing the fields (see targetRank_theta_repeat.m) 
%         .alpha
%         .ind
%         .b   
%         indicating N (the column number of fun.alpha) submodels;  
%  arg: a structure indicating the arguments, containing the following
%     fields
%      .X: Optional, a matrix consisting of the samples, each row
%         representing a sample;      
%      .trainFile: Optional, name of the mat data file in which stores the
%         data matrix X; one of two arguments (arg.X and arg.trainFile) is
%         required to set;
%       Note that
%        * users should set the data matrix by either arg.X or
%          arg.trainFile, if both arg.X and arg.trainFile is set, only
%          arg.X is effective;  
%        * if fun is a function handle, then arg.X or arg.trainFile may
%          indicate arbitrary samples; otherwise, they should indicate the
%          samples in training set;
%     .kernelType: type of kernel function;
%     .r1: kernel argument;
%     .w: Optional, a vector consisting of the feature weights;
%     .testFile: Optional, indicating the name of mat file where containing
%        a matrix X, each row of which indicating a sample in the test set; 
%     .flagOutput: Optional, 
%         'train': output the scores on train set (indicated by argData);
%         'test':  output the scores on test set;
%         'train_test': output the scores on both train and test set;
%               this is also the default value;
%         'train+': output the scores on train set (indicated by argData),
%               including the scores of submodels;
%         'test+': output the scores on test set, including the scores of 
%               submodels;
%         'train_test+': output the scores on both train and test set,
%               including the scores of submodels;
%         
%  Outputs: 
%    varargout{1}: 
%       if arg.flagOutput is set 'train', 'train+',  'train_test',  
%         or 'train_test+', the first return variable is the scores on train
%         set; 
%       if arg.flagOutput is set 'test' or 'test+', the first return is
%         the scores on test set;
%    varargout{2}: if arg.testFile is set and arg.flagOutput is set
%       'train_test' or 'train_test+', the second return is the scores on
%       test set, otherwise there is no second return;
%
%    The form of return scores on train (or test) set: 
%       if
%         * fun is a function handle, 
%       or
%         * there is no plus ('+') character in arg.flagOutput (i.e. it is
%           set 'train', 'test' or 'train_test'), 
%       or
%         * there is a unique submodel (N=1);
%       then 
%           the returned scores (on train or test set) are column vector;
%       otherwise, 
%         the returned scores on train or test set are matrix with
%         N+1 columns, with the first column consisting of the scores of 
%         the final combined model; each column from 2nd to (N+1)-th column
%         consisting of the scores of a sub-model;

%%%
% % %         fwritef(1,'arg01',arg,'');
%%%

% arguments  
  % complete arguments with default values 
arg = completeArg(arg,{'X','trainFile','testFile','flag_output','kernelType','r1','w'},...
                {[], '',         '',        'train_test','',[],[]}); 

[blockSize,rate_trim_score]  = problemArg('blockSize','rate_trim_score');

% check arguments
if isempty(arg.kernelType) || isempty(arg.r1)
    error('Arguments about kernel function: arg.kernelType and arg.r1 are required.');
end

% load data
if isempty(arg.X) 
    if isempty(arg.trainFile)
        error('Either arg.X or arg.trainFile should be set.');
    else        
        load(arg.trainFile,'X');        
    end    
else
    X = arg.X;
end


flag_train = ismember(arg.flagOutput,...
        {'train','train+','train_test','train_test+'}); 
    % whether need to calculate the scores on train set
    
flag_test = ~isempty(arg.testFile) && ismember(arg.flagOutput,...
        {'test','test+','train_test','train_test+'}); 
    % whether need to calculate the scores on test set
    
flag_putOutSubmodelScore = ismember(arg.flagOutput,{'train+','test+','train_test+'});
    % whether need to put out the scores on the submodels
    
if  flag_test     
    s = load(arg.testFile,'X');
    X_test = s.X;
end


% calculate the scores

sc_train = [];
sc_test = [];
% if fun is a function handle
fun_is_struct = 1;
if isa(fun,'function_handle') % fun is a function handle
    fun_is_struct = 0; 
    if flag_train
        sc_train = calculate_score_0(0);
    end
    if flag_test
        sc_test = calculate_score_0(1);
    end
    assignPutOuts();
    return;
end


% if fun is a struct
  % arguments
num_submodel = size(fun.alpha,2);
 % revise flag_putOutSubmodelScore
flag_putOutSubmodelScore = flag_putOutSubmodelScore && num_submodel>1;

if flag_train
    sc_train = zeros(size(X,1),num_submodel+1);
end
if flag_test
    sc_test = zeros(size(X_test,1),num_submodel+1);
end

  % calculate the scores of the sub_models
for k=1:num_submodel
    alpha1 = fun.alpha(:,k);
    ind1 = fun.ind(:,k);
    b1 = fun.b(k);
    f_handle = @discriminant;    
      % calculate the scores of samples in the training set
    if flag_train  
        sc_train(:,k+1) = calculate_score_0(0);
    end
      % calculate the scores of samples in the test set
    if flag_test
        sc_test(:,k+1) = calculate_score_0(1);  
    end
end

  % calculate the average of the scores (exclude some maximum and minimum
  %     values beforehand)
n_trim = round(rate_trim_score*num_submodel);
if num_submodel==1 % only 1 submodel
    if flag_train
        sc_train(:,1) = sc_train(:,2);
    end
    if flag_test
        sc_test(:,1) = sc_test(:,2);
    end
else
    if flag_train
        sc_train(:,1) = ...
            midmean(sc_train(:,2:num_submodel+1),[n_trim,n_trim],2);
    end
    if flag_test
        sc_test(:,1) = ...
            midmean(sc_test(:,2:num_submodel+1),[n_trim,n_trim],2);
    end
end

% deal with sc_train, sc_test
if ~flag_putOutSubmodelScore
    if flag_train
        sc_train(:,2:num_submodel+1) = [];
    end
    if flag_test
        sc_test(:,2:num_submodel+1) = [];
    end
end

assignPutOuts();


    function assignPutOuts()
        % assign the put out variables
        if flag_train
            varargout{1} = sc_train;
        end
        if flag_test
            if flag_train
                varargout{2} = sc_test;
            else % flag_test == true, flag_train == false
                varargout{1} = sc_test;
            end
        end
    end
 
    function fx = discriminant(X1)
        % the classification function R^q --> R
        % Inputs:
        %   X1: a matrix with each row indicating  a sample of PSM,
        %       i.e. X1 is a matrix with q columns
        % Outputs:
        %   fx: a column vector containing the discriminat function values 
        %         of the input samples;        
        % f(x) = \sum_{i} \alpha_i k(x_i, x) + b;        
        epsilon = 1.0E-6;
        id_alpha = abs(alpha1)>=epsilon; 
        K1 = kernelMatrix_OnceaLine(arg.kernelType,X1',X(ind1(id_alpha),:)',arg.r1,arg.w);
        fx = K1*alpha1(id_alpha) + b1;
    end

    function sc = calculate_score_0(flag_dataset)
        % calculate the scores on the given test set
        % Inputs:
        %   flag_dataset: 0: training set; 1: test set
        % Outputs:
        %   sc: the score
        
        if flag_dataset==0 
            n = size(X,1);            
            dataset = 'X';
        else
            n = size(X_test,1);            
            dataset = 'X_test';
        end
        if ~fun_is_struct
            func_name = 'fun';
        else
            func_name = 'f_handle';
        end
        num_block = ceil(n/blockSize);
        sc = zeros(n,1);
        
        pa = 1;
        for ii = 1:num_block
            pb = min(ii*blockSize,n);  
            sc(pa:pb)= eval(sprintf('phi_fx(%s(%s(pa:pb,:)));',func_name,dataset));             
            pa = pb + 1;
        end
    end

end % end of the function