function h = hash_struct(s,alg)
% Convert an input Struct into a message digest using any of 
%        several common hash algorithms 
% Inputs:
% s:  a struct of length 1,  each field of the struct is  of any of the following classes: 
%        char, uint8, logical, double, single, int8, uint8, 
%        int16, uint16, int32, uint32, int64, uint64 
% alg: hash algorithm, which is one of the following: 
%        'MD2', 'MD5', 'SHA-1', 'SHA-256', 'SHA-384', or 'SHA-512'  
% Outputs:
% h    = hash digest output, in hexadecimal notation 
% 
% USAGE: h = hash_struct(struct('name','John','val',[1 2 3]),'MD5') 
 
names = fieldnames(s);

n = length(names);

if n==0
    h= hash(0,alg);  
    return
end

h_m = [];
for ii=1:n
    if isempty(s.(names{ii}))
        h_i = hash(0,alg);
    else
        h_i = hash(s.(names{ii}),alg);
    end
    % allocate space for h_m
    if ii==1        
        h_m = char(zeros(length(h_i),n));
    end
    h_m(:,ii) = h_i';
end

h = hash(h_m,alg); 

end