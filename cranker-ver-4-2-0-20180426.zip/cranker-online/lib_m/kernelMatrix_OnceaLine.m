function H = kernelMatrix_OnceaLine(kernelName,A,B,arg,w)
% generate a kernel matrix H: H(i,j) = kernel(A(:,i),B(:,j))
% Inputs:
%   kernelName: kernel name:
%     'rbf': RBF (Gaussian) kernel
%           k(x,y) = exp(-|x-y|^2/(2*r1*r1));
%   A, B: two matrix with the same number of rows; each column represents
%       a sample;
%   arg:  Optional, kernel argument; 
%       for RBF kernel, arg is just the value of r1, its default value is
%       1.0; 
%   w: Optional, feature weights, default [];
%       a vector with having length the same as the row number of A and B;
%       if it is set, then before calculating the kernel matrix,
%          the i-th row of matrix A multiply w(i), for all i = 1, 2,...
%       The same operation is done on matrix B;
% Outputs:
%  H: a m-by-n matrix, where m,n are the column number of A and B, resp. 


[k,m] = size(A);
[k2,n] = size(B);
if k~=k2
    error('The number of rows of input matices do not coincide');
end

flag_notSetArg = nargin<4 || isempty(arg); % whether arg is not set
flag_notSetW = nargin<5 || isempty(w);
if ~flag_notSetW && (length(w)~=k)
    warning(['The length of the feature weight, w,'...
        'does not match the row number of the input matrix.']);
    flag_notSetW = 1;
end

%H = zeros(m,n);
switch lower(kernelName)
    case 'rbf'
        if flag_notSetArg
            arg = 1.0;
        end
        coef = 2*arg*arg; 
        
        H = zeros(m,n,'like',A);
        for i = 1:n
            U = bsxfun(@minus,A,B(:,i)); % U is a k-by-m array (the same size as A)
            if ~flag_notSetW
                U = bsxfun(@times,U,w);
            end
            H(:,i) = (exp(-sum(U.*U)/coef))';
        end
    otherwise
        error('do not support %s kernel function',kernelName);
end

end



