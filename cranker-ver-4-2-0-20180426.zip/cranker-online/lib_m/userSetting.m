function userSetting(varargin)
% set arguments 
% Inputs/Operations:
%  If no inputs: 
%     the function produces/assign varables for the 
%    caller with the arguments stored by the function itself; 
%  If inputs is not empty:
%     varargin{1} is a cell array or a struct,
%    1) a cell array: it consists paris of name-value
%    for instance {'index_v', [1.1 1.2 1.3],'indexName','coherence'}
%    2) a struct, it has the following structure
%       nv.field1,
%       nv.field2, ...
%       nv.fieldn;
%    In this case, the function store the arguments indicated by the inputs;  
%     and all the stored arguments are cleared;
%  If user wants to clear the stored arguments, just call userSetting([]);

persistent nv_cell

 
if nargin>0    
    nv_cell{length(nv_cell)+1} = varargin{1}; % store  the settings of  each time by the caller
    return;
end

% assign the valued contained in nv_cell

    % if the inputs are empty
if isempty(nv_cell)
    return;
end

% no inputs: 
%     the function produces/assign varables for the caller with the arguments stored by the function itself; 
for k=1:length(nv_cell)
    nv = nv_cell{k};
    if iscell(nv)        
        for ii=1:floor(length(nv)/2)        
            assignin('caller',nv{2*ii-1},nv{2*ii});
        end
    elseif isstruct(nv)
        field_cell = fieldnames(nv);
        for ii = 1:length(field_cell)
            assignin('caller', field_cell{ii}, nv.(field_cell{ii}));
        end
    end
end

evalin('caller','path_cranker_data = parentDir(path_user_data);');
end