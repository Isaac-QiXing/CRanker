%  call OLCS-Ranker  to   identify the PSMs and test the run time
%  reject certain PSMs to enter into the active set


clear

path_root = 'D:'; % E: 
path_user_data =[path_root filesep 'data_psm'];
path_cranker_result = [path_root filesep 'cranker_result']; % path to save cranker result file
path_train_test_data = [path_root filesep 'data_psm_cross_val'];    % path to save splited train file and test file



%fileName = 'yeast.xlsx'; 
%fileName = 'ups1.xlsx'; 
% fileName = 'tal08.xlsx';
 %fileName = 'tal08_large.xlsx';
 %fileName = 'pbmc_orbit_mips.txt'; 
%fileName = 'pbmc_orbit_nomips.txt'; 
% fileName = 'pbmc_velos_mips.txt';
% fileName = 'pbmc_velos_nomips.txt';

fileName_c = {...
'ups1.xlsx';    
'yeast.xlsx';
'tal08.xlsx';
'tal08_large.xlsx';
'pbmc_orbit_mips.txt'; 
'pbmc_orbit_nomips.txt'; 
'pbmc_velos_mips.txt'; 
'pbmc_velos_nomips.txt';   };

n_dataset = length(fileName_c); % number of datasets

% splitted train files and test files
file_c = cell(3,2,n_dataset); % 3: 3 train sets and 3 test sets
file_c(:,1,1) =...
{'ups1\ups1_train_20171001T204106.mat';
'ups1\ups1_train_20171001T204111.mat';
'ups1\ups1_train_20171001T204119.mat';};

file_c(:,2,1) =...
{'ups1\ups1_test_20171001T204106.mat';
'ups1\ups1_test_20171001T204111.mat';
'ups1\ups1_test_20171001T204119.mat';};

file_c(:,1,2) =...
{'yeast\yeast_train_20171001T203622.mat';
'yeast\yeast_train_20171001T203630.mat';
'yeast\yeast_train_20171001T203635.mat'};

file_c(:,2,2) =...
{'yeast\yeast_test_20171001T203622.mat';
'yeast\yeast_test_20171001T203630.mat';
'yeast\yeast_test_20171001T203635.mat';};

file_c(:,1,3) =...
{'tal08\tal08_train_20171001T204341.mat';
'tal08\tal08_train_20171001T204347.mat';
'tal08\tal08_train_20171001T204352.mat';};

file_c(:,2,3) =...
{'tal08\tal08_test_20171001T204341.mat';
'tal08\tal08_test_20171001T204347.mat';
'tal08\tal08_test_20171001T204352.mat';};

file_c(:,1,4) =...
{'tal08_large\tal08_large_train_20171001T204558.mat';
'tal08_large\tal08_large_train_20171001T204601.mat';
'tal08_large\tal08_large_train_20171001T204603.mat';};

file_c(:,2,4) =...
{'tal08_large\tal08_large_test_20171001T204558.mat';
'tal08_large\tal08_large_test_20171001T204601.mat';
'tal08_large\tal08_large_test_20171001T204603.mat';};

file_c(:,1,5) =...
{'orbit_mips\pbmc_orbit_mips_train_20171001T204937.mat';
'orbit_mips\pbmc_orbit_mips_train_20171001T204942.mat';
'orbit_mips\pbmc_orbit_mips_train_20171001T204946.mat';};

file_c(:,2,5) =...
{'orbit_mips\pbmc_orbit_mips_test_20171001T204937.mat';
'orbit_mips\pbmc_orbit_mips_test_20171001T204942.mat';
'orbit_mips\pbmc_orbit_mips_test_20171001T204946.mat';};

file_c(:,1,6) =...
{'orbit_nomips\pbmc_orbit_nomips_train_20171001T205359.mat';
'orbit_nomips\pbmc_orbit_nomips_train_20171001T205400.mat';
'orbit_nomips\pbmc_orbit_nomips_train_20171001T205403.mat';};

file_c(:,2,6) =...
{'orbit_nomips\pbmc_orbit_nomips_test_20171001T205359.mat';
'orbit_nomips\pbmc_orbit_nomips_test_20171001T205400.mat';
'orbit_nomips\pbmc_orbit_nomips_test_20171001T205403.mat';};

file_c(:,1,7) =...
{'pbmc_velos_mips\pbmc_velos_mips_train_20171009T213712.mat';
'pbmc_velos_mips\pbmc_velos_mips_train_20171009T213716.mat';
'pbmc_velos_mips\pbmc_velos_mips_train_20171009T213718.mat';};

file_c(:,2,7) =...
{'pbmc_velos_mips\pbmc_velos_mips_test_20171009T213712.mat';
'pbmc_velos_mips\pbmc_velos_mips_test_20171009T213716.mat';
'pbmc_velos_mips\pbmc_velos_mips_test_20171009T213718.mat';};

file_c(:,1,8) =...
{'pbmc_velos_nomips\pbmc_velos_nomips_train_20171009T214328.mat';
'pbmc_velos_nomips\pbmc_velos_nomips_train_20171009T214331.mat';
'pbmc_velos_nomips\pbmc_velos_nomips_train_20171009T214334.mat';};

file_c(:,2,8) =...
{'pbmc_velos_nomips\pbmc_velos_nomips_test_20171009T214328.mat';
'pbmc_velos_nomips\pbmc_velos_nomips_test_20171009T214331.mat';
'pbmc_velos_nomips\pbmc_velos_nomips_test_20171009T214334.mat';};



% check 'path_user_data' 
if ~exist(path_user_data,'dir')
    error('The path of user data: %s is not exist. Set the `path_user_data'' in config.m',path_user_data);    
end  



% 0. set parameters
% parameters 

train_test_rate = 2/1; % 1/5; %   
n_initial_cardinality_S = 1000; 
period_clean = 400; 
tol_violating_pair_initial = 0.05;  %5E-2; %5E-3; % tolerance of violating pair
tol_violating_pair_min = 5E-2; 

verbose = 1; 
n_epoch = 1; 
save_result_text = 0;

ratio_max_removed_non_SV = 0.25; 
reject_nonactive_sample = 1;
lambda_mode =   'Fix'; %'SPL';%
n_ite_lambda =  1; 
flag_gpu_on = 0;

mu_safe = 0.3; 

mu_decoy_nonact = 1.0;
mu_target_nonact_predict_correct = 8.0;
mu_target_nonact_predict_wrong = 8.0;




% create an Excel file to put out the results
fileName_excel = [addFileSep(path_user_data) 'result_OLCS_ranker_reject_PSM_8_dataset_20180209.xlsx'];
%fileName_excel = [addFileSep(path_user_data) 'result_CCCP_online' '.xlsx'];

line_no_start = 1;
if ~exist(fileName_excel,'file')
     xlswrite(fileName_excel, datestr(now,30), 'sheet1','A1');
     fprintf(1,'An excel file  %s created.\n',fileName_excel);
else
     fprintf(1,'An excel file %s is found.  \n',fileName_excel);
     [tmp1,tmp2,tmpRaw]=xlsread(fileName_excel); 
     if ~isempty(tmp1) && ~isempty(tmp2)  %  not an empty Excel file
            line_no_start = size(tmpRaw,1)+1;
     end
end       
% 0. put out the parameter names and results field names to Excel file
sheetName = 'sheet1';
 line_no_char = num2str(line_no_start);
% 0.1 put out the inserted fields
col_no_start0 = 'A';
col_no_start  =  col_no_start0;
cell_no_start = [col_no_start line_no_char];
fileInf_title_c = {'timestamp','trainFile','test','result file','score file'};
xlswrite(fileName_excel,fileInf_title_c,'sheet1',cell_no_start);
col_no_start = char(col_no_start + length(fileInf_title_c)); 

% 0.2 put out   results field names to Excel file
result_field_name ={ 'TP-total','FP-total','TP-test','FP-test','ratio','runtime'};  
n_result_field = length(result_field_name);

cell_no_start = [col_no_start line_no_char];
xlswrite(fileName_excel,result_field_name ,sheetName,cell_no_start);
col_no_start = char(col_no_start + n_result_field); 

% 0.3 put out main iteration information field names
ite_field_c = {'obj_val', 'dist', 'n_S', 'n_vary_bound', 'n_reprocess','n_clean','n_clean_sample'};
n_ite_field = length(ite_field_c);
cell_no_start = [col_no_start line_no_char];
xlswrite(fileName_excel,ite_field_c ,sheetName,cell_no_start);
col_no_start = char(col_no_start +  n_ite_field);


flag_printed_par_name = 0; % whether the parameter names has been printed

%%for i_data=1:n_dataset
for i_data=1:1

    % 0. get data file name
    fileName = fileName_c{i_data};
    [dir_f,name_f] = fileparts(fileName);
    rawFileName  = [addFileSep(path_user_data) fileName]; 
    matDataFile = [addFileSep(path_user_data) name_f '.mat'];
    matScoreFile = [addFileSep(path_cranker_result) name_f '_score.mat'];
    
    % set parameter values
    switch name_f
        case 'yeast'
            c1=4.8;
            c3=2.4;
            lambda = 2.4;
            mu_safe_target = Inf;
        case 'ups1'
            c1=0.8;
            c3=0.4;
            lambda = 0.4;
            mu_safe_target = Inf;
        case {'tal08','tal08_large'}
            c1=0.9;
            c3=0.6;
            lambda = 0.6;
            mu_safe_target = Inf;
        otherwise  % for PBMC datasets
            c1=3;
            c3=2.0;
            lambda = 2.0;
            mu_safe_target = mu_safe;
    end
    para_c =  {'c1',c1,'c3',c3,'lambda',lambda,'verbose',verbose, 'n_initial_cardinality_S',n_initial_cardinality_S,...
        'train_test_rate',train_test_rate,'period_clean',period_clean, ...   % 'n_ideal_cardinality',n_ideal_cardinality,...
        'tol_violating_pair_initial',tol_violating_pair_initial,... %%% 'tol_decrease_factor',tol_decrease_factor,
        'tol_violating_pair_min', tol_violating_pair_min,'n_epoch',n_epoch,...
        'mu_safe',mu_safe,'mu_safe_target',mu_safe_target,'ratio_max_removed_non_SV',ratio_max_removed_non_SV...
        'lambda_mode',lambda_mode,'n_ite_lambda',n_ite_lambda,'flag_gpu_on',flag_gpu_on,...
        'reject_nonactive_sample',reject_nonactive_sample,'save_result_text',save_result_text,...
        'mu_decoy_nonact',mu_decoy_nonact ,'mu_target_nonact_predict_correct',mu_target_nonact_predict_correct, ...
        'mu_target_nonact_predict_wrong', mu_target_nonact_predict_wrong};
    userSetting( para_c );
    para_v = struct(para_c{:});
    
    % 0.4 put out the parameter names
    if ~flag_printed_par_name
        %%%para_v = struct(para_c{:});
        name_c = fieldnames(para_v); % parameter names
        name_c = columnVec(name_c)'; % ensure it a row vector
        cell_no_start = [col_no_start line_no_char];
        xlswrite(fileName_excel,name_c,sheetName,cell_no_start);
        line_no_start = line_no_start + 1; % prepare to print parameter values and identified numbers
        flag_printed_par_name = 1; % only printed the parameter names once 
    end    
    % 1. read data
    cranker_read('-w','1', '-v','1','-l','\b\t',rawFileName,matDataFile); % -w: title row
    
%    for i_crossVal = 1:3
     for i_crossVal = 1:1    
        % 2. identify reliable target PSMs           
        trainFile = [path_train_test_data filesep file_c{i_crossVal,1,i_data}];
        testFile = [path_train_test_data filesep file_c{i_crossVal,2,i_data}];        
        
        clock1=tic;
        %  cranker_solve(matDataFile,matScoreFile);        
        cranker_solve('-f','2',trainFile,testFile,matScoreFile);
        % '-f' is set '2': employ the user-supplied training  file and test file
        runtime=  toc(clock1);

        % 3. put out results
        resultFile = cranker_write(matDataFile,matScoreFile);
        
        % 3.0 the hint information 
        [resultFile_path,resultFile_name,~] = fileparts(resultFile);
        resultFile_mat = [resultFile_path filesep resultFile_name '.mat'];
        s_result = load(resultFile_mat,'num');
        ratio=(s_result.num{2}.TP+s_result.num{2}.FP)/(s_result.num{3}.TP+s_result.num{3}.FP);
        if verbose>=2
            fwritef(1, 'TP',s_result.num{3}.TP,'%d', 'FP',s_result.num{3}.FP,'%d','ratio',ratio,'''runtime',runtime,'');
        end
        % 3.1 put out the identified numbers and corresponding parameter values to Excel file
        load(matScoreFile,'ite_inf');
        result_c ={ s_result.num{3}.TP ,s_result.num{3}.FP,s_result.num{2}.TP,s_result.num{2}.FP,ratio,runtime};
        ite_inf_c = {ite_inf.obj_val(end), ite_inf.dist(end), ite_inf.n_S(end), ite_inf.n_vary_bound(end), ite_inf.n_reprocess(end),...
            ite_inf.n_clean(end),ite_inf.n_clean_sample(end)};
        line_no_char = num2str(line_no_start);
        
        % 3.2 print time,trainFile name,testFile name, resultFile name and iteration file name
        col_no_start  =  char(col_no_start0);
        timeStamp = datestr(now, 30);
        fileInf_c = {timeStamp,trainFile,testFile,resultFile,matScoreFile};
        xlswrite(fileName_excel,fileInf_c,sheetName,[col_no_start line_no_char]);
        col_no_start = char(col_no_start + length(fileInf_c));
        % 3.3 % print identified numbers
        xlswrite(fileName_excel,result_c,sheetName, [col_no_start line_no_char] );
        col_no_start = char(col_no_start + n_result_field);
        % 3.4 print briefly iteration information
        xlswrite(fileName_excel,ite_inf_c,sheetName, [col_no_start line_no_char] )
        col_no_start = char(col_no_start +  n_ite_field);
        % 3.5 print parameter values
        para_val =  struct2cell(para_v);
        para_val = columnVec(para_val)'; % ensure a row vector
        xlswrite(fileName_excel,para_val,sheetName,[col_no_start line_no_char]);
        
        line_no_start = line_no_start + 1;
        
    end % end for 
end % end for     
 
 
