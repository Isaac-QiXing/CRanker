% test parameters of the rules to check whether to reject some PSMs to
% enter into training process in order to accelerate the computating 
% date 2018.2.9
 

clear  

%  fileName = 'pbmc_orbit_mips.txt';
%fileName = 'pbmc_orbit_nomips.txt';
%fileName = 'tal08.xlsx';
%fileName = 'yeast.xlsx';
 %fileName = 'tal08_large.xlsx';
%fileName = 'ups1.xlsx';    
%fileName = 'pbmc_velos_mips.txt';
 fileName = 'pbmc_velos_nomips.txt';
path_user_data ='E:\data_psm';  
path_cranker_result = 'E:\cranker_result'; % path to save cranker result file


userSetting({'path_user_data',path_user_data});
[dir_f,name_f] = fileparts(fileName);
dataFile = [addFileSep(path_user_data) name_f '.mat'];

% check 'path_user_data' 
if ~exist(path_user_data,'dir')
    error('The path of user data: %s is not exist. Set the `path_user_data'' in config.m',path_user_data);    
end

% create an Excel file to put out the results
fileName_excel = [addFileSep(path_user_data) 'result_OLCS_ranker_reject_PSM' datestr(now,29) '.xlsx'];
%fileName_excel = [addFileSep(path_user_data) 'result_CCCP_online' '.xlsx'];

line_no_start = 1;
if ~exist(fileName_excel,'file')
     xlswrite(fileName_excel, datestr(now,30), 'sheet1','A1');
     fprintf(1,'An excel file  %s created.\n',fileName_excel);
else
     fprintf(1,'An excel file %s is found.  \n',fileName_excel);
     [tmp1,tmp2,tmpRaw]=xlsread(fileName_excel); 
     if ~isempty(tmp1) && ~isempty(tmp2)  %  not an empty Excel file
            line_no_start = size(tmpRaw,1)+1;
     end
end       


% parameters 

train_test_rate = 2/1; % 1/5; %   
n_initial_cardinality_S = 1000; 
period_clean = 400; 
tol_violating_pair_initial = 0.05;  %5E-2; %5E-3; % tolerance of violating pair
tol_violating_pair_min = 5E-2; 

verbose = 1; 
n_epoch = 1; 
save_result_text = 0;

ratio_max_removed_non_SV = 0.25; 
reject_nonactive_sample = 1;
lambda_mode =   'Fix'; %'SPL';%
n_ite_lambda =  1; 
flag_gpu_on = 0;

mu_safe = 0.3; 
switch name_f
    case 'yeast'
        c1=4.8;
        c3=2.4;
        lambda = 2.4;          
        mu_safe_target = Inf; 
    case 'ups1'
        c1=0.8;
        c3=0.4;
        lambda = 0.4;  
        mu_safe_target = Inf; 
    case {'tal08','tal08_large'}
        c1=0.9;
        c3=0.6;
        lambda = 0.6;
        mu_safe_target = Inf; 
    otherwise  % for PBMC datasets
        c1=3;
        c3=2.0;
        lambda = 2.0;
        mu_safe_target = mu_safe; 
end
%%%


% % %  c3_0= [0.6:0.6:3 ];
% % %    c1_multi=  [1.5, 2,3 ];
% % %  n_c1_multi = length(c1_multi);
% % %  n_c3 = length(c3_0); 
% % %  n_repeat = 1; 
% % %  c1 = kron(kron(c3_0,c1_multi),ones(1,n_repeat));
% % %  c3 = kron(kron(c3_0,ones(1,n_c1_multi)),ones(1,n_repeat)); 
% % %  c1 = num2cell(c1);
% % %  c3 = num2cell(c3);
% % %  lambda = c3;
 
mu_decoy_nonact_v = [4.0  ];
mu_target_nonact_predict_correct_v = [6.0 15.0]; %%[4.0  8.0];
mu_target_nonact_predict_wrong_v  = [4.0  8.0];

len_decoy = length(mu_decoy_nonact_v);
len_correct = length(mu_target_nonact_predict_correct_v);
len_wrong  = length(mu_target_nonact_predict_wrong_v);
mu_decoy_nonact = kron(kron(mu_decoy_nonact_v,ones(1,len_correct) ), ones(1,len_wrong)); 
mu_target_nonact_predict_correct = kron(kron(ones(1,len_decoy),mu_target_nonact_predict_correct_v ), ones(1,len_wrong)); 
mu_target_nonact_predict_wrong = kron(kron(ones(1,len_decoy),ones(1,len_correct) ),mu_target_nonact_predict_wrong_v); 
mu_decoy_nonact = num2cell(mu_decoy_nonact);
mu_target_nonact_predict_correct = num2cell(mu_target_nonact_predict_correct);
mu_target_nonact_predict_wrong = num2cell(mu_target_nonact_predict_wrong);

para_c =  {'c1',c1,'c3',c3,'lambda',lambda,'verbose',verbose, 'n_initial_cardinality_S',n_initial_cardinality_S,... 
    'train_test_rate',train_test_rate,'period_clean',period_clean, ...   % 'n_ideal_cardinality',n_ideal_cardinality,...
    'tol_violating_pair_initial',tol_violating_pair_initial,... %%% 'tol_decrease_factor',tol_decrease_factor, 
    'tol_violating_pair_min', tol_violating_pair_min,'n_epoch',n_epoch,...
    'mu_safe',mu_safe,'mu_safe_target',mu_safe_target,'ratio_max_removed_non_SV',ratio_max_removed_non_SV...
    'lambda_mode',lambda_mode,'n_ite_lambda',n_ite_lambda,'flag_gpu_on',flag_gpu_on,...
    'reject_nonactive_sample',reject_nonactive_sample,'save_result_text',save_result_text,...
    'mu_decoy_nonact',mu_decoy_nonact ,'mu_target_nonact_predict_correct',mu_target_nonact_predict_correct, ...
    'mu_target_nonact_predict_wrong', mu_target_nonact_predict_wrong};

para_v = struct(para_c{:});
name_c = fieldnames(para_v); % parameter names
name_c = columnVec(name_c)'; % ensure it a row vector
n_para_item = length(name_c); % number of parameter fields  


% 0. put out the parameter names and results field names to Excel file
sheetName = 'sheet1';
 line_no_char = num2str(line_no_start);
% 0.1 put out the inserted fields
col_no_start0 = 'A';
col_no_start  =  col_no_start0;
cell_no_start = [col_no_start line_no_char];
xlswrite(fileName_excel,{'timestamp','dataFile','result file','score file'},'sheet1',cell_no_start);
col_no_start = char(col_no_start + 4); 

% 0.2 put out   results field names to Excel file
result_field_name ={ 'TP-total','FP-total','TP-test','FP-test','ratio','runtime'};  
n_result_field = length(result_field_name);

cell_no_start = [col_no_start line_no_char];
xlswrite(fileName_excel,result_field_name ,sheetName,cell_no_start);
col_no_start = char(col_no_start + n_result_field); 

% 0.3 put out main iteration information field names
ite_field_c = {'obj_val', 'dist', 'n_S', 'n_vary_bound', 'n_reprocess'};
n_ite_field = length(ite_field_c);
cell_no_start = [col_no_start line_no_char];
xlswrite(fileName_excel,ite_field_c ,sheetName,cell_no_start);
col_no_start = char(col_no_start +  n_ite_field);

% 0.4 put out the parameter names  
cell_no_start = [col_no_start line_no_char];
xlswrite(fileName_excel,name_c,sheetName,cell_no_start);

line_no_start = line_no_start + 1; % prepare to print parameter values and identified numbers 


% 1. read data
%dataFile = cranker_read(fileName);  
 cranker_read('-l','\b\t',fileName,dataFile); % the interface of cranker_read() is updated
 
for ii=1:length(para_v) 
   tic
    fprintf('parameter %d\n',ii);
    para_s =  para_v(ii);
        
    userSetting(para_s);
    
    % 2. solve the model
    timeStamp = datestr(now,30);
    matScoreFile = [addFileSep(path_cranker_result) name_f '_score_' timeStamp '.mat'];   
    cranker_solve(dataFile,matScoreFile); % -v: verbose
    
    %3. put out results
    resultFile = cranker_write(dataFile,matScoreFile);
        
    % 3.0 the hint information 
    [resultFile_path,resultFile_name,~] = fileparts(resultFile);
    resultFile_mat = [resultFile_path filesep resultFile_name '.mat'];
    s_result = load(resultFile_mat,'num');    
    ratio=(s_result.num{2}.TP+s_result.num{2}.FP)/(s_result.num{3}.TP+s_result.num{3}.FP);
    toc
    runtime=  toc;
    if verbose>=2
        fwritef(1, 'TP',s_result.num{3}.TP,'%d', 'FP',s_result.num{3}.FP,'%d','ratio',ratio,'''runtime',runtime,'');
    end
    % 3.1 put out the identified numbers and corresponding parameter values to Excel file   
    load(matScoreFile,'ite_inf');
    result_c ={ s_result.num{3}.TP ,s_result.num{3}.FP,s_result.num{2}.TP,s_result.num{2}.FP,ratio,runtime};
    ite_inf_c = {ite_inf.obj_val(end), ite_inf.dist(end), ite_inf.n_S(end), ite_inf.n_vary_bound(end), ite_inf.n_reprocess(end)};
    line_no_char = num2str(line_no_start);
    
     % 3.2 print time,trainFile name,testFile name, resultFile name and iteration file name
    col_no_start  =  char(col_no_start0);	
    xlswrite(fileName_excel,{timeStamp,dataFile,resultFile,matScoreFile},sheetName,[col_no_start line_no_char]); 
    col_no_start = char(col_no_start + 4); 
    % 3.3 % print identified numbers
    xlswrite(fileName_excel,result_c,sheetName, [col_no_start line_no_char] ); 
    col_no_start = char(col_no_start + n_result_field);     
    % 3.4 print briefly iteration information
    xlswrite(fileName_excel,ite_inf_c,sheetName, [col_no_start line_no_char] ) 
    col_no_start = char(col_no_start +  n_ite_field);
     % 3.5 print parameter values   
    para_val =  struct2cell(para_s);
    para_val = columnVec(para_val)'; % ensure a row vector 
    xlswrite(fileName_excel,para_val,sheetName,[col_no_start line_no_char]);   
    
    line_no_start = line_no_start + 1;      
end
 