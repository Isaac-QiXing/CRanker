 % test batch algorithm CSVM_CCCP_batch() and CSVM_batch_repeat()

clear
tic
%fileName = 'yeast.xlsx'; 
%fileName = 'ups1.xlsx'; 
%fileName = 'pbmc_orbit_mips.txt'; 
%fileName = 'pbmc_orbit_nomips.txt'; 
 fileName = 'tal08.xlsx';
 %fileName = 'tal08_large.xlsx';
% fileName = 'pbmc_velos_mips.txt';
% fileName = 'pbmc_velos_nomips.txt';
path_user_data ='E:\data_psm';
path_cranker_result = 'E:\cranker_result'; % path to save cranker result file

% check 'path_user_data' 
if ~exist(path_user_data,'dir')
    error('The path of user data: %s is not exist. Set the `path_user_data'' in config.m',path_user_data);    
end  

[dir_f,name_f] = fileparts(fileName);
rawFileName  = [addFileSep(path_user_data) fileName]; 
matDataFile = [addFileSep(path_user_data) name_f '.mat'];
matScoreFile = [addFileSep(path_cranker_result) name_f '_score.mat'];

% 0. set parameters
svm_theta_solver = 'CCCP_batch';  % 'CCCP_online';
maxTrainSize = 16000; % 1000;
num_submodel =5; % 5
max_ite_CCCP_batch = 15;    % 20; 
 flag_low_rank_approx = 0;
train_test_rate =  1/5; % 2/1; %  
verbose = 2; 

%for yeast
% c1=4.8;
% c3=2.4;
% lambda = 2.4;
%  c1=0.9;
% c3=0.6;
% lambda = 0.6;
% c1=1.2;
% c3=1;
% lambda = 1;
% % % % for orbit-mips
c1=0.9;
c3=0.6;
lambda =0.6;

lambda_mode =   'Fix'; %'SPL';%
n_ite_lambda =  1; 
flag_gpu_on = 0;


userSetting( {'path_user_data',path_user_data,'verbose',verbose,  'train_test_rate',train_test_rate,...
    'flag_gpu_on',flag_gpu_on, 'lambda_mode',lambda_mode,'n_ite_lambda',n_ite_lambda,...
    'svm_theta_solver',svm_theta_solver,'maxTrainSize',maxTrainSize,'num_submodel',num_submodel,'max_ite_CCCP_batch',max_ite_CCCP_batch,...
    'c1',c1,'c3',c3,'lambda',lambda,'flag_low_rank_approx',flag_low_rank_approx} );

% % 1. read data
 cranker_read('-w','1', '-v','1','-l','\b\t',rawFileName,matDataFile); % -w: title row
%  
% % 2. identify reliable target PSMs
%cranker_solve('-v','2',matDataFile,matScoreFile); % -v: verbose

% cranker_read('-l','\b\t',fileName,dataFile); % the interface of cranker_read() is updated
 
  trainFile= 'E:\data_psm\tal08_train_20171001T204347.mat';
    testFile='E:\data_psm\tal08_test_20171001T204347.mat';
    cranker_solve('-f','2',trainFile,testFile,matScoreFile); % '-f' is set '2': employ the user-supplied training  file and test file 
 
% 3. put out results
 resultFile = cranker_write(matDataFile,matScoreFile);
 [resultFile_path,resultFile_name,~] = fileparts(resultFile);
    resultFile_mat = [resultFile_path filesep resultFile_name '.mat'];
    s_result = load(resultFile_mat,'num');    
    ratio=(s_result.num{2}.TP+s_result.num{2}.FP)/(s_result.num{3}.TP+s_result.num{3}.FP)
      
 toc
 runtime=  toc;
     Result={ s_result.num{3}.TP ,s_result.num{3}.FP,s_result.num{2}.TP,s_result.num{2}.FP,ratio};        
 timeData={datestr(now,30)};
  Parameter=[c1,c3,lambda,runtime];
  
 if ~exist('e:\myData1.xlsx','file')
    xlswrite('e:\myData1.xlsx',timeData,1,'A1');
    xlswrite('e:\myData1.xlsx',Result,1,'B1');
    xlswrite('e:\myData1.xlsx',Parameter,1,'H1');
 else 
    [tmp1,tmp2,tmpRaw]=xlsread('e:\myData1.xlsx');
 if size(tmp1,1)==0&&size(tmp2,1)==0%�Ƿ��ǿ��ĵ�
        mRowRange='1';
    else
        mRowRange=num2str(size(tmpRaw,1)+1);
    end
    xlswrite('e:\myData1.xlsx',timeData,1,['A' mRowRange]);
    xlswrite('e:\myData1.xlsx',Result,1,['B' mRowRange]);
     xlswrite('e:\myData1.xlsx',Parameter,1,['H' mRowRange]);
 end

 
 
