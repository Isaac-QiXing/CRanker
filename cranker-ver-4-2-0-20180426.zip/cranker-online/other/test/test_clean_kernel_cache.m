function test_clean_kernel_cache()
% test the function clean_kernel_cache

n_sample = 6;

% initialize K0 and IACT
K0 = zeros(n_sample);

IACT = [7 9 3 5];

n_act = length(IACT);
g = 1:n_act;
K0(1:n_act,1:n_act) = g'*g;

K0
n_clean =   clean_kernel_cache([3 4])
K0 
IACT
n_clean =   clean_kernel_cache([4 6 9 5])
K0 
IACT

n_clean =   clean_kernel_cache([7 6 3 5])
K0 
IACT

    function n_clean =  clean_kernel_cache(ind)
        % clean the specified kernel elements in caches
        % Inputs
        %  ind: indices of kernel elements to clear
        % Outputs:
        %  n_clean: number of rows (and colums)��of the caching matrix K0 
        %       cleared;
        
        [lic] = ismember(IACT,ind);
        n_clean = sum(lic);
        if n_clean==0
            return
        end
        if n_clean == length(IACT) % all the elements of K would be clean
            K0 = zeros(size(K0));
            IACT = [];
            return
        end
        n_act = length(IACT);
        if n_act==0 
            return
        end
        
        % update K0 
        v = 1:length(IACT);
        i_act_K0_hold = v(~lic); 
            % indices of columns (and rows) of K0 which should be reserved 

        n_hold = length(i_act_K0_hold);
        
        K0(1:n_hold,1:n_hold) = K0(i_act_K0_hold,i_act_K0_hold);
        K0(1:n_act, n_hold+1:n_act) = 0;
        K0(n_hold+1:n_act,1:n_hold) = 0; 
        
        % update  IACT
        IACT = IACT(i_act_K0_hold);
    end
 
end