function test_clean_working_set()
% test clean working set

n = 10;

% set variables
i_tail = 6;

alpha_v = rand(n,1);
alpha_v(alpha_v<0.5)=0;

g_v = (1:n)';
S = randperm(n)';
S(i_tail+1:n) = 0;

flag_S_A = logical(S.*mod(S,4));
flag_S_B = logical(S.*mod(S,3));

TOL_PRECISION = 1E-14;
n_max_allowed_non_SV=1; 


fwritef(1,'alpha_v',alpha_v','', 'g_v',g_v','', 'S',S','%d\t','i_tail',i_tail,'%d');
fwritef(1,'flag_S_A',int8(flag_S_A)','%d\t','flag_S_B',int8(flag_S_B)','%d\t');


clean_working_set();

disp('After clean...\n');
fwritef(1,'alpha_v',alpha_v','', 'g_v',g_v','', 'S',S','%d\t','i_tail',i_tail,'%d');
fwritef(1,'flag_S_A',int8(flag_S_A)','%d\t','flag_S_B',int8(flag_S_B)','%d\t');


    function n_clean = clean_working_set()
    % remove elements from the working set 
    % CLEAN_WORKING_SET selects certain non-support vectors with highest
    %     gradients for removal;
    % Outputs:
    %   n_clean: number of cleaned elements from the working set
    
        i_S_non_sv = find( abs(alpha_v(S(1:i_tail)))< TOL_PRECISION ); % i.e., a_v(S(1:i_tail)) == 0
            % indices of the working set, S, with a_v(i)==0
        n_S_non_sv = length(i_S_non_sv);    
        n_clean = 0;
        if n_S_non_sv <= n_max_allowed_non_SV            
            return
        end
            
        % remove certain number of elements from the working set with largest gradient 
        [g_v_non_SV, i_i_S] = sort(g_v(S(i_S_non_sv))); % this code can be optimized 
                
        S(i_S_non_sv(i_i_S(n_max_allowed_non_SV+1:n_S_non_sv))) = 0; 
        
        % sort the the non-zero indices of S, and at the same time, update  
        %   flag_S_A, flag_S_B
        i_s = 0; % current index of S of nonzero elements
        for ii=1:i_tail
            % identify the element of S(ii)              
            if S(ii) % S(ii)~=0
                i_s = i_s + 1; 
                if i_s<ii 
                    S(i_s)=S(ii);
                    flag_S_A(i_s) = flag_S_A(ii);
                    flag_S_B(i_s) = flag_S_B(ii);
                end            
            end
        end
        S(i_s+1:i_tail) = 0; 
        flag_S_A(i_s+1:i_tail) = false;
        flag_S_B(i_s+1:i_tail) = false;
        n_clean = i_tail - i_s;  
            % at the end of the above for loop, i_s indicate the number of 
            %   nonzero elements of S
        % update i_tail    
        i_tail = i_s;       
        
    end


end 
