function test_get_kernel_elements()

n_sample = 6;
n_feature = 3;
X_col = rand(n_feature,n_sample);
kernelType = 'rbf';
r1 = 1;
w_feature = ones(n_feature,1);

n_max_cache = 6;
n_initial_chche = 4;
n_step_chche =1;
        
K0 = zeros(n_initial_chche,n_initial_chche); % initilize caching kernel matrix
IACT = []; % IACT: indices of  caching kernel elements

K = kernelMatrix_OnceaLine(kernelType,X_col,X_col,r1,w_feature);

irow = 1;
irow2 = [3 5];
icol = 2:3;
icol2 = [2 4 6];

K
irow
icol
irow2
icol2

K_sub =  get_kernel_element(irow,icol)
IACT
K0 

K_sub =  get_kernel_element(irow2,icol2)
IACT
K0
% K_sub =  get_kernel_element(irow,icol2)
% IACT
% K0 

   function K_sub =  get_kernel_element(irow,icol)
        % calculate the kernel elements  
        
        % Inputs: irow, icol: two COLUMN vectors of indices indicating the submatrix
        %       K_sub = K(irow,icol)
        %    
        % Outputs: 
        %   K_sub:��the required kernel submatrix, with size n_row-by-n_col
        %       with n_row = length(irow); n_col = length(icol)
        
        
        if length(irow)>n_max_cache || length(icol)>n_max_cache
            error('size of active kernel submatrix exceeded the maximum size %d.',n_max_cache);
        end
        
        % IACT : the vector of caching indices of the samples
        % K0:�������caching kernel submatrix
        %       K0(i,j) = K(IACT(i),IACT(j))
        
        % parameters:
        %  n_max_cache: the maximum size of the caching matrix K0
        %  n_initial_chche: the maximum size of the caching matrix K0
        %  n_step_chche: the increased size of the caching matrix once expanded 
        
        % find the the indices of irows and icol which NOT included in IACT
        irow = columnVec(irow);
        icol = columnVec(icol);
        iact_diff = setdiff([irow;icol],IACT); % iact_diff is also a column vector
       
        
        % return the kernel elements if iact_diff is empty
        if isempty(iact_diff) % all the required kernel elements has already been stored in K0
            [~,ind_row] = ismember(irow,IACT);
            [~,ind_col] = ismember(icol,IACT);
            K_sub = K0(ind_row,ind_col);
        end
        
        % expand the size of the caching matrix K0 (if necessary)
        n_act0 = length(IACT); % old length of IACT
        if length(iact_diff) + n_act0 > n_max_cache 
            warning('Caching kernel submatrix exceeded the maximum size %d.',n_max_cache);
            K_sub = kernelMatrix_OnceaLine(kernelType,X_col(:,irow),X_col(:,icol),r1,w_feature);
            return
        end
        
        n_K0 = length(K0);
        n_diff = length(iact_diff);
        if n_diff + n_act0 > n_K0
            n_expand = max(n_act0+n_diff-n_K0,n_step_chche);
            
%             K0_temp = K0;
%             K0 = zeros(n_K0+n_expand);
%             K0(1:n_K0,1:n_K0)=K0_temp;
            K0 = [K0 zeros(n_K0,n_expand); zeros(n_expand,n_K0+n_expand)];
        end
        
        % update IACT                
        IACT = [IACT; iact_diff];
            
        % calculate the elements of the required submatrix 
        K_diff = kernelMatrix_OnceaLine(kernelType,X_col(:,IACT),X_col(:,iact_diff),r1,w_feature);
        
        % store the newly calculated kernel elements in K0
        n_act1 = n_act0 + n_diff; % new length of IACT 
        K0(1:n_act1, n_act0+1:n_act1) = K_diff; 
        K0(n_act0+1:n_act1,1:n_act0) = K0(1:n_act0,n_act0+1:n_act1)';
         % return the required kernel elements          
        [~,ind_row] = ismember(irow,IACT);
        [~,ind_col] = ismember(icol,IACT);
        K_sub = K0(ind_row,ind_col);
        
    end    

end