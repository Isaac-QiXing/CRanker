% test_userSetting 

train_test_rate=    problemArg('train_test_rate')

userSetting({'train_test_rate',5,'name','Job'});

train_test_rate=    problemArg('train_test_rate')

