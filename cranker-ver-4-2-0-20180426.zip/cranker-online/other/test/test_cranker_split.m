% test_cranker_split.m

n = 77;
m =3; 

data = struct('input',rand(n,m),'output',(1:n)','input_feature',{{'xcorr','delta_cn'}});

dataFile = 'mydataFile.mat';
save(dataFile,'data');


%train_test_rate = 2/1;
train_test_rate = [3 1 1];
[trainFile,testFile]  = cranker_split(dataFile,'train_test_rate',train_test_rate);