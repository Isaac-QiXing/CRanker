% test_parameterSet.m

% var_output = parameterSet('-v','1','-c1','1.2','yeast');
%var_output = parameterSet('-c1','yeast');

% var_output = parameterSet('-v','1','-y','1.2','yeast')
 
% var_output = parameterSet('-v','-y','1.2','yeast') 

% var_output = parameterSet('-v','1','c1','1.3','yeast')
 
% var_output = parameterSet('-v','1','c1','1.3','-c2','3.5','yeast')
% var_output = parameterSet('-v','1','-c1','1.3','-c2')
 var_output
[verbose c1] = problemArg('verbose','c1')