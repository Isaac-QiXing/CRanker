% test gpuArray_v

a = zeros(3,3);
b = 1:3;

[a1,b1]=gpuArray_v(1,a,b);
