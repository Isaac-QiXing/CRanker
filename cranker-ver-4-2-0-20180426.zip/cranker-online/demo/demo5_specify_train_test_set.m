% demo4_cranker.m
% A demo  to illustrate how to specify train set and test set 
% 


clear
 
 rawFileName = 'yeast.xlsx';  % data file containing records of PSMs
%fileName = 'ups1.xlsx';  
 

matDataFile = 'myPSMdata.mat'; % Mat file name to store PSM records
matScoreFile = 'myPSMscore.mat'; % Mat file name to store the scores of identified PSMs

   
   

% 1. read PSM records
cranker_read(rawFileName,matDataFile);   

 % 2. split the train set and test set 
 [trainFile,testFile] = cranker_split(matDataFile);
%    % or specify the train file and test file manually 
%  trainFile= 'E:\data_psm\tal08_train_20171001T204352.mat';
%  testFile='E:\data_psm\tal08_test_20171001T204352.mat';

% 3. solve the model
cranker_solve('-f','2',trainFile,testFile,matScoreFile); 
% '-f' is set '2': employ the user-supplied training  file and test file 
   

% 4. put out identified PSM records 
 resultFile = cranker_write(matDataFile,matScoreFile);
