% demo_cranker.m
% A demo to call 
%       cranker_read, cranker_solve and cranker_write

clear
 
 rawFileName = 'yeast.xlsx';  % data file containing records of PSMs
%fileName = 'ups1.xlsx';  
 

matDataFile = 'myPSMdata.mat'; % Mat file name to store PSM records
matScoreFile = 'myPSMscore.mat'; % Mat file name to store the scores of identified PSMs

 
% 1. read PSM records
cranker_read(rawFileName,matDataFile); 
%cranker_read('-l','\b\t',fileName,dataFile); %-l: seperation character of different attribute values of PSM record 
%cranker_read('-w','1','-v','3','-e','0','-n','0',rawFileName,matDataFile); % -w: title row, -v: verbose

% 2. identify reliable target PSMs
cranker_solve(matDataFile,matScoreFile); 
% cranker_solve('-v','2',matDataFile,matScoreFile); % -v: verbose
% cranker_solve('-t','3',matDataFile,matScoreFile); %-t: train/test rate, 
% cranker_solve('-f','0',matDataFile,matScoreFile); %-f: whether split train and test 
% cranker_solve('-c2','0.1',matDataFile,matScoreFile);
% cranker_solve('-z','600','-m','3',matDataFile,matScoreFile);%-z: maximum train size; -m: number of submodels
%  cranker_solve('-x','0','-f','0','-v','3',matDataFile,matScoreFile); %-x: relateive feature weight of xcorr and deltacn

% 3. put out identified PSM records 
 resultFile = cranker_write(matDataFile,matScoreFile);
% cranker_write('-fdr','0.04','-v','0',matDataFile,matScoreFile);
 
 
