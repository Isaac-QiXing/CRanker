% demo2_cranker.m
% A demo to call 
%       cranker_read, cranker_solve and cranker_write
% and illustrate parameter settings

clear
 
 rawFileName = 'yeast.xlsx';  % data file containing records of PSMs
%fileName = 'ups1.xlsx';  
 

matDataFile = 'myPSMdata.mat'; % Mat file name to store PSM records
matScoreFile = 'myPSMscore.mat'; % Mat file name to store the scores of identified PSMs

% 1. read PSM records
cranker_read(rawFileName,matDataFile); 
 
% 2. identify reliable target PSMs
% * users can also set 'flag_split_train_test' by '-f' parameter 
% e.g. Identify PSMs with 'flag_split_train_test==0' as follows
% cranker_solve('-f','0',matDataFile,matScoreFile); %-f: whether split train and test     
%
% * users can also set 'train_test_rate' by '-t' parameter 
% e.g. Identify PSMs with c1=4.8, c3=2.4, lambda=2.4, flag_split_train_test==1, train_test_rate==2 as follows
 cranker_solve('-c1','4.8', '-c3','2.4', '-lambda','2.4', '-f','1','-t','2',matDataFile,matScoreFile); %-t: train/test rate,
 
% 3. put out identified PSM records 
 resultFile = cranker_write(matDataFile,matScoreFile);
  
 
