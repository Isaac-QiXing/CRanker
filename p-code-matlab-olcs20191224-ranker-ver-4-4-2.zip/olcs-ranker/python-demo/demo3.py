import matlab.engine
eng = matlab.engine.start_matlab()


rawFileName = 'yeast.xlsx'

matDataFile = 'myPSMdata.mat'
matScoreFile = 'myPSMscore.mat'

eng.olcs_read(rawFileName,matDataFile,nargout=0)

eng.olcs_solve(matDataFile,matScoreFile,nargout=0)
eng.olcs_solve('-s','CCCP_online','-muSafe','0.3','-muSafeTarget','Inf',matDataFile,matScoreFile,nargout=0)
resultFile = eng.olcs_write(matDataFile,matScoreFile,nargout=0)


eng.quit()