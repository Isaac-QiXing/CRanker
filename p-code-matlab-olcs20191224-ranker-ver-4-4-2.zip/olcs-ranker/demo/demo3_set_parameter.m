% demo3_cranker.m
% A demo to call 
%       olcs_read, olcs_solve and olcs_write
% and illustrate parameter settings:  set the solver
% 


clear
 
 rawFileName = 'yeast.xlsx';  % data file containing records of PSMs
%fileName = 'ups1.xlsx';  
 
userSetting({'path_user_data','D:\data_psm'}); % set the path of dataset files

matDataFile = 'myPSMdata.mat'; % Mat file name to store PSM records
matScoreFile = 'myPSMscore.mat'; % Mat file name to store the scores of identified PSMs
 

% 1. read PSM records
olcs_read(rawFileName,matDataFile); 
 
% 2. identify reliable target PSMs
olcs_solve(matDataFile,matScoreFile); 

% 2. identify reliable target PSMs

% * users can also set solve by  '-s' parameter: 
%    set solver and corresponding classification model    
    % 'CCCP_online': employ online algorithm   to solve the CS-Ranker model 
    % 'CCCP_batch': employ the batch-CS-Ranker  to solve the CS-Ranker model 
    % 'primal_SVM��: employ the built-in solver to solve the C-Ranker model.
    %   Note that primal_SVM solves a different model  
    
% e.g. set the solver as 'CCCP_online',   '-muSafe' parameter as 0.3, and
% '-muSafeTarget' parameter as Inf
olcs_solve('-s','CCCP_online','-muSafe','0.3','-muSafeTarget','Inf',matDataFile,matScoreFile); 

% e.g. set the solver as 'CCCP_online',   '-fixTrainTestSet' parameter as 0
% and '-fixTrainOrder' parameter as 0
%olcs_solve('-s','CCCP_online','-fixTrainTestSet','0','-fixTrainOrder','0',matDataFile,matScoreFile); 

% e.g. set the solver as 'primal_SVM', '-tolFun' parameter as 0.2 
%olcs_solve('-s','primal_SVM','-tolFun','0.2',matDataFile,matScoreFile); 
 
% 3. put out identified PSM records 
 resultFile = olcs_write(matDataFile,matScoreFile);