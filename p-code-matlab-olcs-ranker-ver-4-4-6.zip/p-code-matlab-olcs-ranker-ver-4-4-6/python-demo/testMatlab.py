import matlab.engine
import sys
eng = matlab.engine.start_matlab()



rawFileName = 'C:/Users/ZhonghangXia/mysite/media/'+sys.argv[1]
matDataFile = 'myPSMdata.mat'
matScoreFile = 'myPSMscore.mat'

eng.olcs_read(rawFileName,matDataFile,nargout=0)

eng.olcs_solve(matDataFile,matScoreFile,nargout=0)

resultFile = eng.olcs_write(matDataFile,matScoreFile,nargout=0)

eng.quit()
