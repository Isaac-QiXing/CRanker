def main(rawFileName):
# Inputs:
#   rawFileName: string, name of the raw data file
# Outputs:
#   flag: 0: succeed to run; 1: fails to run
#   logFile: string, name of a text file, containing the outputs information
#           and the  error information (if any)
#   logFile_error: a string of the text file name, containing the error message
#       output by the function (if any); if there is no error message, 
#        the file will not be created; 
#   resultFile: string, name a text file, containing the identified PSM records 
#       if flag==1, then retultFile = ''; 

    import matlab.engine
    eng = matlab.engine.start_matlab()

    matDataFile = 'myPSMdata.mat'
    matScoreFile = 'myPSMscore.mat'
    resultFile = ''
    t_c = eng.olcs_read(rawFileName,matDataFile,nargout=3)
    flag, logFile, logFile_error = t_c
    #  flag:  0: succeed to run; 1: fails to run    
    #  logFile:  a string of the text file name, containing the message
    #   of the outputs to the command line 
    # logFile_error: a string of the text file name, containing the error message
    #       output by the function (if any); if there is no error message, 
    #    the file will not be created; 

    if flag:  #  0: succeed to run; 1: fails to run
        eng.quit()
        return flag, logFile, logFile_error, resultFile
        
    t_c = eng.olcs_solve('-auto','1',matDataFile,matScoreFile,nargout=3)
    flag, logFile, logFile_error = t_c
    if flag:  #  0: succeed to run; 1: fails to run
        eng.quit()
        return flag, logFile, logFile_error, resultFile
       
    t_c  = eng.olcs_write(matDataFile,matScoreFile,nargout=4)
            # there are 4 outputs, the 1st is the name of the resultFile 
    resultFile, flag, logFile, logFile_error = t_c             
    eng.quit()
    return flag, logFile, logFile_error, resultFile

import sys
import os.path
 
rawFileName = 'C:/Users/ZhonghangXia/mysite/media/'+sys.argv[1]
#rawFileName = 'yeast-demo.txt'
#rawFileName = 'D:\\data_psm\\yeast-demo-incorrect-format-for-test.txt' 

flag, logFile, logFile_error, resultFile = main(rawFileName)

# print information in the logFile
if os.path.isfile(logFile):
    fid = open(logFile,'rt')
    print(fid.read())
    fid.close()


if flag and os.path.isfile(logFile_error):
    # print information in the logFile_error
    fid = open(logFile_error,'rt')
    print(fid.read())
    fid.close()

if flag:  # error occurs 
    fileName_mat = 'myPSMdata_result_000.mat'
    fileName_txt = 'myPSMdata_result_000.txt'
    f= open(fileName_mat,"w+")
    f.close
    f= open(fileName_txt,"w+")
    f.close
    

 
     

  
