import matlab.engine
eng = matlab.engine.start_matlab()

version = eng.olcs_version()

eng.quit()