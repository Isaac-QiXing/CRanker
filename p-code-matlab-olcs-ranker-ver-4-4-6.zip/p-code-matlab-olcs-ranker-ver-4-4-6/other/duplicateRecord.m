function iteInf =  duplicateRecord(recordFileName,file_output,arg)
% duplicate a specified group of records   multiple times and merged them
% as a unique file
% Inputs:
%   recordFileName: a string, txt file name of a the records, each row is a record
%   file_output: a string, txt file name of the output file consisting of
%       the merged records;
%       If the file already exist, it would be overwritten;
%   arg: a struct of parameters
%     .duplicateNumber: a positive integer, number of copying the original records
%     .titleRow: Optional, a positive integer, indexing the title row,
%       e.g. titleRow = 3: then the 3rd row is title row, and the first two
%       rows will be ignored; default 1;

debug_on = 1;

if ~exist(recordFileName,'file')
    error('Do not find the specifed data file %s.',recordFileName);
end

fid_out = fopen(file_output,'w');
fid = fopen(recordFileName,'r');

arg = completeArg(arg,{'duplicateNumber','titleRow'},{1,1});

i_total = 0; % counts the number of total record lines printed out

for i_dup = 1:arg.duplicateNumber
    if debug_on
        fprintf(1,'i_duplicate: %d / %d \n',i_dup,arg.duplicateNumber);
    end
    i_file_input = 0; % counts the number of the recods in the input file
    while ~feof(fid)
        if  i_file_input==0
            if i_dup ==1
                %  read the header line
                record_cell = textscan(fid,'%[^\r\n]',1,'HeaderLines',arg.titleRow-1);                
            else % i_dup >1
                record_cell = textscan(fid,'%[^\r\n]',1,'HeaderLines',arg.titleRow);
                % read the row of arg.titleRow,  omit the first arg.titleRow number of rows
            end
            if ~isempty(record_cell) && ~isempty(record_cell{1})
                % write  the record  to the new file
                fprintf(fid_out,'%s\n',record_cell{1}{1});
                i_file_input = i_file_input +1;
                i_total = i_total + 1;
            end
        else
            %record_cell = textscan(fid,'%[^\r\n]',1);
            record_s = fgetl(fid);
            if ~isempty(record_s)
                fprintf(fid_out,'%s\n',record_s);
                i_file_input = i_file_input +1;
                i_total = i_total + 1;
            end
        end
        %         if ~isempty(record_cell) && ~isempty(record_cell{1})
        %             % write  the record  to the new file
        %             fprintf(fid_out,'%s\n',record_cell{1}{1});
        %             i_file_input = i_file_input +1;
        %             i_total = i_total + 1;
        %         end
        
        if debug_on
            if mod(i_file_input,5000) == 1
                fprintf(1,'i_file_input:   %d \n',i_file_input);
            end
        end
    end
    if i_dup==1
        n_file_input = i_file_input-1; % number of the records in the input file
    end
    frewind(fid); % Move file position indicator to beginning of open file
    
end % end loop of i_dup

fclose(fid);
fclose(fid_out);

iteInf.n_file_input = n_file_input;
iteInf.n_total = i_total-1;
end