% test_cal_q_value()

n_row = 10;
n_col = 2;

n_max = n_row;
score = randi(n_max,n_row,n_col);

%y = randi([0,1],n_row,1);
%y(y==0) = -1;
y = ones(n_row,1);
ind_decoy = unique(randi(n_max,round(n_row*0.3),1));
y(ind_decoy)=-1;

q_value = cal_q_value(score,y);

% score
%[score_sort ind]= sort(score,1,'descend')
y_ind = y(ind)

% q_value
score = [score q_value]
