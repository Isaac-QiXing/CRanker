
for i=1:5
%a = rand(1);
str = timeStampNow()
 
end
