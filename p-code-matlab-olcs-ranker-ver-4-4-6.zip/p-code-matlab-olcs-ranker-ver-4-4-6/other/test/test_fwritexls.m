% test_fwritexls.m

fwritexls('test.xls',{'name','val'},rand(5,2));
fwritexls('test.xls',{'name','val'},rand(5,2),'F2');
fwritexls('test.xls',{'name','val'},rand(5,2),'A2','test1');
arg = 'v';
fwritexls('test.xls',{'name','val'},rand(5,2),'A2','test2',arg);
  %arg = 'v'; indicates  the labels are arranged vertically;
fwritexls('test.xls',{'name','val'},rand(5,2),'A1','test3',...
    {'name','val'},rand(5,2),'F2','test3');
arg = 'hv';
fwritexls('test.xls',{'name','val'},rand(5,2),'A1','test4',...
    {'name','val'},rand(5,2),'F2','test4',arg);
  %  arg = 'hv'; indicates  the labels 'name', 'val' are arranged
  %    1) horizontally for the first group of data
  %    2) vertically for the second group of data;