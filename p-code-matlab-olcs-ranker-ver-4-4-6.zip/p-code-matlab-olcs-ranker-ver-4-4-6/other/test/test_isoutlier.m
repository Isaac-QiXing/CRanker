%test_isoutlier
A = [57 59 60 100 59 58 57 58 300 61 62 60 62 58 57]

TF = isoutlier(A)