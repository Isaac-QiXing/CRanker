% test_memory_spy

memory_spy(0);

n = 1000;
n_repeat = 10;
A = rand(n);
for ii=1:n_repeat
B = A*A+1;
end
clear('A','B');

%%%for i=1:n
    
mem = memory_spy(1)

memory_spy(0);
for ii=1:n_repeat
	a = sin(ii);
end
mem2 = memory_spy(1)


memory_spy(0);
A = rand(n);
mem3 = memory_spy(1)


