% test_swap.m

v = 1:5;
a = 3;
b =2;
v1 = swap(v,a,b)
 
 