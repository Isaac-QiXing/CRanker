% test_completeArg.m

arg = [];
train_test_rate = 3;
flag_standardize = 5;

arg = completeArg(arg,{'train_test_rate','flag_standardize'},...
    {train_test_rate,flag_standardize});

fwritef(1,'arg',arg,'');
