function test_rule_converge_bound()
% test rule_converge_bound

clear all

threshold_vary_bound_ratio = 0.1;
n = 20;
A_v = zeros(n,1);
B_v = ones(n,1);

n_target = n/2;
i_act_target = unique(randi(n,n_target,1));


for ii=n/2:-1:1
    
    i_act_target = unique([i_act_target; randi(n)]);
    n_vary = floor(ii/2);
    if n_vary>0
        i_act_vary = i_act_target(end-n_vary+1:end);
        % change certain number of bounds
        A_v(i_act_vary) = ~A_v(i_act_vary);
        B_v(i_act_vary) = ~B_v(i_act_vary);
    end
    flag_converge = rule_converge_bound();
    
   
    fprintf(1,'%d\t len_act_vary: %d\t flag: %d\n ',ii, length(i_act_vary),flag_converge);
end

  function flag_converge = rule_converge_bound()
        %����check whether the bounds of A_v and B_v of the active set 
        %     varies little in recent iterations
        
       
        
        n_statistic_radius = 10; % number of recent iterations to be calculated
        
        persistent i_act_old A_act_old B_act_old i_call v_vary_bound;
             % i_act_old:  array, the active indices of targets in the previous call 
             % A_act_old:  array, the lower bounds of active indices of targets in the previous call 
             % B_act_old:  array the upper bounds of active indices of targets in the previous call 
             % v_vary_bound: array of length  n_statistic_radius, consisting of the number
             %      of varied bounds in recent calls  
             % i_call = mod(i_ite,n_statistic_radius)
             %              with i_ite the number of call
        
        if isempty(i_act_old)
            i_act_old = i_act_target;
            A_act_old = A_v(i_act_target);
            B_act_old = B_v(i_act_target);
            i_call = 0; 
            v_vary_bound = inf(n_statistic_radius,1); 
                % initialize the number of varied bounds as positive infty 
            flag_converge = 0;            
            return
        end
        
        
        % calculate the number of changed lower bounds and upper bounds on 
        %   the indices i_act_old
        i_call = mod(i_call,n_statistic_radius)+1;
            % the value of i_call locates between [1,n_statistic_radius]
        v_vary_bound(i_call) = nnz(A_act_old ~= A_v(i_act_old)) ...
            + nnz(B_act_old ~= B_v(i_act_old));
        

        
        % determine whether the stable rule satisfied
        % Rule 1: 
        %   if the total number of the bounds A_v and B_v that changes in 
        %       recent iterations less than a threshold, then 
        %       the iterations are viewed as stable;
        flag_converge = mean(v_vary_bound) < threshold_vary_bound_ratio*length(i_act_old); 
        
        %%%
%         i_call
%         
%         A_v_t = A_v'
%         B_v_t = B_v'
%         i_act_vary_t = i_act_vary'
%         i_act_old_t = i_act_old'
%         A_act_old_t = A_act_old'
%         A_v_act_old = A_v(i_act_old)'
%         nnz_A =  nnz(A_act_old ~= A_v(i_act_old))
%         nnz_B =  nnz(B_act_old ~= B_v(i_act_old))
%         v_vary_bound_ite = v_vary_bound'
% %         n_vary_bound = mean(v_vary_bound)
        %%%
                % update the variables
        i_act_old = i_act_target;
        A_act_old = A_v(i_act_target);
        B_act_old = B_v(i_act_target);
  end
end