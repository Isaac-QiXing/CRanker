% test02_accuracyIndex
 
load('../demo/temp20171001.mat');
 
 [~,ind] = sort(indexRank,'descend');
 
 A = [indexRank(ind),y(ind)];
 
 v = find(y(ind)==-1,30);
 
 n_v = length(v);
 
 fdr_v = 2*((1:n_v)'-1)./ (v-1);
 
 B = [v, fdr_v];
 
 
 
 
 
 