% test_crossValidateIndex
n_total_sample = 10;
k = 3;

index = crossValidateIndex(n_total_sample,k);
fwritef(1,'index',index,'');

n_max = 8;
index = crossValidateIndex(n_total_sample,k,n_max);
fwritef(1,'index',index,'');

flag_equal_fold_size = 1;
index = crossValidateIndex(n_total_sample,k,n_max,flag_equal_fold_size);
fwritef(1,'index',index,'');