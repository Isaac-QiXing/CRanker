%test_dist_normal_cone_box

n = 3; 
A_v = zeros(n,1);
B_v = ones(n,1);
alpha_v = [0;1;0.2];

g = [-1;2;0.1];
d1 = dist_normal_cone_box(g,alpha_v, A_v,B_v);

g = [1;2;0];
d2 = dist_normal_cone_box(g,alpha_v, A_v,B_v);

g = [-1; -2; 0];
d3 = dist_normal_cone_box(g,alpha_v, A_v,B_v);

alpha_v = [0; 2; 0.2 ];
g = [-1; -1; 0];
d4 = dist_normal_cone_box(g,alpha_v, A_v,B_v);

alpha_v = [-eps;1; 0.2 ];
g = [-1; 1; 0];
d5 = dist_normal_cone_box(g,alpha_v, A_v,B_v);


d1 
d2
 d3
 d4
 d5