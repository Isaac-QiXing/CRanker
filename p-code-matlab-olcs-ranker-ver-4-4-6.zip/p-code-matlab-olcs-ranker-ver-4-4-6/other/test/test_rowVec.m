% test_rowVec

v = [1, 3,5];
v= rowVec(v)

v = [1, 3,5]';
v= rowVec(v)

v = [];
v= rowVec(v)

v = rand(3,2);
v= rowVec(v)

v = num2cell(rand(3,2));
v= rowVec(v)