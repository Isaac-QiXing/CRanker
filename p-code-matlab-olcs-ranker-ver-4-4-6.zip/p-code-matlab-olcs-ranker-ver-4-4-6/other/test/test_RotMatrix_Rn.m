clear 
clc

% test_RotMatrix_Rn
 alpha = 4*pi/3;
 
 u = [0, 0,1]';
 v = [0,1,0]';

%R = RotMatrix(alpha, u, v)
R = RotMatrix_Rn( u, v);

R_multi_u = R*u

R = RotMatrix_Rn( v,u);

R_multi_v = R*v


 u = [0, 0,1]';
 v = [0,1,1]';

 R = RotMatrix_Rn( u, v);

R_multi_u = R*u/norm(u)

R = RotMatrix_Rn( v,u);

R_multi_unit_v = R*v/norm(v) 

 u = [0, 0,1]';
 v = [0,-1,1]';

 R = RotMatrix_Rn( u, v);

R_multi_u = R*u

R = RotMatrix_Rn( v,u);

R_multi_norm_v = R*v/norm(v)
