%

fplot(@sigmoid_scale,[-5,5]);