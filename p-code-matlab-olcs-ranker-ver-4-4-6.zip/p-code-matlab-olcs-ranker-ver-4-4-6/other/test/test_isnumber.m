% test_isnumber.m

val_c = {'10.2',[],'','-1','+1','ABC23',NaN};

for ii = 1:length(val_c)
    val = val_c{ii};
    ii 
    disp(val);
    fprintf(1,'%d\n',isnumber(val));
end