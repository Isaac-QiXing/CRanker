% test_split_train_test.m

n = 77;
m =3; 

data = struct('input',rand(n,m),'output',(1:n)','input_feature',{{'xcorr','delta_cn'}});

dataFile = 'mydataFile.mat';
trainFile = 'mytrainFile.mat';
testFile = 'mytestFile_1.mat';

save(dataFile,'data');

 arg =struct('train_test_rate',2/1,'flag_standardize',1);
 [ind_train,ind_test] = split_train_test(dataFile,trainFile,testFile,arg);

testFile = {'mytestFile_1.mat';'mytestFile_2.mat'};
arg =struct('train_test_rate',[3 1 1],'flag_standardize',1);
[ind_train,ind_test] = split_train_test(dataFile,trainFile,testFile,arg);


