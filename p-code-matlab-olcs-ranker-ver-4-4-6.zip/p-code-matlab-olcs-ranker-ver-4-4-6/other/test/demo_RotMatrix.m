 % demo_RotMatrix
 alpha = 4*pi/3;
 
 u = [0, 0,1];
 v = [0,1,0];

R = RotMatrix(alpha, u, v)