% test_parameterSet.m

% var_output = parameterSet('-v','1','-cdecoy','1.2','yeast');
%var_output = parameterSet('-cdecoy','yeast');

% var_output = parameterSet('-v','1','-y','1.2','yeast')
 
% var_output = parameterSet('-v','-y','1.2','yeast') 

% var_output = parameterSet('-v','1','cdecoy','1.3','yeast')
 
% var_output = parameterSet('-v','1','cdecoy','1.3','-ctarget','3.5','yeast')
% var_output = parameterSet('-v','1','-cdecoy','1.3','-ctarget')
 var_output
[verbose cdecoy] = problemArg('verbose','cdecoy')