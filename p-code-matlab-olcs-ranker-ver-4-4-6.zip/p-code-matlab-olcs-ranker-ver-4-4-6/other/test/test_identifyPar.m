% test_identifyPar.m
[par_new output_var_c] = identifyPar( '-v', 3, '-cdecoy',1.0)

[par_new output_var_c] = identifyPar( '-v', '2', '-cdecoy','1.0', 'data.txt' )

[par_new output_var_c] = identifyPar( '-v', 3, '-cdecoy',1.0, 1:3,'data.txt' )



