% test_userSetting 
clc
clear all

r1=    problemArg('r1')

userSetting({'r1',5,'name','Job'});

userSetting({'r1',4,'name','2nd'});

r1 =    problemArg('r1')

userSetting([]);

r1 =    problemArg('r1')

userSetting({'r1',3,'name','Job'});

r1 =    problemArg('r1')    