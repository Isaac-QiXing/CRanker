% test_enzNC

 peptide_str = 'K.HSLAESIQNAGILQSYWENEIPQKK.S';
[enz]= enzNC(peptide_str)