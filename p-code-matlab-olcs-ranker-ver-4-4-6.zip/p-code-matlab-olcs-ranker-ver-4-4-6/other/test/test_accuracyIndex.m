clc
clear

% test_accuracyIndex
n = 30; 

n_negative = floor(n/4); 
indexRank = rand(n,1);

y = ones(n,1);
i_negative = randperm(n,n_negative);
y(i_negative) = -1;
%arg.fdr = 0.2;
arg.fdr = [0.05 0.20];
 
 
% case 1. a single group of scores 
% digestIndex = [];
% digestIndex = randi([0,2],n,1);
% 
% 
% [acc,num,id] = accuracyIndex(indexRank,y,digestIndex,arg);

% % case 2. multiple group cases: indexRank is a cell array
% n_group = 2;
% digestIndex = [];
% %digestIndex = randi([0,2],n,1); 
%    % set indexRank and arg.index
% len_group_v = floor(power(0.5,1:n_group)*n); % size of each group
% len_group_sum_v = [0, cumsum(len_group_v)];
% index_v = columnVec(randperm(n));
%   
% indexRank = cell(n_group,1);
% 
% arg.index = cell(n_group,1);
% arg.accuracyMerge = 1; 
% for ii=1:n_group
%     indexRank{ii} = rand(len_group_v(ii),1);
%     arg.index{ii} = index_v(len_group_sum_v(ii)+1:len_group_sum_v(ii+1));
% end
% [acc,num,id] = accuracyIndex(indexRank,y,digestIndex,arg);

% case 3. multiple group cases: indexRank is a matrix
n_group = 2;
n_method = 2;
digestIndex = [];
digestIndex = randi([0,2],n,1); 
   % set indexRank and arg.index
len_group_v = floor(power(0.5,1:n_group)*n); % size of each group
len_group_sum_v = [0, cumsum(len_group_v)];
index_v = columnVec(randperm(n));
  
%indexRank = cell(n_group,1);
indexRank = rand(n,n_method);

arg.index = cell(n_group,1);
arg.accuracyMerge = 1; 
for ii=1:n_group
    %indexRank{ii} = rand(len_group_v(ii),1);
    arg.index{ii} = index_v(len_group_sum_v(ii)+1:len_group_sum_v(ii+1));
end
[acc,num,id] = accuracyIndex(indexRank,y,digestIndex,arg);

