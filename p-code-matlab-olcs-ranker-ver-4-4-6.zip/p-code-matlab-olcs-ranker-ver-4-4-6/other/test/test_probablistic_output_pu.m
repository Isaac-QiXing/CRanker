%test_probablistic_output_pu.m
clear
clc

i_case = 1;

switch i_case
    
    case 1 % test case 1
        n_sample = 50000;
        %fx_min = -10;
        %fx_max = 10;
        fx_v = randn(n_sample,1);
        label_v = randi([0,1],n_sample,1);
        label_v(label_v ==0) = -1;

        flag_pos_correct = 1; 
        %flag_pos_correct = 0; 
        prob_v  = probablistic_output_pu(fx_v,label_v,flag_pos_correct);
        
    case 2
    % test case 2
    fx_v = [ 1 .2 .3  .1 .3  -.2 -2 1 3 3  -5:4  ];
    label_v  = [ones(1,10), ones(1,10)*(-1)];
    flag_pos_correct = 1;          
    prob_v  = probablistic_output_pu(fx_v,label_v,flag_pos_correct);
    prob_v
    
       case 3
    % test case 2
    fx_v = -1.0*[ 1 .2 .3  .1 .3  -.2 -2 1 3 3  -5:4  ];
    label_v  = [-1*ones(1,10), ones(1,10)];
    flag_pos_correct = 0;          
    prob_v  = probablistic_output_pu(fx_v,label_v,flag_pos_correct);
    prob_v
end 
