% a demo to use C-Ranker, with fixed training set and test set 

%   fileName = 'yeast.xlsx';
fileName = 'ups1.xlsx'; 
  % if you have set path_user_data in config.m,
  %   do not need to include the directory here, just set the name of the
  %   file,   such as 'yeast.csv';

global   fileName_just_read globe_dataFile globe_trainFile globe_testFile

% fileName_just_read:    the fileName of that just read 
% globe_dataFile: data file name that just been read
% globe_trainFile: train file name that just been splitted
% globe_testFile: test file name that just been splitted 
 

% set paths

% path_user_data ='E:\data_psm';
% path_cranker_result = 'E:\cranker_result'; % path to save cranker result file
path_user_data ='D:\data_psm';
path_cranker_result = 'D:\cranker_result'; % path to save cranker result file

  % check 'path_user_data' 
if ~exist(path_user_data,'dir')
    error('The path of user data: %s is not exist. Set the `path_user_data'' in config.m',path_user_data);    
end  

[dir_f,name_f] = fileparts(fileName);
rawFileName  = [addFileSep(path_user_data) fileName]; 
dataFile = [addFileSep(path_user_data) name_f '.mat'];
timestamp = datestr(now,30);
matScoreFile = [addFileSep(path_cranker_result) name_f '_score_' timestamp '.mat'];
  

% 0. set parameters

% for ups1
train_test_rate = 2/1;    
%%%n_ideal_cardinality_v= 2000;  % this parameter has been removed
n_initial_cardinality_S = 2000; %2000
period_clean = 400; 
verbose = 2; %  4;  
n_epoch = 1; 

mu_safe = 0.3; 
mu_safe_target =  Inf; %mu_safe;
ratio_max_removed_non_SV = 0.25; 

tol_violating_pair_initial = 0.05;  %5E-2; %5E-3; % tolerance of violating pair
% %%tol_decrease_factor = 0.4;
tol_violating_pair_min = 5E-2; 

 cdecoy=2.0;
 ctarget=0.5;
 lambda = 0.5;
 
lambda_mode =   'Fix'; %'SPL';%
n_ite_lambda =  3; 

userSetting( {'path_user_data',path_user_data,'verbose',verbose,  'train_test_rate',train_test_rate,'n_initial_cardinality_S',n_initial_cardinality_S,...
    'period_clean',period_clean, 'tol_violating_pair_initial',tol_violating_pair_initial,... %%% 'tol_decrease_factor',tol_decrease_factor, 
    'flag_gpu_on',flag_gpu_on ...
    'tol_violating_pair_min', tol_violating_pair_min,'n_epoch',n_epoch,...
    'mu_safe',mu_safe,'mu_safe_target',mu_safe_target,'ratio_max_removed_non_SV',ratio_max_removed_non_SV...
    'lambda_mode',lambda_mode,'n_ite_lambda',n_ite_lambda,...
    'cdecoy',cdecoy,'ctarget',ctarget,'lambda',lambda} );

 
% 1. read data
if isempty(fileName_just_read) || ~strcmpi(fileName_just_read,fileName)
    % if there is no file name has been read in previous or the data file
    % name changed in this calling

    % read data
    %dataFile = cranker_read(fileName);
    cranker_read(rawFileName,dataFile); % the interface of cranker_read() is updated

   % split the train set and test set 
   [trainFile,testFile] = cranker_split(dataFile);
     
    % update the global variables
    fileName_just_read = fileName;
    globe_dataFile = dataFile;
    globe_trainFile = trainFile;
    globe_testFile = testFile;    
else
    % get the data file names from the global variables (using the same train file and test file)
    dataFile = globe_dataFile;
    trainFile = globe_trainFile;
    testFile = globe_testFile;
    fprintf(1,'Warning: Using the train file and test file input in previous calling.\n');
    fprintf(1, 'If want to split the new train file and test file,');
    fprintf(1,'  run ``clear'' in command window to clear the global varibles which stores the train and test file names.\n');
    
end

s_train = load(trainFile,'sizeX');
s_test = load(testFile,'sizeX');
fwritef(1,'# training samples',s_train.sizeX(1),'%d','# testing samples',s_test.sizeX(1),'%d' );
 
% 2. solve the model
cranker_solve('-f','2',trainFile,testFile,matScoreFile); % '-f' is set '2': employ the user-supplied training  file and test file 

% 3. put out results
resultFile = cranker_write(dataFile,matScoreFile);

% 4.1 the hint information
[resultFile_path,resultFile_name,~] = fileparts(resultFile);
resultFile_mat = [resultFile_path filesep resultFile_name '.mat'];
s_result = load(resultFile_mat,'num');
fprintf(1,'You may find the results in file: %s\n',resultFile);
ratio=(s_result.num{2}.TP+s_result.num{2}.FP)/(s_result.num{3}.TP+s_result.num{3}.FP);
fwritef(1, 'TP',s_result.num{3}.TP,'%d', 'FP',s_result.num{3}.FP,'%d',...
    'TP on test set', s_result.num{2}.TP,'%d',  'FP on test set',s_result.num{2}.FP,'%d','ratio',ratio,'');

% 4.2 test TP==0 phenomenoen
if hint_TP_0(resultFile) ==1
    fprintf(1,'Have Not identified correct PSM. Algorithm stuck at a bad local minimum.\n');
end

