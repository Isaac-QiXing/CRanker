% demo_cranker.m
% test the performance of a trained determination function on two different
%    test sets

clear

%%%%
global data_file_global train_file_global hint_file_global test_file_global 
%%%%


% fileName = 'yeast.xlsx'; 
fileName = 'ups1.xlsx'; 
%fileName = 'pbmc_velos_mips.txt'; 
  % if you have set path_user_data  
  %   do not need to include the directory here, just set the name of the
  %   file,   such as 'yeast.csv';

path_user_data ='D:\data_psm';
path_cranker_result = 'D:\cranker_result'; % path to save cranker result file

% check 'path_user_data' 
if ~exist(path_user_data,'dir')
    error('The path of user data: %s is not exist. Set the `path_user_data'' in config.m',path_user_data);    
end  

[dir_f,name_f] = fileparts(fileName);
rawFileName  = [addFileSep(path_user_data) fileName]; 
matDataFile = [addFileSep(path_user_data) name_f '.mat'];
matScoreFile = [addFileSep(path_cranker_result) name_f '_score.mat'];

% 0. set parameters

    
train_test_rate = [0.6,0.2,0.2]; %%2/1;    
%%%n_ideal_cardinality_v= 1000;  % 300;
n_initial_cardinality_S = 2000; 
period_clean = 400; 
tol_violating_pair_initial = 0.05;  %5E-2; %5E-3; % tolerance of violating pair
% %%tol_decrease_factor = 0.4;
tol_violating_pair_min = 5E-2; 

verbose = 1; 
n_epoch = 1; 
mu_safe = 0.2; 
mu_safe_target =  inf; % for ups1 % 0.2; % for yeast
ratio_max_removed_non_SV = 0.25; 

cdecoy=1.2;
ctarget=0.4;
lambda = 0.6;

lambda_mode =   'SPL';%'Fix'; %
n_ite_lambda =  8; 

userSetting( {'path_user_data',path_user_data,'verbose',verbose,  'train_test_rate',train_test_rate,'n_initial_cardinality_S',n_initial_cardinality_S,...
    'period_clean',period_clean, 'tol_violating_pair_initial',tol_violating_pair_initial,... %%% 'tol_decrease_factor',tol_decrease_factor, 
    'tol_violating_pair_min', tol_violating_pair_min,'n_epoch',n_epoch,...
    'mu_safe',mu_safe,'mu_safe_target',mu_safe_target,'ratio_max_removed_non_SV',ratio_max_removed_non_SV...
    'lambda_mode',lambda_mode,'n_ite_lambda',n_ite_lambda,...
    'cdecoy',cdecoy,'ctarget',ctarget,'lambda',lambda} );

 
    %hint_file name 
% 1. read data
cranker_read('-w','1', '-v','1',  rawFileName,matDataFile); % -w: title row

%cranker_read('-w','1', '-v','3','-e','0','-n','0',rawFileName,matDataFile); % -w: title row

% 2. split train set and two test sets

 % split 3 files, file_c{1} containes  the train set, file_c{2} contains
 % the hint set, file_c{3} contains the test set
[trainFile,testFile] = cranker_split(matDataFile,'train_test_rate',train_test_rate);

data_file_global = matDataFile;
train_file_global = trainFile;
hint_file_global = testFile{1}; 
test_file_global = testFile{2};

% 3. identify reliable target PSMs 
cranker_solve('-f','2',trainFile,testFile{2},matScoreFile); % '-f' is set '2': employ the user-supplied training  file and test file 
    % matScoreFile contains the scores of training set, hint set  and test set  

    
%%load(matDataFile,'data');
%%load(matScoreFile,'score_train','score_test','ind_train','ind_test'); % score_test is a column cell array
%%acc = accuracy(data.output,{score_train; score_test{:}}, {ind_train; ind_test{:}});

% 3. put out results
%%fwritef(1,'acc',acc,'');
 cranker_write(matDataFile,matScoreFile);
% cranker_write('-fdr','0.04','-v','0',matDataFile,matScoreFile);