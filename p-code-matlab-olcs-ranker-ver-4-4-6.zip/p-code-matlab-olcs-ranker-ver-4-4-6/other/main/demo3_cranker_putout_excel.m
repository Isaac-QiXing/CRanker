% a demo to use C-Ranker, print the identified numbers and parameters to
% Excel file



clear all 

%  fileName = 'pbmc_orbit_mips.txt';
%fileName = 'pbmc_orbit_nomips.txt';
fileName = 'tal08.xlsx';
%fileName = 'yeast.xlsx';
 %fileName = 'tal08_large.xlsx';
%fileName = 'ups1.xlsx';    
%fileName = 'pbmc_velos_mips.txt';
 %fileName = 'pbmc_velos_nomips.txt';
path_user_data ='E:\data_psm';  
path_cranker_result = 'E:\cranker_result'; % path to save cranker result file


userSetting({'path_user_data',path_user_data});
[dir_f,name_f] = fileparts(fileName);
dataFile = [addFileSep(path_user_data) name_f '.mat'];

% check 'path_user_data' 
if ~exist(path_user_data,'dir')
    error('The path of user data: %s is not exist. Set the `path_user_data'' in config.m',path_user_data);    
end

% create an Excel file to put out the results
fileName_excel = [addFileSep(path_user_data) 'result_CCCP_online' datestr(now,29) '.xlsx'];
%fileName_excel = [addFileSep(path_user_data) 'result_CCCP_online' '.xlsx'];

line_no_start = 1;
if ~exist(fileName_excel,'file')
     xlswrite(fileName_excel, datestr(now,30), 'sheet1','A1');
     fprintf(1,'An excel file  %s created.\n',fileName_excel);
else
     fprintf(1,'An excel file %s is found.  \n',fileName_excel);
     [tmp1,tmp2,tmpRaw]=xlsread(fileName_excel); 
     if ~isempty(tmp1) && ~isempty(tmp2)  %  not an empty Excel file
            line_no_start = size(tmpRaw,1)+1;
     end
end       

% for ups1
train_test_rate = 2/1;   
%%%n_ideal_cardinality= 2000;  %  % this parameter has been removed
n_initial_cardinality_S =1000; %2000
period_clean = 400; 
verbose = 1; %  4;  
n_epoch =1; 

mu_safe = 0.3; 
 mu_safe_target = Inf; 
%mu_safe_target = Inf; 
ratio_max_removed_non_SV = 0.25; 
lambda_mode =   'Fix'; %'SPL';%
n_ite_lambda =  4; 
  c3_0=0.6;
c1_multi=1.5;
%  c3_0= [0.6:0.6:3 ];
%    c1_multi=  [1.5, 2,3 ];
 %c1_multi=  [1.5,2];
 n_repeat =1;
 
 %repeat_v = 1:n_repeat;
 n_c1_multi = length(c1_multi);
 n_c3 = length(c3_0);
 
 repeat_v = kron(ones(1,n_c1_multi*n_c3),1:n_repeat);
 cdecoy = kron(kron(c3_0,c1_multi),ones(1,n_repeat));
 ctarget = kron(kron(c3_0,ones(1,n_c1_multi)),ones(1,n_repeat));
 
 repeat = num2cell(repeat_v);
 cdecoy = num2cell(cdecoy);
 ctarget = num2cell(ctarget);
 lambda = ctarget;
 
 % % for yeast
% n_ideal_cardinality_v= 1000;  % 300;
% n_initial_cardinality_S = 800; 
% n_max_allowed_non_SV = 200; 
% verbose = 2; 
% n_epoch = 2; 
% mu_safe = 0.2; 
% mu_safe_target = 0.2; 
% ratio_max_removed_non_SV = 0.25; 
% cdecoy=3;
% ctarget=1.5;
% lambda = 1.2;

flag_gpu_on = 0;
tol_violating_pair_initial = 0.05;  %5E-2; %5E-3; % tolerance of violating pair
% %%tol_decrease_factor = 0.4;
tol_violating_pair_min = 5E-2; 

para_c =  {'repeat',repeat,'cdecoy',cdecoy,'ctarget',ctarget,'lambda',lambda,'verbose',verbose, 'n_initial_cardinality_S',n_initial_cardinality_S,... 
    'train_test_rate',train_test_rate,'period_clean',period_clean, ...   % 'n_ideal_cardinality',n_ideal_cardinality,...
    'tol_violating_pair_initial',tol_violating_pair_initial,... %%% 'tol_decrease_factor',tol_decrease_factor, 
    %%%'flag_gpu_on',flag_gpu_on ...
    'tol_violating_pair_min', tol_violating_pair_min,'n_epoch',n_epoch,...
    'mu_safe',mu_safe,'mu_safe_target',mu_safe_target,'ratio_max_removed_non_SV',ratio_max_removed_non_SV...
    'lambda_mode',lambda_mode,'n_ite_lambda',n_ite_lambda,'flag_gpu_on',flag_gpu_on};

para_v = struct(para_c{:});
name_c = fieldnames(para_v); % parameter names
name_c = columnVec(name_c)'; % ensure it a row vector
n_para_item = length(name_c); % number of parameter fields  


% 0. put out the parameter names and results field names to Excel file
sheetName = 'sheet1';
 line_no_char = num2str(line_no_start);
% 0.1 put out the inserted fields
col_no_start0 = 'A';
col_no_start  =  col_no_start0;
cell_no_start = [col_no_start line_no_char];
xlswrite(fileName_excel,{'timestamp','trainFile','testFile','result file','score file'},'sheet1',cell_no_start);
col_no_start = char(col_no_start + 5); 

% 0.2 put out   results field names to Excel file
result_field_name ={ 'TP-total','FP-total','TP-test','FP-test','ratio','runtime'};  
n_result_field = length(result_field_name);

cell_no_start = [col_no_start line_no_char];
xlswrite(fileName_excel,result_field_name ,sheetName,cell_no_start);
col_no_start = char(col_no_start + n_result_field); 

% 0.3 put out main iteration information field names
ite_field_c = {'obj_val', 'dist', 'n_S', 'n_vary_bound', 'n_reprocess'};
n_ite_field = length(ite_field_c);
cell_no_start = [col_no_start line_no_char];
xlswrite(fileName_excel,ite_field_c ,sheetName,cell_no_start);
col_no_start = char(col_no_start +  n_ite_field);

% 0.4 put out the parameter names  
cell_no_start = [col_no_start line_no_char];
xlswrite(fileName_excel,name_c,sheetName,cell_no_start);

line_no_start = line_no_start + 1; % prepare to print parameter values and identified numbers 


% 1. read data
%dataFile = cranker_read(fileName);  
 cranker_read('-l','\b\t',fileName,dataFile); % the interface of cranker_read() is updated
 
for ii=1:length(para_v) 
   tic
    fprintf('parameter %d\n',ii);
    para_s =  para_v(ii);
        
    userSetting(para_s);
    
    % 2. split the train set and test set 
%  [trainFile,testFile] = cranker_split(dataFile);
 trainFile= 'E:\data_psm\tal08_train_20171001T204352.mat';
    testFile='E:\data_psm\tal08_test_20171001T204352.mat';
%        trainFile= 'E:\data_psm\pbmc_velos_mips_train_20171009T213716.mat';
%    testFile='E:\data_psm\pbmc_velos_mips_test_20171009T213716.mat';
   % pbmc_orbit_nomips_test_20171001T205359
  % yeast_test_20171001T203622 
    % 3. solve the model
    timeStamp = datestr(now,30);
    matScoreFile = [addFileSep(path_cranker_result) name_f '_score_' timeStamp '.mat'];
    cranker_solve('-f','2',trainFile,testFile,matScoreFile); % '-f' is set '2': employ the user-supplied training  file and test file 
   
    % 4. put out results
    %%%% resultFile = cranker_write(dataFile,trainFile,score_train,testFile,score_test);
    resultFile = cranker_write(dataFile,matScoreFile);
        
    % 4.0 the hint information 
    [resultFile_path,resultFile_name,~] = fileparts(resultFile);
    resultFile_mat = [resultFile_path filesep resultFile_name '.mat'];
    s_result = load(resultFile_mat,'num');    
    ratio=(s_result.num{2}.TP+s_result.num{2}.FP)/(s_result.num{3}.TP+s_result.num{3}.FP);
    toc
    runtime=  toc;
    if verbose>=2
        fwritef(1, 'TP',s_result.num{3}.TP,'%d', 'FP',s_result.num{3}.FP,'%d','ratio',ratio,'''runtime',runtime,'');
    end
    % 4.1 put out the identified numbers and corresponding parameter values to Excel file   
    load(matScoreFile,'ite_inf');
    result_c ={ s_result.num{3}.TP ,s_result.num{3}.FP,s_result.num{2}.TP,s_result.num{2}.FP,ratio,runtime};
    ite_inf_c = {ite_inf.obj_val(end), ite_inf.dist(end), ite_inf.n_S(end), ite_inf.n_vary_bound(end), ite_inf.n_reprocess(end)};
    line_no_char = num2str(line_no_start);
    
     % 4.2 print time,trainFile name,testFile name, resultFile name and iteration file name
    col_no_start  =  char(col_no_start0);	
    xlswrite(fileName_excel,{timeStamp,trainFile,testFile,resultFile,matScoreFile},sheetName,[col_no_start line_no_char]); 
    col_no_start = char(col_no_start + 5); 
    % 4.3 % print identified numbers
    xlswrite(fileName_excel,result_c,sheetName, [col_no_start line_no_char] ); 
    col_no_start = char(col_no_start + n_result_field);     
    % 4.3 print briefly iteration information
    xlswrite(fileName_excel,ite_inf_c,sheetName, [col_no_start line_no_char] ) 
    col_no_start = char(col_no_start +  n_ite_field);
     % 4.5 print parameter values   
    para_val =  struct2cell(para_s);
    para_val = columnVec(para_val)'; % ensure a row vector 
    xlswrite(fileName_excel,para_val,sheetName,[col_no_start line_no_char]);   
    
    line_no_start = line_no_start + 1;      
end
 