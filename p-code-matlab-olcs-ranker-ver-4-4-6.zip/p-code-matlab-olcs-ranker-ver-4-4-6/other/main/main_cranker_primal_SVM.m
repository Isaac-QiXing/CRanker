% a demo to call C-Ranker (solve the primal-SVM based classification model
% by built-in Matlab solver)

clear

path_user_data ='E:\data_psm';
path_cranker_result = 'E:\cranker_result'; % path to save cranker result file

n_dataset = 8; % number of datasets

%fileName = 'yeast.xlsx'; 
%fileName = 'ups1.xlsx'; 
% fileName = 'tal08.xlsx';
 %fileName = 'tal08_large.xlsx';
 %fileName = 'pbmc_orbit_mips.txt'; 
%fileName = 'pbmc_orbit_nomips.txt'; 
% fileName = 'pbmc_velos_mips.txt';
% fileName = 'pbmc_velos_nomips.txt';

fileName_c = {...
'ups1.xlsx';    
'yeast.xlsx';
'tal08.xlsx';
'tal08_large.xlsx';
'pbmc_orbit_mips.txt'; 
'pbmc_orbit_nomips.txt'; 
'pbmc_velos_mips.txt'; 
'pbmc_velos_nomips.txt';   };


% splitted train files and test files
file_c = cell(3,2,n_dataset); % 3: 3 train sets and 3 test sets
file_c(:,1,1) =...
{'E:\data_psm_cross_val\ups1\ups1_train_20171001T204106.mat';
'E:\data_psm_cross_val\ups1\ups1_train_20171001T204111.mat';
'E:\data_psm_cross_val\ups1\ups1_train_20171001T204119.mat';};

file_c(:,2,1) =...
{'E:\data_psm_cross_val\ups1\ups1_test_20171001T204106.mat';
'E:\data_psm_cross_val\ups1\ups1_test_20171001T204111.mat';
'E:\data_psm_cross_val\ups1\ups1_test_20171001T204119.mat';};

file_c(:,1,2) =...
{'E:\data_psm_cross_val\yeast\yeast_train_20171001T203622.mat';
'E:\data_psm_cross_val\yeast\yeast_train_20171001T203630.mat';
'E:\data_psm_cross_val\yeast\yeast_train_20171001T203635.mat'};

file_c(:,2,2) =...
{'E:\data_psm_cross_val\yeast\yeast_test_20171001T203622.mat';
'E:\data_psm_cross_val\yeast\yeast_test_20171001T203630.mat';
'E:\data_psm_cross_val\yeast\yeast_test_20171001T203635.mat';};

file_c(:,1,3) =...
{'E:\data_psm_cross_val\tal08\tal08_train_20171001T204341.mat';
'E:\data_psm_cross_val\tal08\tal08_train_20171001T204347.mat';
'E:\data_psm_cross_val\tal08\tal08_train_20171001T204352.mat';};

file_c(:,2,3) =...
{'E:\data_psm_cross_val\tal08\tal08_test_20171001T204341.mat';
'E:\data_psm_cross_val\tal08\tal08_test_20171001T204347.mat';
'E:\data_psm_cross_val\tal08\tal08_test_20171001T204352.mat';};

file_c(:,1,4) =...
{'E:\data_psm_cross_val\tal08_large\tal08_large_train_20171001T204558.mat';
'E:\data_psm_cross_val\tal08_large\tal08_large_train_20171001T204601.mat';
'E:\data_psm_cross_val\tal08_large\tal08_large_train_20171001T204603.mat';};

file_c(:,2,4) =...
{'E:\data_psm_cross_val\tal08_large\tal08_large_test_20171001T204558.mat';
'E:\data_psm_cross_val\tal08_large\tal08_large_test_20171001T204601.mat';
'E:\data_psm_cross_val\tal08_large\tal08_large_test_20171001T204603.mat';};

file_c(:,1,5) =...
{'E:\data_psm_cross_val\orbit_mips\pbmc_orbit_mips_train_20171001T204937.mat';
'E:\data_psm_cross_val\orbit_mips\pbmc_orbit_mips_train_20171001T204942.mat';
'E:\data_psm_cross_val\orbit_mips\pbmc_orbit_mips_train_20171001T204946.mat';};

file_c(:,2,5) =...
{'E:\data_psm_cross_val\orbit_mips\pbmc_orbit_mips_test_20171001T204937.mat';
'E:\data_psm_cross_val\orbit_mips\pbmc_orbit_mips_test_20171001T204942.mat';
'E:\data_psm_cross_val\orbit_mips\pbmc_orbit_mips_test_20171001T204946.mat';};

file_c(:,1,6) =...
{'E:\data_psm_cross_val\orbit_nomips\pbmc_orbit_nomips_train_20171001T205359.mat';
'E:\data_psm_cross_val\orbit_nomips\pbmc_orbit_nomips_train_20171001T205400.mat';
'E:\data_psm_cross_val\orbit_nomips\pbmc_orbit_nomips_train_20171001T205403.mat';};

file_c(:,2,6) =...
{'E:\data_psm_cross_val\orbit_nomips\pbmc_orbit_nomips_test_20171001T205359.mat';
'E:\data_psm_cross_val\orbit_nomips\pbmc_orbit_nomips_test_20171001T205400.mat';
'E:\data_psm_cross_val\orbit_nomips\pbmc_orbit_nomips_test_20171001T205403.mat';};

file_c(:,1,7) =...
{'E:\data_psm_cross_val\pbmc_velos_mips\pbmc_velos_mips_train_20171009T213712.mat';
'E:\data_psm_cross_val\pbmc_velos_mips\pbmc_velos_mips_train_20171009T213716.mat';
'E:\data_psm_cross_val\pbmc_velos_mips\pbmc_velos_mips_train_20171009T213718.mat';};

file_c(:,2,7) =...
{'E:\data_psm_cross_val\pbmc_velos_mips\pbmc_velos_mips_test_20171009T213712.mat';
'E:\data_psm_cross_val\pbmc_velos_mips\pbmc_velos_mips_test_20171009T213716.mat';
'E:\data_psm_cross_val\pbmc_velos_mips\pbmc_velos_mips_test_20171009T213718.mat';};

file_c(:,1,8) =...
{'E:\data_psm_cross_val\pbmc_velos_nomips\pbmc_velos_nomips_train_20171009T214328.mat';
'E:\data_psm_cross_val\pbmc_velos_nomips\pbmc_velos_nomips_train_20171009T214331.mat';
'E:\data_psm_cross_val\pbmc_velos_nomips\pbmc_velos_nomips_train_20171009T214334.mat';};

file_c(:,2,8) =...
{'E:\data_psm_cross_val\pbmc_velos_nomips\pbmc_velos_nomips_test_20171009T214328.mat';
'E:\data_psm_cross_val\pbmc_velos_nomips\pbmc_velos_nomips_test_20171009T214331.mat';
'E:\data_psm_cross_val\pbmc_velos_nomips\pbmc_velos_nomips_test_20171009T214334.mat';};



% check 'path_user_data' 
if ~exist(path_user_data,'dir')
    error('The path of user data: %s is not exist. Set the `path_user_data'' in config.m',path_user_data);    
end  



% 0. set parameters
svm_theta_solver = 'primal_SVM';  %'CCCP_batch';  % 'CCCP_online';
tolFun_cranker = 0.1;  
maxTrainSize = 16000; % 1000;100; %
num_submodel = 5; %2;
 flag_low_rank_approx = 1;  % whether to employ low rank approximation of the kernel matrix 
 tol_low_rank_approx = 0.01; 
train_test_rate =  2/1; % 1/500; %   
verbose = 2; 

 
cdecoy=1.0;
ctarget=1.0;
 
flag_gpu_on = 0;
save_result_text = 0; % do not save result to text files 

userSetting( {'path_user_data',path_user_data,'verbose',verbose,  'train_test_rate',train_test_rate,...
    'flag_gpu_on',flag_gpu_on, ... %%%'lambda_mode',lambda_mode,'n_ite_lambda',n_ite_lambda,...
    'svm_theta_solver',svm_theta_solver,'maxTrainSize',maxTrainSize,'num_submodel',num_submodel,...
    'cdecoy',cdecoy,'ctarget',ctarget,  'flag_low_rank_approx',flag_low_rank_approx, 'tol_low_rank_approx', tol_low_rank_approx,...
    'tolFun_cranker',   tolFun_cranker,'save_result_text',save_result_text} );


%%for i_data=1:n_dataset
for i_data=1:1

    % 0. get data file name
    fileName = fileName_c{i_data};
    [dir_f,name_f] = fileparts(fileName);
    rawFileName  = [addFileSep(path_user_data) fileName]; 
    matDataFile = [addFileSep(path_user_data) name_f '.mat'];
    matScoreFile = [addFileSep(path_cranker_result) name_f '_score.mat'];
    
        
    % 1. read data
    cranker_read('-w','1', '-v','1','-l','\b\t',rawFileName,matDataFile); % -w: title row
    
%     for i_crossVal = 1:3
    for i_crossVal = 1:1
    
        % 2. identify reliable target PSMs    
       
        trainFile = file_c{i_crossVal,1,i_data};
        testFile = file_c{i_crossVal,2,i_data};
        
        tic
          cranker_solve(matDataFile,matScoreFile);        
        %cranker_solve('-f','2',trainFile,testFile,matScoreFile); % '-f' is set '2': employ the user-supplied training  file and test file
        runtime=  toc;

        % 3. put out results
        resultFile = cranker_write(matDataFile,matScoreFile);
        [resultFile_path,resultFile_name,~] = fileparts(resultFile);
        resultFile_mat = [resultFile_path filesep resultFile_name '.mat'];
        s_result = load(resultFile_mat,'num');
        s_train = load(matScoreFile,'model');
        ratio=(s_result.num{2}.TP+s_result.num{2}.FP)/(s_result.num{3}.TP+s_result.num{3}.FP);
        nnz_x = nnz(s_train.model.alpha);

        TP=s_result.num{3}.TP;
        FP=s_result.num{3}.FP;
        fwritef(1,'TP',TP,'%d',  'FP',FP, '%d',  'runtime',  runtime,'%.1f\t',  'ratio',ratio, '%.4f');

        Result={ s_result.num{3}.TP ,s_result.num{3}.FP,s_result.num{2}.TP,s_result.num{2}.FP,ratio, nnz_x, runtime};
        timeData={datestr(now,30)};
        train_test_file_c = {trainFile,testFile};
        Parameter=[cdecoy,ctarget,tolFun_cranker,maxTrainSize,num_submodel,flag_low_rank_approx,tol_low_rank_approx,train_test_rate];

        resultFile = ['e:\result_cranker_time_20180131', '.xlsx'];
        if ~exist(resultFile,'file')
            xlswrite(resultFile,timeData,1,'A1'); % time stamp
            xlswrite(resultFile,train_test_file_c,1,'B1'); % train and test file
            xlswrite(resultFile,Result,1,'D1');
            xlswrite(resultFile,Parameter,1,'L1');
        else
            [tmp1,tmp2,tmpRaw]=xlsread(resultFile);
            if size(tmp1,1)==0&&size(tmp2,1)==0%�Ƿ��ǿ��ĵ�
                mRowRange='1';
            else
                mRowRange=num2str(size(tmpRaw,1)+1);
            end
            xlswrite(resultFile,timeData,1,['A' mRowRange]);
            xlswrite(resultFile,train_test_file_c,1,['B',mRowRange] ); % train and test file
            xlswrite(resultFile,Result,1,['D' mRowRange]);
            xlswrite(resultFile,Parameter,1,['L' mRowRange]);
        end
    end % end for 
end % end for     
 
 
