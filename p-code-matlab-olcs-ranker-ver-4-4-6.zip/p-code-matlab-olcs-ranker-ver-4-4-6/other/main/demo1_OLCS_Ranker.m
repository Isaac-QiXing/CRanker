% demo_cranker.m
% test cranker_read, cranker_solve, cranker_write

clear
tic
 fileName = 'yeast.xlsx'; 
%fileName = 'ups1.xlsx'; 
%fileName = 'pbmc_orbit_mips.txt'; 
% fileName = 'pbmc_velos_nomips.txt'; 
  % if you have set path_user_data  
  %   do not need to include the directory here, just set the name of the
  %   file,   such as 'yeast.csv';

% path_user_data ='E:\data_psm';
% path_cranker_result = 'E:\cranker_result'; % path to save cranker result file

path_user_data ='D:\data_psm';
path_cranker_result = 'D:\cranker_result'; % path to save cranker result file

% check 'path_user_data' 
if ~exist(path_user_data,'dir')
    error('The path of user data: %s is not exist. Set the `path_user_data'' in config.m',path_user_data);    
end  

[dir_f,name_f] = fileparts(fileName);
rawFileName  = [addFileSep(path_user_data) fileName]; 
matDataFile = [addFileSep(path_user_data) name_f '.mat'];
matScoreFile = [addFileSep(path_cranker_result) name_f '_score.mat'];

% 0. set parameters

    
train_test_rate = 2/1; % 1/5; %   
n_initial_cardinality_S = 1000; 
period_clean = 400; 
tol_violating_pair_initial = 0.5;  %5E-2; %5E-3; % tolerance of violating pair
tol_violating_pair_min = 0.1; %5E-2; 


verbose = 2; 
n_epoch = 1; 
save_result_text = 0;

% mu_safe = 0.3; 
% mu_safe_target = 0.3; % for velos_nomips

ratio_max_removed_non_SV = 0.25; 
reject_nonactive_sample = 1;
mu_decoy_nonact = [4.0  ];
mu_target_nonact_predict_correct = [15.0]; %%[4.0  8.0];
mu_target_nonact_predict_wrong  = [8.0];

mu_safe = 0.3; 
switch name_f
    case 'yeast'
        cdecoy=4.8;
        ctarget=2.4;
        lambda = 2.4;          
        mu_safe_target = Inf; 
    case 'ups1'
        cdecoy=0.8;
        ctarget=0.4;
        lambda = 0.4;  
        mu_safe_target = Inf; 
    case {'tal08','tal08_large'}
        cdecoy=0.9;
        ctarget=0.6;
        lambda = 0.6;
        mu_safe_target = Inf; 
    otherwise  % for PBMC datasets
        cdecoy=3;
        ctarget=2.0;
        lambda = 2.0;
        mu_safe_target = mu_safe; 
end

lambda_mode =   'Fix'; %'SPL';%
n_ite_lambda =  2; 

flag_gpu_on = 0;

userSetting( {'path_user_data',path_user_data,'verbose',verbose,  'train_test_rate',train_test_rate,'n_initial_cardinality_S',n_initial_cardinality_S,...
    'period_clean',period_clean,'tol_violating_pair_initial',tol_violating_pair_initial,... %%% 'tol_decrease_factor',tol_decrease_factor, 
    'flag_gpu_on',flag_gpu_on ...
    'tol_violating_pair_min', tol_violating_pair_min,'n_epoch',n_epoch,...
    'mu_safe',mu_safe,'mu_safe_target',mu_safe_target,'ratio_max_removed_non_SV',ratio_max_removed_non_SV...
    'lambda_mode',lambda_mode,'n_ite_lambda',n_ite_lambda,...
    'cdecoy',cdecoy,'ctarget',ctarget,'lambda',lambda,'reject_nonactive_sample',reject_nonactive_sample,'save_result_text',save_result_text,...
     'mu_decoy_nonact',mu_decoy_nonact ,'mu_target_nonact_predict_correct',mu_target_nonact_predict_correct, ...
    'mu_target_nonact_predict_wrong', mu_target_nonact_predict_wrong});
    


% 1. read data
cranker_read('-w','1', '-v','1','-l','\b\t',rawFileName,matDataFile); % -w: title row

%cranker_read('-w','1', '-v','3','-e','0','-n','0',rawFileName,matDataFile); % -w: title row

% 2. identify reliable target PSMs
clock1 = tic;
 cranker_solve('-v','2',matDataFile,matScoreFile); % -v: verbose
% cranker_solve('-t','3',matDataFile,matScoreFile); %-t: train/test rate, 
% cranker_solve('-f','0',matDataFile,matScoreFile); %-f: whether split train and test 
% cranker_solve('-ctarget','0.1',matDataFile,matScoreFile);
% cranker_solve('-z','600','-m','3',matDataFile,matScoreFile);%-z: maximum train size; -m: number of submodels
%  cranker_solve('-x','0','-f','0','-v','3',matDataFile,matScoreFile); %-x: relateive feature weight of xcorr and deltacn

% 3. put out results
 resultFile = cranker_write(matDataFile,matScoreFile);
% cranker_write('-fdr','0.04','-v','0',matDataFile,matScoreFile);
runtime = toc(clock1);

[resultFile_path,resultFile_name,~] = fileparts(resultFile);
resultFile_mat = [resultFile_path filesep resultFile_name '.mat'];
s_result = load(resultFile_mat,'num');
ratio=(s_result.num{2}.TP+s_result.num{2}.FP)/(s_result.num{3}.TP+s_result.num{3}.FP);

 TP = s_result.num{3}.TP
 FP = s_result.num{3}.FP
 ratio
runtime

% % %  toc
% % %  runtime=  toc;
% % %      Result={ s_result.num{3}.TP ,s_result.num{3}.FP,s_result.num{2}.TP,s_result.num{2}.FP,ratio};        
% % %  timeData={datestr(now,30)};
% % %   Parameter=[cdecoy,ctarget,lambda,runtime];
% % %   
% % %  if ~exist('e:\myData1.xlsx','file')
% % %     xlswrite('e:\myData1.xlsx',timeData,1,'A1');
% % %     xlswrite('e:\myData1.xlsx',Result,1,'B1');
% % %     xlswrite('e:\myData1.xlsx',Parameter,1,'H1');
% % %  else 
% % %     [tmp1,tmp2,tmpRaw]=xlsread('e:\myData1.xlsx');
% % %  if size(tmp1,1)==0&&size(tmp2,1)==0%�Ƿ��ǿ��ĵ�
% % %         mRowRange='1';
% % %     else
% % %         mRowRange=num2str(size(tmpRaw,1)+1);
% % %     end
% % %     xlswrite('e:\myData1.xlsx',timeData,1,['A' mRowRange]);
% % %     xlswrite('e:\myData1.xlsx',Result,1,['B' mRowRange]);
% % %      xlswrite('e:\myData1.xlsx',Parameter,1,['H' mRowRange]);
% % %  end

 
 
