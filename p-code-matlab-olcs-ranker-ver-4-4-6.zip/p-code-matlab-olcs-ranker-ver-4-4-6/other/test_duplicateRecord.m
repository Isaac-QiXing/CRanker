% test_duplicateRecord.m
dataPath = 'D:\data_psm\';

debug_on =0;
if debug_on
    recordFileName =  [dataPath 'yeast-demo.txt'];
    file_output = [dataPath 'yeast-demo_duplicate_temp.txt'];
    arg.duplicateNumber = 3;
else
    recordFileName =  [dataPath 'pbmc_orbit_mips.txt'];
    file_output = [dataPath 'pbmc_orbit_mips_duplicate_temp.txt'];
    arg.duplicateNumber = 20;
end

iteInf =  duplicateRecord(recordFileName,file_output,arg);