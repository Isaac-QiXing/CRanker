%demo_crossValidation.m
clear
clc

path = '.\';
dataset ='ups1';

% for ups1
par_search = struct( 'cdecoy',[  0.2     1.0    ],...
    'ctarget_cdecoy_ratio', [   0.1  0.3  0.6  ],...        % ratios of ctarget to  cdecoy
    'r1',[  1.0         ],...
    'lambda_ctarget_ratio', [1.0 1.5 2.0]);  % candidate parameter values for grid search

train_test_rate = 1/5; %5/1;
k_fold = 3; %5;
dataFile = [path dataset '.mat'];
rawFileName = [path dataset '.xlsx'];

 %   read PSM records
olcs_read(rawFileName,dataFile);
%  select part of PSMs as training samples
[trainFile,~] = olcs_split(dataFile,'train_test_rate',train_test_rate);
% cross validation to select proper parameter values
olcs_cv('-k',k_fold,'-z','20000','-v',1,trainFile,par_search,@findBestResult);
