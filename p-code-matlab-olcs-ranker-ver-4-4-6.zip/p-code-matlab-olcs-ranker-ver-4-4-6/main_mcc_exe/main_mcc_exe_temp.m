 mcc -m olcs_read
% mcc -m olcs_solve
 mcc -m olcs_write 
 mcc -m olcs_version
% mcc -m olcs_split
% mcc -m olcs_train
% mcc -m olcs_test
% mcc -m olcs_cv
 
 