% demo4_cranker.m
% A demo to  employ OLCS-Ranker on large-scale datasets
% 

clc
clear
 
    
% dataPath = 'E:\olcs-ranker\data-psm\';
dataPath = 'D:\data_psm\';
%  rawFileName = 'D:\data_psm\pbmc_orbit_mips.txt'; 
 rawFileName = [dataPath 'pbmc_velos_nomips.txt']; % data file containing records of PSMs

%%userSetting({'path_user_data','D:\data_psm'}); % set the path of dataset files

matDataFile = [dataPath 'myPSMdata.mat']; % Mat file name to store PSM records
matScoreFile = [dataPath 'myPSMscore.mat']; % Mat file name to store the scores of identified PSMs
   

% 1. read PSM records
olcs_read(rawFileName,matDataFile); 
 
% 2. identify reliable target PSMs

% On large scale datasets,  
%  * set '-muSafeTarget' the same value as '-muSafe' 

% set the solver as 'CCCP_online',   '-muSafe' parameter as 0.3, and
% '-muSafeTarget' parameter as 0.3 
% olcs_solve('-s','CCCP_online','-muSafe','0.3','-muSafeTarget','0.3',...
%     matDataFile,matScoreFile); 
olcs_solve('-auto','1','-v','3',matDataFile,matScoreFile);
 
% 3. put out identified PSM records 
 resultFile = olcs_write(matDataFile,matScoreFile);