% main_generate_p_file

currPath = fileparts(mfilename('fullpath'));
mfile_str =[currPath filesep 'lib_m' filesep '*.m'];

% generate a path to save the p-files
tmp = '.\lib_p';
if ~exist(tmp,'dir')
    mkdir(tmp);
end
cd(tmp);

% generate p-code
pcode(mfile_str);
dir ;