function q_value = cal_q_value(score,y)
% inputs:
%   score: n-by-k matrix of score values, each column is a group of scores of a base predictor
%       A larger score value indicates higher confidence of x_i be a positive sample
%   y: n-by-1 column vectors consisting of 1 and -1
% Outputs:
%   q_value: a matrix with the same size as SCORE, consisting of the q_values

COEF_FDR = 1.0; 

y = columnVec(y);
if size(score,1)~=length(y)
    error('SCORE should have the same row number as the label vector Y');
end
    


[~,i_trRank] = sort(score,1,'descend');
    

is_decoy_m =  y(i_trRank)==-1; % is_decoy_m is a  n-by-k matrix consisting of 1 and 0 

[n_row,n_col] = size(score);
q_value = zeros(n_row,n_col); % intialize q_value

if nnz(is_decoy_m)>0    
    B = cumsum(is_decoy_m,1);
    u = (1:n_row)';
    for i_col=1:n_col
        q_value(:,i_col) = B(:,i_col)./u;
            % for i_col-th column:
            %   q_value(ii,i_col) = num of 1s (i.e., num of decoys) in is_decoy_m(1:ii,i_col)/ii
    end
    %  --> the orginal order of scores
    [~,i_score] = sort(i_trRank,1,'ascend');
    q_value = q_value(i_score);
end
    
