function R = RotMatrix_Rn(u, v)
 % RotMatrix - N-dimensional Rotation matrix
 % Inputs:
 %  u,v: two vectors that is not collinear
 % Outputs:
 %  R: N-by-N rotation matrix, that Rotate unit  vector of direction u to
 %  unit direction vector of v: 
 %      i.e.  
 %          R*u/norm(u)  = v/norm(v)
 
 % calculate alpha
 %  <u,v> = |u||v| cos(alpha)
 %  | cross(u,v) |  = |u||v| sin(alpha)
 
 norm_u = norm(u);
 norm_v = norm(v);
 alpha = acos(dot(u,v)/(norm_u*norm_v)); 
%  cross_u_v = cross(u,v);
%  if cross_u_v<0
%      alpha = 2*pi - alpha; 
%  end
 
 R = RotMatrix(alpha, u, v);
 
 % check  R*u/norm(u) == v/norm(v)
 if norm(R*u/norm(u) -v/norm(v),1)>1.0E-12
       alpha = 2*pi - alpha;
       R = RotMatrix(alpha, u, v);
 end
    
end