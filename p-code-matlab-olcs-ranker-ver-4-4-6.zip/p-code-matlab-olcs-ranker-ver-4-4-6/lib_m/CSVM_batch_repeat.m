function [model,fval_v,exitFlag_v] = CSVM_batch_repeat(arg,X_col,y_total)
%   training  multiple   CRanker models based on C-SVM by batch CCCP (Convex-Concave Procedure);
%
% Inputs:
%     arg: the struct of algorithm parameters; see CSVM_CCCP_batch.m    for detail;
%   
%   X_col:   the matrix of samples,  each column indicating a sample
%        the number of rows of X_col equal to the length of arg.w;
%
%   y_total: a column vector of labels consisting of 1 and -1; with length equal to 
%       the column number of X_col 
% Outputs
%   model: a structure indicating the model
%     .alpha: a matrix, with each column consisting the coefficients alpha 
%           of a sub-model;
%           note that the discriminant function:
%                 f(x) = \sum_{i} \alpha_i k(x_i, x) + b;
%     .ind: a matrix with the same size as alpha_v, each column consisting
%           the indices of the samples employed for training a sub-model;
%     .b:  a column vector with the length equal the number of sub-models;
%          consisting the calculated intersepts of the discriminant
%          function; 
%   fval_v: a vector of calculated objective function values of each submodel
%       
%   exitFlag_v:  a vector of exit flags of each submodel
%       0: exceed the maximum iteration number
%       1: succeed to find a local minimum; 

% arguments
[verbose, decoy_rate,maxTrainSize,num_submodel] =...
    problemArg('verbose','decoy_rate','maxTrainSize','num_submodel');

n = size(X_col,2); % total number of samples
if verbose >=3
    fprintf('num of samples for training: %d \n',n);
end

% n less than the given training size
if n<=maxTrainSize   
    [model,fval_v, exitFlag_v]=CSVM_CCCP_batch(arg,X_col,y_total); 
    model.ind = (1:n)'; 
    return
end

   
if verbose ==1
        printProgress(0);
end
% repeat
fval_v = zeros(num_submodel,1);
exitFlag_v = zeros(num_submodel,1);
for k = 1:num_submodel
    % sample specified number of samples randomly
    if verbose>=2
        fprintf('\t Begin to solve submodel %d. \n',k);
    end 
    
    ind = selectLabel(y_total,maxTrainSize,decoy_rate);    
    tic 
        [model0,fval_v(k), exitFlag_v(k)]=CSVM_CCCP_batch(arg,X_col(:,ind),y_total(ind));
	t = toc;
    if k==1
        % initialize the model structure
        num_sample = length(model0.alpha);     
        model = struct('alpha',zeros(num_sample,num_submodel),...
            'ind',zeros(num_sample,num_submodel),'b',zeros(num_submodel,1));
    end    
    model.alpha(:,k) = model0.alpha;
    model.ind(:,k) = ind;
    model.b(k) = model0.b;
    if verbose ==1
        printProgress(1,num_submodel);
    elseif verbose>=2
        fprintf('\t Finished to solve submodel %d. Elapsed time: %.2fs.\n',k,t);
    end  
end

end
