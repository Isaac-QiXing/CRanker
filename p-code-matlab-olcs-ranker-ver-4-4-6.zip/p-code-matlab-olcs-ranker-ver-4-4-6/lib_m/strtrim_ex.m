function str2 = strtrim_ex(str,par)
% trim the specified leading and trailing characters of a string
% extended version of the function strtrim
% Inputs:
%   str: a string or string cell array
%   par, Optional,  characters to remove, default ' \b\t' (remove the 
%   leading and tailing black charaters).
% Outputs:
%   str2: a string or string cell array with the same size as str



if isempty(str)
    str2 = [];
    return;
end

if nargin<=1 || isempty(par)
    par = ' \b\t';
end

pattern_str = sprintf('[^%s]*[^%s]',par,par);

str2 = regexp(str,pattern_str,'match','once');

    
end