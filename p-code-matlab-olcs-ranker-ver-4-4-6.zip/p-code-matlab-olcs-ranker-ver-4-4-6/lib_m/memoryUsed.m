function mem = memoryUsed()
% return the memory (Mb) used by Matlab  

userview = memory; 
% userview = 
%     MaxPossibleArrayBytes: 1.4957e+10
%     MemAvailableAllArrays: 1.4957e+10
%             MemUsedMATLAB: 784044032

mb = 2^20;
mem = userview.MemUsedMATLAB / mb;
end