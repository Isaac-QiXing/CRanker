function w = get_feature_weight(X_feature,arg)
% get the feature weight vector
% Inputs:
%  X_feature: a string cell array of feature names
%  arg:  a struct containing:
%   .weight_xcorr: a positive scalar indicating the relative feature weight
%       of ``xcorr'' and ``deltacn'' feature; 
% Outputs:
%  w: a column vector with same length as X_feature, consisting of the
%     feature weights 

[xcorr_name, deltacn_name,  basic_w]= problemArg('feature_name_xcorr',...
    'feature_name_deltacn', 'basic_feature_weight');

w_xcorr = arg.weight_xcorr;

% initialize w
w = ones(length(X_feature),1)*basic_w;

[temp ind_v]  = ismember({xcorr_name,deltacn_name},X_feature);
for ii=1:2 % 2: two features: xcorr and deltacn
    if ind_v(ii)>0
        w(ind_v(ii))  = w(ind_v(ii))*w_xcorr;
    end
end


end