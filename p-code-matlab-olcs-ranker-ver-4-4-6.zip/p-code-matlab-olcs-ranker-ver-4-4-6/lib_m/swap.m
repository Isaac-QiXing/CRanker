function v1 = swap(v,a,b)
% swap two values of vector 
%   v(a) <-> v(b)

v1 = v;
t = v1(a);
v1(a) = v1(b);
v1(b) = t;
end