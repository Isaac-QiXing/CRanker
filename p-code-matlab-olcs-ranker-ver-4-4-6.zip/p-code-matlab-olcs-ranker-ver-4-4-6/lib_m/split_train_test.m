function [ind_train,varargout] = split_train_test(dataFile,trainFile,testFile,arg)
% split the data randomly into one training set and one or multiple test sets
% Inputs: 
%   dataFile: mat data file name
%   arg: structrue of the arguments
%      .train_test_rate:
%           (1) a scaler indicating the ratio of  cardinality of train set  to the cardinality of test set;
 %          (2) or a vector indicating the percentage of each divided sets
% 
%      .flag_standardize: whether standardize each column before splitting
%
%   trainFile, testFile: mat file name where store the train and test dataset;
%       If to divide multiple test sets, then testFile is a cell array, each cell consists of a test file name  
%           
% Outputs:
%   ind_train: a column vector consisting the indices of the train set;
%   varargout{1}: (1) a column vector consisting the indices of the test set;
%     (2) Or a cell array, if to divide multiple test sets, each
%     cell consists of a vector of the indices of a divided test set
%
%     both of trainFile and testFile(s)  contain the following variables:
 %       X: a matrix, each row consists a record/sample;
 %       y: a column vector with length as same number of rows of X,
 %          consisting of the labels of the samples;
 %     ind: a column vectore with same length as y, indexing the samples;
 %   sizeX: a 1-by-2 vector, the size of matrix X;
 %  X_feature: a string cell array, with the i-th element  the
 %           feature name of the i-th column of the matrix X; 

 % 0.1 check the number of supplied files and the number of files to divide
 if iscell(testFile)
     n_test = length(testFile); % n_test: number of test files to be divided
 elseif ischar(testFile) 
     n_test = 1;
 else
     error('testFile should be a string or a cell array of strings.');
 end
 
if isscalar(arg.train_test_rate)
    arg.train_test_rate = [arg.train_test_rate 1]; % train/test ratio = arg.train_test_rate : 1
end
if  length(arg.train_test_rate) ~= n_test+1
    error('The number of supplied test files (%d file(s) ) is not equal to that indicated by the train_test_rate',n_test);
end


% 0.2. standardize
load(dataFile,'data');
if arg.flag_standardize
    data.input = standardize(data.input); 
end

fix_train_test_set = problemArg('fix_train_test_set');

% 1. determine the size of each divided set

[n,m] = size(data.input); % n: total number of samples, m: the number of features
train_test_rate = arg.train_test_rate/sum(arg.train_test_rate); % ratio of the capacity of each set
size_set_v = round(n*train_test_rate); % size of each set
size_set_v(1) = n - sum(size_set_v(2:end)); % adjust the number of size_set_v(1) to ensure that sum(size_set_v) == n

% 2. separated the data and save the variables to files
if fix_train_test_set
    rng(1,'twister');
    ind = columnVec(randperm(n));
else % make the train set and test set different at different calls
    rng('shuffle');
    ind = columnVec(randperm(n));
end
    
p_size = cumsum(size_set_v); % cumulative sum of the cardinality of each set

% 2.1 save the training samples
ind_train = ind(1:p_size(1));

if isfield(data,'input_feature')
    X_feature = data.input_feature;
else
    X_feature = {};
end
saveData(trainFile,'X',data.input(ind_train,:),'y',data.output(ind_train),...
    'sizeX',[p_size(1) m],'ind',ind_train,'X_feature',X_feature);

% 2.2 save the test sets
ind_test_c = cell(n_test,1);
for ii=1:n_test
    ind_test = ind(p_size(ii)+1:p_size(ii+1));
    ind_test_c{ii} = ind_test;
    if iscell(testFile)
        testFile_ii = testFile{ii};
    else % n_test == 1
        testFile_ii = testFile;
    end
    saveData(testFile_ii,'X',data.input(ind_test,:),'y',data.output(ind_test),...
        'sizeX',[length(ind_test) m], 'ind',ind_test,'X_feature',X_feature);
end

if nargout>1
    if n_test == 1
        varargout{1} = ind_test_c{1};
    else%    n_test>1
        varargout{1} = ind_test_c;
    end
end

end
