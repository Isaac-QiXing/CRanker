function saveErrInformation(logFileName,err)
% save error information to command line and to the specified text file
% Inputs:
%   logFileName: text file name, set [], if only put out to command line 
%   err: object of MException class

if isempty(logFileName)
    fid = [];
else    
    fid = fopen(logFileName,'a+');
end
for i_fid = [1,fid]
    fprintf(i_fid, '%s', err.getReport('extended', 'hyperlinks','off'));
end
fclose(fid);