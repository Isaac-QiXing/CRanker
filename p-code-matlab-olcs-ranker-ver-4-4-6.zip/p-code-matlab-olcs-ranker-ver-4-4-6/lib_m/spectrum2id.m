function id = spectrum2id(spectrumFile,dataFile,arg)
%Inputs
%  spectrmFile: excel file name, which file contains PSMs data with the title 
%     labeled  'spectrum' on the title line
%  dataFile: mat data file name, contains text.spectrum
%  arg: 
%   .titleRow: title row number
%   .sheet: sheet name
% Outputs:
%   id: a vector indexing the indices of the samples

% load data

load(dataFile,'text');
spect = text.spectrum;
clear('text');
[data txt] = readData(spectrumFile,arg);
[tp id] = ismember(txt.spectrum,spect);
end