function str = timeStampNow()
% genenate a timeStamp str

timeStamp = datestr(now,30);
str=  [timeStamp '_' num2str(round(rand(1)*1E6))];
end