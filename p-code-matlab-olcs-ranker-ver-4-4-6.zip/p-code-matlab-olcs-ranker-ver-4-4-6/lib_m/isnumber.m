function flag = isnumber(str)
% Check whether a string is composed by numbers 0--9, or '.', '+', '-'
%   ('+','-s' only occur at the beginning);
%   * if str=[], return false; 
%   * if str=NaN, return false; 
%
% Versions.
%   * 2020.2.13 fix a bug of identifying the input STR=[] or STR = NaN; 
%   * 2017.9.13 first version

 
if isempty(str) 
    flag = false; 
elseif isnan(str)
    flag = false; 
elseif ischar(str)
    flag = ~isempty(regexp(str,'^[-+]?[\d\.]+$','match'));
else
    flag = isnumeric(str);
end

end