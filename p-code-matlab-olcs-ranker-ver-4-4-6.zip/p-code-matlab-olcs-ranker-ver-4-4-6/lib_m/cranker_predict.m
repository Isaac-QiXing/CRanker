function [result_test,varargout] = cranker_predict(matTrainFile,matTestFile, par_alg)
% train the cranker model and identify the TPs and FPs on test set
% Inputs:
%      matTrainFile, matTestFile: mat file name for traing and test,
%       it contain  the same data variables;
%      par_alg: a struct of algorithm  parameters
% Outputs:
%      result_test: a struct of the predicted results on test sets 
%          Each field  of result_test is a numeric scalar.
%      varargout{1}: optional,  a struct of iterated information, including 8 fields:
%         'score_train','score_test',
%         'ind_train','ind_test','weight','arg','model','timestamp'
%
% version
%   2018.10.10 fix a bug of the case of multiple scores of submodels (for instance, corresponding to multiple lambda)
%   2018.10.3 add an optional output ite_s (iterated model, scores)
%   2018.9.25 add a parameter ��cv_fdr�� in config(), with default value =  0.01

debug_mode = 0; %1; %

userSetting(par_alg);

% score file name 
dataPath = fileparts(matTestFile);
matScoreFile = [addFileSep(dataPath) 'score_' datestr(now,30),'.mat'];

olcs_solve_no_cv('-v','0',matTrainFile,matTestFile,matScoreFile);

testData = load(matTestFile, 'y');


if nargout==1
    s = load(matScoreFile, 'score_test');
else % nargout >1
    s = load(matScoreFile, 'score_train','score_test', 'ind_train','ind_test','weight','arg','model','timestamp');
    varargout{1} = s; 
end

argIndex.fdr = problemArg('cv_fdr');
[~,num ] = accuracyIndex(s.score_test(:,end),testData.y,[],argIndex);



    %   calculate the train and test accuracies and put them out
    trainData = load(matTrainFile, 'y');
    s_train = load(matScoreFile, 'score_train');
      [~,num_train ] = accuracyIndex(s_train.score_train(:,end),trainData.y,[],argIndex);

 
      
num.TP_train = num_train.TP;
num.FP_train = num_train.FP;
num.TN_train = num_train.TN;
num.FN_train = num_train.FN; 
      
if debug_mode
    fprintf('on train (TP, FP): (%d, %d), on test (%d, %d) \n',num_train.TP, num_train.FP, num.TP,num.FP)  
end

result_test = num; 
% restore the default parameter settings
userSetting([]);
% delete the score file
if exist(matScoreFile,'file')
    delete(matScoreFile);
end
    
end