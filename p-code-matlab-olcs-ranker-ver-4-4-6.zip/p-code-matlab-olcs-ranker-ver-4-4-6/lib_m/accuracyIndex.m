function [acc,num,varargout] = accuracyIndex(indexRank,y,digestIndex,arg)
% select indices and calculate accuracies based on specified FDRs
%
% Inputs:
%  indexRank: 
%   (1) a matrix  consisting of the scores indicating the rank, with the row numer = length(y)   
%       * each column is a group of scores
%       * a large score indicates a high rank
%   (2) Or a cell array, with each cell consisting of  scores of different samples
%   (3) Or empty [], indicating that all the scores corresponding to y are
%      select to calcualte the accuracies          
%
%  y: a column vector consisting of the labels, 1: positive sample, -1: negative sample;
%   (1) if indexRank is a column vector, then length(y) should equal to the row number of indexRank
%
%  digestIndex: 
%    * a column vector with the same length as y, indicating the digested
%    type of each PSM, it consists of 0, 1 and 2
%       2: full digested, 1: half  digested, 0: none
%    * set [], if not to provide digest information
%
%  arg: the arguments
%   .fdr:  optional, fdr:=coef*FP/(TP+FP),coef is usually set to 2; this parameter is required
%      if indexRank is set; 
%   .accuracyMerge: 0 or 1, whether merge accuracies of multiple sets of samples  when
%      indexRank is a cell array with  length>1,    default 1; 
%   .index:  optional, a cell array,  this parameter is required when indexRank is a cell array  
%     arg.index{i} consists of the indices of i-th set of samples, i=1,2,..
%     Specially, 
%     (1)  if  indexRank is a cell array, then
%       arg.index{i} is a column vector of  the indices of the scores of indexRank{i},
%           i.e.   length(arg.index{i}) == length(indexRank{i}),i = 1,2,...
%     (2) if indexRank = [], then arg.index do not take effect
%     (3) if arg.accuracyMerge ==1, then users should ensure that 
%        * the indices in each arg.index{i} is unique, i =1,2.,,
%        * any two cells arg.index{i}, arg.index{j} contains no common indices
%       default value: [];
%   .tolFP:  optional, number of allowed FPs that to be added additionally, default value 3;   
%   .ratio_discount: optional,   for setting the expected number of added identified  samples
%       once append one FP; 
%       expect_add_sample =  ratio_discount * round(2/arg.fdr);   
%       this parameter is effective when arg.tolFP > 0
%
%  .allowZeroFDR: optional, 1 or 0, whether allow the case that the calculated FDP==0, 
%       default value 0;     
%
% Outputs:
%  num: struct array of size n_set-by-n_method-by-n_FDR,  numbers of TP, FP, TN,FN  with
%   *  n_set = length(arg.index)+1, if arg.accuracyMerge==1 && length(arg.index)>1
%      n_set =  length(arg.index),  otherwise   
%        arg.index{i} is i-th set of indices of scores, and the (length(arg.index)+1)-th
%        set of scores are the merged scores in the first case.
%   *  n_method = size(indexRank,2),  if indexRank is a nonempty matrix
%      n_method = 1 ,              otherwise 
%   *  n_FDR = length(arg.FDR), if arg.FDR is set and nonempty
%      n_FDR = 1,            otherwise
%
%     num(i,j,k)  <-- result of i-th set, j-th method and k-th FDR 
%    
%   NUM has the following fields 
%   
%   .TP : number of true positives 
%   .FP : number of false positives
%   .FN : number of false negative
%   .TN : number of true negative
%   .TP_full: number of TP in full-digested (if digestIndex is provided)
%   .TP_half: number of TP in half-digested (if digestIndex is provided)
%   .TP_none: number of TP in none-digested (if digestIndex is provided)
%   .FP_full: number of FP in full-digested (if digestIndex is provided)
%   .FP_half: number of FP in half-digested (if digestIndex is provided)
%   .FP_none: number of FP in none-digested (if digestIndex is provided)
%     and similarly for 
%   .FN_full
%   .FN_half
%   .FN_none
%   .TN_full
%   .TN_half
%   .TN_none
%
%  acc: struct array of accuracies, with the same size as NUM, with the following fields
%   .FDR: false discovery rate: FP/(FP+TP) 
%   .TPR: true positive rate:  TP/(TP+FN)
%   .FPR: false positive rate: FP/(FP+TN)
%   .score: threshold score under the specified FDR level
%       i.e., TP = nnz(indexRank >= acc.score)
%
%  varargot{1}: struct array of indices, with the common size and fields of NUM,
%       consists of indices of the samples.
%
%  varargout{2}: array of flags  with the common size of indexRank 
%     0: Identified numbers of TPs and FPs satisfying (i.e., <=) the specified FDR 
%     -1: dealed with the extreme case that the selected FDR==0 
%     N (a positive integer): the number of extra added FPs 
%
%  versions
%   2018.10.5 
%      * revise the default value of arg.tolFP from 0 to 2;  (ok)
%         
%      * add an field 'score' to the output 'ACC': the threshold score under specified FDR
%         (ok)
%
%      * revise the method to calculate the merged accuracy:
%        e.g., the number of TPs is not simply adds those TP numbers on each subset,
%           but to count the TP on  the list of merged scores.
%        The old calculation method is not correct, and the new method is correct.
%          But the old method usually gets almost the same results with
%          the correct method. In the case when the TP number is quite small
%           the calculated  results may have evident difference. 
%         (ok)
%       
%      * support the case the IndexRank is a matrix with each column a list
%        of scores of all the PSMs ? 
%      * support the case that arg.index is a cell array with IndexRank has been set ?
%      * support a series of FDR levels ? 
%      * revise the  the variable type of the first 3 outputs: cell array --> struct array

debug_mode = 0;
 
% 0.0 make indexRank,y,digestIndex column array
y = columnVec(y);
digestIndex = columnVec(digestIndex);
if isnumeric(indexRank) && isRowVector(indexRank)
    indexRank = columnVec(indexRank);
end

n_sample = length(y);

% 0.1 check the input size of indexRank and arg.index
if iscell(indexRank) && length(indexRank)>1
    if ~isfield(arg,'index') || length(indexRank)~=length(arg.index) 
        error('when indexRank is a cell array, arg.index is required, and should have the same size as indexRank');        
    end
    for ii=1:length(indexRank)
        if length(indexRank{ii})~=length(arg.index{ii})
            error('when indexRank is a cell array, arg.index{ii} should have the same size as indexRank{ii}');        
        end
    end
end

% 0.2 check the size of indexRank and digestIndex

  % check the size of indexRank
if ~iscell(indexRank) && ~isempty(indexRank) && size(indexRank,1)~=length(y)
    error('IndexRank should have the same row number as y');
end
  % check the size of digestIndex
if ~isempty(digestIndex) && length(digestIndex)~=length(y)
    error('digestIndex should have the same size as y');
end

% 0.3 set default parameter values
arg = completeArg(arg,{'accuracyMerge','tolFP','ratio_discount','allowZeroFDR','index','fdr'},...
                      {1,               3,      0.4 ,           0,              []  ,     []});

fdr_v = arg.fdr; 

   % check arg.fdr
if isempty(arg.fdr)&& ~isempty(indexRank)
    error('arg.fdr is required.');
end

% 0.3 count the length of the output struct array num
% 0.3.1 set n_set (number of sets )
if ~isempty(arg.index)  
    n_group = length(arg.index);
else     
    n_group = 1; % n_group: number of input sets of indices
end    
%   *  n_set = length(arg.index)+1, if arg.accuracyMerge==1 && length(arg.index)>1
%      n_set =  max{length(arg.index),1},  otherwise 
if n_group>1 && arg.accuracyMerge 
    n_set = n_group + 1; %len_num: length of the output struct array num, id and acc
else
    n_set = n_group;
end  
% 0.3.2 set n_method 
%   *  n_method = size(indexRank,2),  if indexRank is a nonempty matrix
%      n_method = 1 ,              otherwise 
if isnumeric(indexRank) && ~isempty(indexRank)
    n_method = size(indexRank,2);
else 
    n_method = 1;
end

% 0.3.3 set n_fdr
%   *  n_fdr = length(arg.FDR), if arg.FDR is set and nonempty
%      n_fdr = 1,            otherwise
n_fdr = max(length(arg.fdr),1);

if debug_mode
    fwritef(1,'n_set',n_set,'','n_method',n_method,'','n_fdr',n_fdr,'');
end

% 0.4 for accuracyMerge: 
%   append a list of merged scores to a cell of indexRank
if n_group>1 && arg.accuracyMerge 
    % 0.4.1 make each cell of indexRank and arg.index is a column vector
    if iscell(indexRank)
        indexRank = cellfun(@columnVec,indexRank,'UniformOutput',false);
    end
    arg.index = cellfun(@columnVec,arg.index,'UniformOutput',false);
    % 0.4.2 merge the scores and indices as  column vectors
    %    score_merge <- Union of indexRank{i}, i = 1,2,...
    %    index_merge <- Union of arg.index{i}, i = 1,2,...
    index_merge = cat(1, arg.index{:});
    [index_merge,i_merge]= unique(index_merge);
    if iscell(indexRank)
        score_merge = cat(1, indexRank{:});
        score_merge = score_merge(i_merge);
    end
    
    % 0.4.3 insert the merged scores and indices into indexRank and arg.index
    if iscell(indexRank)
        indexRank{n_group+1} = score_merge;
    end
    arg.index{n_group+1} = index_merge;
end

% 1. calculate the accuracies
num = struct('TP',num2cell(zeros(n_set,n_method,n_fdr)),'FP',0,'FN',0,'TN',0,...
    'TP_full',0,'TP_half',0,'TP_none',0,'FP_full',0,'FP_half',0,'FP_none',0,...
    'TN_full',0,'TN_half',0,'TN_none',0,'FN_full',0,'FN_half',0,'FN_none',0);
id =  struct('TP',cell(n_set,n_method,n_fdr),'FP',[],'FN',[],'TN',[],...
    'TP_full',[],'TP_half',[],'TP_none',[],'FP_full',[],'FP_half',[],'FP_none',[],...
    'TN_full',[],'TN_half',[],'TN_none',[],'FN_full',[],'FN_half',[],'FN_none',[]);
acc = struct('FDR',num2cell(zeros(n_set,1)),'TPR',0,'FPR',0,'score',[]);
flag_exit_m = zeros(n_set,n_method,n_fdr);

for i_set=1:n_set
    if isempty(arg.index)
        index_iset = 1:n_sample; % if arg.index = [], all the samples are used
    else
        index_iset = arg.index{i_set};
    end    
    if isempty(digestIndex)
        digestIndex_ii = [];
    else
        digestIndex_ii = digestIndex(index_iset);
    end
    for i_method = 1:n_method
        if isempty(indexRank)
            indexRank_i = [];
        elseif iscell(indexRank)
            indexRank_i = indexRank{i_set};
        else % index rank is matrix or vector
            indexRank_i = indexRank(index_iset,i_method);
        end
        for i_fdr = 1:n_fdr
            if ~isempty(fdr_v)
                arg.fdr = fdr_v(i_fdr);
            end
            if nargout>=3
                [acc_i,num_i,id_i,flag_exit_i]=accuracyIndex_0(indexRank_i,y(index_iset),digestIndex_ii,arg);
            else % nargout<=2 do not get the 3rd output ID
                [acc_i,num_i]=accuracyIndex_0(indexRank_i,y(index_iset),digestIndex_ii,arg);
            end
            acc(i_set,i_method,i_fdr) = acc_i;
            num(i_set,i_method,i_fdr) = num_i;
            if nargout>=3
                % update indices of the struct array id
                if ~isempty(arg.index)
                    id_i = structfun(@updateIndex,id_i,'UniformOutput',false);
                end
                % assgin id_i and flag_exit_i
                id(i_set,i_method,i_fdr)  = id_i;
                flag_exit_m(i_set,i_method,i_fdr) = flag_exit_i;
            end            
        end
    end
end

    function ind1 = updateIndex(ind)
        ind1 = index_iset(ind);
    end
 
% % % % update indices of the struct array id
% % % field_num_c = fieldnames(num);
% % % n_field_num = length(field_num_c);
% % % if nargout>=3 && n_group>1
% % %     for ii=1:n_group
% % %         index_ii = arg.index{ii};
% % %         for kk=1:n_field_num
% % %             field = field_num_c{kk};            
% % %             id(ii).(field) = index_ii(id(ii).(field));
% % %         end
% % %     end
% % % end

% 2. merge the accuracies
% the scores and indices has been merged and the merged accuracies has been
% calculated above. 

% 3. output 
if nargout>=3
    varargout{1} = id;
end
if nargout>=4
    varargout{2} = flag_exit_m;
end

end %end of the function accuracyIndex()


function [acc,num,varargout] = accuracyIndex_0(indexRank,y,digestIndex,arg)
% calculate the accuracy index

% Inputs:
%  indexRank: the value of a certain index ranking the samples,
%            with a large value indicateing a reliable target;
%           if indexRank is set [], all the samples corresponding to y, will
%           be viewed selected targets;
%  y: a column vector consisting of the labels, 1: targets, -1: decoys;
%
%  digestIndex: a column vector indicating the digested type;
%    2: full digested, 1: half  digested, 0: none
%    * set [], if not to provide digest information
%
%  arg: the arguments
%   .fdr: Optional, upper bound of the fdr:=FP/(TP+FP); this parameter
%          is effective only if indexRank is set;
%   .selectedTarget: Optional, a vector consisting a series of rate of predicted
%       positive samples (i.e. x_i's with f(x_i)>0 )
%    e.g. [0.1 0.2 0.3] indicating the selected percentage of the predicted
%      positive samples are 10%, 20%, 30%
%       this parameter is effective if and only if indexRank is set and 
%       .fdr is not effective;
%   .tolFP, refer the inputs of accuracyIndex()
%   .ratio_discount: scalar that for discount the expected number of added  identified  samples  once append one FP    
%       expect_add_sample =  ratio_discount * round(2/arg.fdr);   
%       this parameter is effective when arg.tolFP > 0 
%   .allowZeroFDR: optional, 1 or 0, whether allow  the extreme cast that the calculated FDP == 0, default value 0;   
%
%   NOTE that 
%    ARG struct has no 'index' field for  accuracyIndex_0(), if there exist
%       ARG.index, it does not take effect.
%
% Outputs:
%  num: array of struct with the same length as
%    arg.selectedTarget
%   .TP : number of true positives 
%   .FP : number of false positives
%   .FN : number of false negative
%   .TN : number of true negative
%   .TP_full: number of TP in full-digested
%   .TP_half: number of TP in half-digested
%   .TP_none: number of TP in none-digested
%   .FP_full: number of FP in full-digested
%   .FP_half: number of FP in half-digested
%   .FP_none: number of FP in none-digested
%     and similarly for 
%   .FN_full
%   .FN_half
%   .FN_none
%   .TN_full
%   .TN_half
%   .TN_none
%  acc: array of accuracy structure 
%   .FDR: false discovery rate: FP/(FP+TP) 
%   .TPR: true positive rate:  TP/(TP+FN)
%   .FPR: false positive rate: FP/(FP+TN)
%   .score: threshold score under the specified FDR level
%       i.e., TP = nnz(indexRank >= acc.score)
%  varargout{1}: id, array of a structure with the same fields as NUM; indexing the
%      selected samples 
% varargout{2}: flag of the identification. 
%     0: Identified  TP+FPs satisfying that FDR value <= the specified .fdr 
%     -1: dealed with the extreme case that  the selected FDR ==0 and the  identified TP+FPs increases   
%     N (a positive integer): the number of extra added FPs 

%COEF_FDR = 1.0;  % FDR = COEF_FDR * FP / (TP + FP)
COEF_FDR = problemArg('COEF_FDR');  % FDR = COEF_FDR * FP / (TP + FP)

if ~isempty(digestIndex) && length(y)~=length(digestIndex)
    error('The length of the #2 and #3 should equal.');
end
flag_index = ~isempty(indexRank); % 1: indexRank is set; 0: otherwise
if flag_index && length(y)~=length(indexRank)
    error('If #1 is not empty, the length of the #1 and #2 should equal.');
end
if nargin<=3 || nargin>3 && (~isfield(arg,'selectedTarget') || isempty(arg.selectedTarget))
    selectedTarget = 1.0;
else
    selectedTarget = arg.selectedTarget;
end

if arg.tolFP>0   
    ratio_discount = arg.ratio_discount;    
    % this parameter is effective when arg.tolFP > 0 
end

n_y = length(y);
if flag_index
    n_pos = nnz(indexRank>0);
else
    n_pos = n_y; % all the samples are viewed selected targets 
end


if flag_index
    [indexRank_sort,i_trRank] = sort(indexRank,'descend');
        % indexRank_sort is the sorted indexRank used for given acc.score
end

% * calculate rates of the selected targets based on fdr
flag_exit = 0; 
if flag_index && nargin>3 && isfield(arg,'fdr') && ~isempty(arg.fdr)
       
    % *.1 calculate all the  FDR levels    
    %%%FP_max = ceil(n_y * arg.fdr * 0.5);
    FP_max = ceil(n_y * arg.fdr/COEF_FDR);
        % maximum number of possible FPs under the specified FDR
    FP_search = FP_max + 1 + arg.tolFP; 
    ind_FP = find(y(i_trRank)==-1,FP_search);
    n_FP = length(ind_FP);
    if n_FP>0
% % %         fdr_search =  2*( (1:n_FP)'-1)./((ind_FP-1)+~(ind_FP-1)); 
        fdr_search =  COEF_FDR*( (1:n_FP)'-1)./((ind_FP-1)+~(ind_FP-1)); 
            % fdr_search is a vector with the same length as ind_FP
            % FDR values if the selected number of scores are ind_FP(ii)-1, with number of FP ii-1
            %  note that it always hold that fdr_search(1) == 0 
            %  +~(ind_FP-1): avoid the case that ind_FP(1)-1 ==0
    else
        fdr_search = [];
    end
    % *.2 find the biggest index that the FDR value is less than specified FDR level arg.fdr   
    i_act = [];
    if isempty(ind_FP)
        selectedTarget = 1.0; % no FP found, all the indices are selected as correct
    else % n_FP>0
        i_act = find(fdr_search <= arg.fdr,1,'last');         
        selectedTarget = (ind_FP(i_act)-1)/n_y; 
    end    
        
        
    % *.3 deal with the extreme case that  the selected FDR ==0    
    if ~isempty(i_act) && i_act ==1 && ~arg.allowZeroFDR    % arg.zeroFDR: deal with the case 
        fdr_search(1) = Inf; % to avoid fdr_search(1) is selected in the min opereation below
        [fdr_min, i_min] = min(fdr_search); % try to select the minimum FDR 
        if fdr_min <=2*arg.fdr           
            selectedTarget = (ind_FP(i_min)-1)/n_y; % reset selectedTarget
            i_act = i_min; % reset i_act
            flag_exit = -1; 
        end       
    end
      
    % *.4 allow add specified number of FPs additionally
    if arg.tolFP>0 && ~isempty(i_act) && i_act<n_FP
    
         %%%expect_add_sample =   round(2/arg.fdr);   % fdr = COEF_FDR*FP/(TP+FP)
         expect_add_sample =   round(COEF_FDR/arg.fdr);   % fdr = COEF_FDR*FP/(TP+FP)
          % expeted number of added samples once add one FP : expect_add_sample
         %%%expect_add_sample_discount =   round(ratio_discount*2/arg.fdr);   % fdr = COEF_FDR*FP/(TP+FP)
         expect_add_sample_discount =   round(ratio_discount*COEF_FDR/arg.fdr);   % fdr = COEF_FDR*FP/(TP+FP)
           % set expected indices of i of the scores that y_i==-1
         ind_expect = Inf(n_FP,1); % a column vector, expected indices of i of the scores that y_i==-1
         ind_FP_discount = min(i_act + arg.tolFP,n_FP);
         ind_expect(i_act+1: ind_FP_discount) = ind_FP(i_act) + expect_add_sample_discount*(1: ind_FP_discount-i_act)';  
            % set expected indices of i with  expeted number of added samples == expect_add_sample_discount  
         if ind_FP_discount < n_FP
            ind_expect(ind_FP_discount+1 : n_FP) = ind_expect(ind_FP_discount) + expect_add_sample *(1 : n_FP - ind_FP_discount)';
            % set expected indices of i with  expeted number of added samples == expect_add_sample
         end
           % find the last index that the expected index of negative sample less than that of the true negative sample   
         i_act_adjust =  find(ind_expect<=ind_FP,1,'last'); % note that i_act_adjust > i_act if i_act_adjust is not empty
         if ~isempty(i_act_adjust)             
              selectedTarget = (ind_FP(i_act_adjust)-1)/n_y; % reset selectedTarget
              if flag_exit~=-1 % set flag_exit
                flag_exit = i_act_adjust-i_act; 
              end
         end
        
    end
end
           
if nargout>=4
    varargout{2} = flag_exit;
end

% calculate the accuracies based on the value of arg.selectdTarget
n_sample = length(y);

len_sel = length(selectedTarget);
num = struct('TP',num2cell(zeros(len_sel,1)),'FP',0,'FN',0,'TN',0,...
    'TP_full',0,'TP_half',0,'TP_none',0,'FP_full',0,'FP_half',0,'FP_none',0,...
    'TN_full',0,'TN_half',0,'TN_none',0,'FN_full',0,'FN_half',0,'FN_none',0);
id =  struct('TP',cell(len_sel,1),'FP',[],'FN',[],'TN',[],...
    'TP_full',[],'TP_half',[],'TP_none',[],'FP_full',[],'FP_half',[],'FP_none',[],...
    'TN_full',[],'TN_half',[],'TN_none',[],'FN_full',[],'FN_half',[],'FN_none',[]);
acc = struct('FDR',num2cell(zeros(len_sel,1)),'TPR',0,'FPR',0,'score',[]);

fieldname_num = fieldnames(num);
for ii=1:len_sel
    if flag_index
        sel_rate = selectedTarget(ii);             
        p = round(n_y*sel_rate);        % number of TP + FP 
        i_pos_rank = i_trRank(1:p);     % indices to be selected as positive samples
        i_neg_rank = i_trRank(p+1:n_sample); % indices to be selected as negative samples
    else        
        i_pos_rank = 1:n_sample;
        i_neg_rank = [];
    end
    if nargout>=3
        id(ii).TP = i_pos_rank(y(i_pos_rank)==1);
        id(ii).FP = i_pos_rank(y(i_pos_rank)==-1);   
        if ~isempty(digestIndex)
            id(ii).TP_full = i_pos_rank((y(i_pos_rank)==1)&digestIndex(i_pos_rank)==2);
            id(ii).TP_half = i_pos_rank((y(i_pos_rank)==1)&digestIndex(i_pos_rank)==1);
            id(ii).TP_none = i_pos_rank((y(i_pos_rank)==1)&digestIndex(i_pos_rank)==0);
            id(ii).FP_full = i_pos_rank((y(i_pos_rank)==-1)&digestIndex(i_pos_rank)==2);
            id(ii).FP_half = i_pos_rank((y(i_pos_rank)==-1)&digestIndex(i_pos_rank)==1);
            id(ii).FP_none = i_pos_rank((y(i_pos_rank)==-1)&digestIndex(i_pos_rank)==0);    
        end
        if flag_index
            id(ii).FN = i_neg_rank(y(i_neg_rank)==1);
            id(ii).TN = i_neg_rank(y(i_neg_rank)==-1);
            if ~isempty(digestIndex)
                id(ii).FN_full = i_neg_rank((y(i_neg_rank)==1)&digestIndex(i_neg_rank)==2);
                id(ii).FN_half = i_neg_rank((y(i_neg_rank)==1)&digestIndex(i_neg_rank)==1);
                id(ii).FN_none = i_neg_rank((y(i_neg_rank)==1)&digestIndex(i_neg_rank)==0);
                id(ii).TN_full = i_neg_rank((y(i_neg_rank)==-1)&digestIndex(i_neg_rank)==2);
                id(ii).TN_half = i_neg_rank((y(i_neg_rank)==-1)&digestIndex(i_neg_rank)==1);
                id(ii).TN_none = i_neg_rank((y(i_neg_rank)==-1)&digestIndex(i_neg_rank)==0); 
            end
        else
            id(ii).FN = []; id(ii).TN = [];
            id(ii).FN_full =[]; id(ii).FN_half = []; id(ii).FN_none = [];
            id(ii).TN_full =[]; id(ii).TN_half =[]; id(ii).TN_none = [];
        end
        varargout{1} = id;
           % assign num(ii)    
        for k=1:length(fieldname_num)
            fieldName = fieldname_num{k};
            num(ii).(fieldName) = length(id(ii).(fieldName));
        end 
    else % nargour<=2
         % calculate the field values of NUM
         num(ii).TP = nnz(y(i_pos_rank)==1);
         num(ii).FP = nnz(y(i_pos_rank)==-1);   
         num(ii).FN = nnz(y(i_neg_rank)==1);
         num(ii).TN = nnz(y(i_neg_rank)==-1);
    end
      
    % assign acc(ii)
    acc(ii).FDR = COEF_FDR* num(ii).FP/(num(ii).FP + num(ii).TP);
    acc(ii).TPR = num(ii).TP/(num(ii).TP + num(ii).FN);
    acc(ii).FPR = num(ii).FP/(num(ii).FP + num(ii).TN);
    if flag_index 
        if p>0
            acc(ii).score = indexRank_sort(p);
        end
    end
end

end % end function accuracyIndex_0()
