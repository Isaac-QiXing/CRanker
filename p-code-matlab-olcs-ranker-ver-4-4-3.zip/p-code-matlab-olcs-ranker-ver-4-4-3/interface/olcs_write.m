function resultFile = olcs_write(varargin)
% put out the results of C-Ranker to file
% Inputs:
%    varargin{2*i-1}: a string, the parameter name;
%    varargin{2*i}: the parameter value of varargin{2*i-1}; for i=1, 2, ...
%    the optional arguments are as follows:
%       '-fdr': a positive scalar indicating the fdr level;
%       '-v':  0,  2 or 3
%        0: do not print any information to command window;
%        2: put out progress information briefly to command window;
%        3: put out detailed progress information to command window;
%
%   the last inputs are as follows:
%
%   matDataFile: name of file (with extension .mat)  which contains the data
%       of samples;
%   matScoreFile: name of file  (with extension .mat) which contains the calculated
%       scores and trained model;
% Output:
%   resultFile: resultFile name
%
% Operation:
%   The function saves the following contents to a result file:
%  (1) acc: a cell array of structure containing the following items
%    .FDR: false discovery rate: FP/(FP+TP)
%    .TPR: true positive rate:  TP/(TP+FN)
%    .FPR: false positive rate: FP/(FP+TN)
%   where
%   acc(1): on training set;
%   acc(2): on test set (if any);
%   acc(3): on the total set (if test set exist);
%  (2) num: an array of structure containing the items of the numbers of
%  identified PSMs, including
%     .TP : number of true positives
%     .FP : number of false positives
%     .FN : number of false negative
%     .TN : number of true negative
%     .TP_full: number of TP in full-digested
%     .TP_half: number of TP in half-digested
%     .TP_none: number of TP in none-digested
%     .FP_full: number of FP in full-digested
%     .FP_half: number of FP in half-digested
%     .FP_none: number of FP in none-digested
%        and similarly for
%     .FN_full
%     .FN_half
%     .FN_none
%     .TN_full
%     .TN_half
%     .TN_none
%   num(1): on train set;
%   num(2): on test set (if any);
%   num(3): the total (if test set exist);
%  (3) records of identified PSMs
%
% version.
%  2018.9.10: revise the implementation to put out PSMs to text files


% get arguments
[par_new,varargin_par] = identifyPar(varargin{:});

arg = struct();
len_arg = length(par_new);
if len_arg>0
    arg = assignStruct('', par_new(1:2:len_arg),par_new(2:2:len_arg));
end

% get  matDataFile and matScoreFile
if length(varargin_par)<2
    error('There should be 2 inputs variables:  matDataFile and matScoreFile.');
end
matDataFile = varargin_par{1};
matScoreFile = varargin_par{2};

% get arguments
[fdr, ...
    feature_name_psm_id, feature_name_psm_score,feature_name_label, ...
    feature_name_digest_type,path_cranker_data,verbose,threshold_tolFP,tolFP,ratio_discount,allowZeroFDR,save_result_text]...
    = problemArg('fdr',...
    'feature_name_psm_id','feature_name_psm_score','feature_name_label',...
    'feature_name_digest_type','path_cranker_data','verbose','threshold_tolFP','tolFP','ratio_discount','allowZeroFDR','save_result_text' );

%%%arg = completeArg(arg, {'fdr','flag_save_mat','flag_save_txt','verbose'},{fdr,1,1,verbose});
arg = completeArg(arg, {'fdr','flag_save_mat','flag_save_txt','verbose'},{fdr,1,save_result_text,verbose});

% check whether matDataFile and matScoreFile exist
%   If the specified filename contains directory, search the file at the
%       specified directory;
%   Otherwise search the file at path_cranker_data
arg.ext = '.mat';
[ind_data,fileName_data ] = searchFile(matDataFile,{path_cranker_data},arg);
[ind_score,fileName_score ] = searchFile(matScoreFile,{path_cranker_data},arg);
if ind_data==-1
    error('Do not find the data file: %s\n',matDataFile);
else
    matDataFile = fileName_data;
end
if ind_score==-1
    error('Do not find the result file: %s\n',matScoreFile);
else
    matScoreFile = fileName_score;
end

load(matScoreFile,'score_train','score_test','ind_test','ind_train');
flag_split = ~isempty(score_test) && ~isempty(ind_test);
% whether it is splitted to train set and test set

% assign the name of resultFile
[pathstr_dataFile, name] = fileparts(matDataFile);
pathstr = pathstr_dataFile; % the same directory as the data file


%%%fileName = [name '_result_' datestr(date)];
fileName = [name '_result_' datestr(now,30)];
resultFile = '';
if arg.flag_save_txt
    resultFile = [addFileSep(pathstr) fileName '.txt'];
else
    resultFile = [addFileSep(pathstr) fileName '.mat'];
end
if arg.flag_save_mat
    resultFile_mat =  [addFileSep(pathstr) fileName '.mat'];
end

% load results
load(matDataFile,'data','text');
digestIndex = data.(feature_name_digest_type);

% calculate the accuracy on 1) train set 2) test set 3) whole set;
num_sub_model = size(score_train,2); % number of sub-models
% % % argIndex = struct('fdr', arg.fdr);
argIndex = struct('fdr', arg.fdr,'tolFP',0,'ratio_discount',0, 'allowZeroFDR',allowZeroFDR);
argIndex_adjust =  struct('fdr', arg.fdr,'tolFP',tolFP,'ratio_discount',ratio_discount, 'allowZeroFDR',allowZeroFDR);
% initialization
if flag_split
    acc = cell(1,3);
    num = cell(1,3);
    id = cell(1,3);
else
    acc = cell(1);
    num = cell(1);
    id = cell(1);
end

% 1) on train set
for kk=1:num_sub_model
    [acc{1}(kk),num{1}(kk),id{1}(kk)] = accuracyIndex(score_train(:,kk),...
        data.output(ind_train), digestIndex(ind_train),argIndex);
    if num{1}(kk).FP < threshold_tolFP
        [acc{1}(kk),num{1}(kk),id{1}(kk)] = accuracyIndex(score_train(:,kk),...
            data.output(ind_train), digestIndex(ind_train),argIndex_adjust); % calculate the accuracy again to allow tolFP>0
    end
end
% update id{1}
field_item_v = fieldnames(id{1});
for ii=1:length(id{1})
    for k = 1:length(field_item_v)
        id{1}(ii).(field_item_v{k}) = ind_train(id{1}(ii).(field_item_v{k}));
    end
end

if flag_split
    % 2) on test set
    for kk=1:num_sub_model
        [acc{2}(kk),num{2}(kk),id{2}(kk)] = accuracyIndex(score_test(:,kk),...
            data.output(ind_test),digestIndex(ind_test),argIndex);
        if num{2}(kk).FP < threshold_tolFP % calculate the accuracy again to allow tolFP>0
            [acc{2}(kk),num{2}(kk),id{2}(kk)] = accuracyIndex(score_test(:,kk),...
                data.output(ind_test),digestIndex(ind_test),argIndex_adjust);
        end
    end
    % update id{2}
    for ii=1:length(id{2})
        for k = 1:length(field_item_v)
            id{2}(ii).(field_item_v{k}) = ind_test(id{2}(ii).(field_item_v{k}));
        end
    end
    % 3) on the whole set
    [acc{3},num{3},id{3}] = accuracyMerge(num{1},num{2},id{1},id{2});
end
% the scores on whole set
score_whole = zeros(length(data.output),num_sub_model);
score_whole(ind_train,:) = score_train;
if flag_split
    score_whole(ind_test,:) = score_test;
end

% construct the information of identified PSMs
if flag_split
    id_act_set = 3; % indicate the whole set
else
    id_act_set = 1; % indicate the train set
end
id_ave_score = 1; %  acc{id_act_set}(id_ave_score) stores the average (last) scores

feature_string = columnVec(fieldnames(text))';
feature_numeric_model = columnVec(data.input_feature)'; % ensure a row array
feature_P_cell = [{feature_name_psm_id,feature_name_psm_score}...
    feature_string feature_numeric_model...
    {feature_name_label}];
% the feature names of columns of the cell matrix P_cell:

% ind_P = [columnVec(id{id_act_set}(id_ave_score).TP); ...
%     columnVec(id{id_act_set}(id_ave_score).FP)];
% len_catch_sample = length(ind_P); % number of identified PSMs
% % sort the PSMs with descending scores
% [temp,ind_ind_P] = sort(score_whole(ind_P,id_ave_score),'descend');
% ind_P = ind_P(ind_ind_P);
% clear('temp','ind_ind_P');


 

% sort the PSMs with descending scores
[~, ind_P] = sort(score_whole(:,id_ave_score),'descend');
len_catch_sample = length(score_whole);  



% assign the values of features of string value
len_feature_string = length(feature_string);
P_cell_string = cell(len_catch_sample,len_feature_string);

for ii=1:len_feature_string
    name_s = feature_string{ii};
    if length(text.(name_s)) >= len_catch_sample % the feature has values
        P_cell_string(:,ii) = text.(name_s)(ind_P);
    else % the feature is not set strings
        P_cell_string(:,ii) = {''};  % assign empty strings '' to P_cell_string
    end
end
clear('text');

% save and print out the results
if arg.flag_save_mat
    time_stamp = datestr(now);
    save(resultFile_mat, 'acc','num','id','ind_train','ind_test',...
        'score_train','score_test','score_whole',...
        'matDataFile', 'matScoreFile', 'argIndex','time_stamp');
end
clear('id','ind_train','ind_test','score_train','score_test');


if flag_split
    hintStr = 'with num{1} the numbers of identified PSMs on train set';
    hintStr= [hintStr ', num{2} the numbers of identified PSMs on test set'  ];
    hintStr= [hintStr ', num{3} the numbers of identified PSMs on total set.'  ];
else
    hintStr = 'with NUM the numbers of identified PSMs on train set.';
end


if arg.flag_save_txt
    % put out results to txt file
    if arg.verbose>=1
        fprintf(1,'Identified PSM records have been saved to %s  %s\n',resultFile,hintStr);
    end
    
    fid = fopen(resultFile,'w+');
    fwritef(fid,'',datestr(now),'');
    fwritef(fid,'num',num,'%d\t','accuracy',acc,'');
    % put out the information of identified PSMs
%     %  1) put out the title line
%     fwritef(fid,'','\n\n------------- Identified PSMs ------------\n\n','');
%     pos = fwritef(fid,'',feature_P_cell,'c%s\t');
%     %  2) put out the IDs, scores, string features values, numeric values, and
%     %     the labels
%     fwritef(fid,'',ind_P,'%8d\t', '',score_whole(ind_P,id_ave_score),{'%8.3f\t+',pos},...
%         '',P_cell_string,{'c%s\t+',pos}, ...
%         '',data.input(ind_P,:),{'+',pos},  '',data.output(ind_P),{'%d\t+',pos});

        %  1) put out the title line 
    pos = fwritef(fid,'',feature_P_cell,'c%s\t');
    %  2) put out the IDs, scores, string features values, numeric values, and
    %     the labels  
    fmt_string = repmat('%s\t', 1, len_feature_string);
    fmt_data_input = repmat('%8.3f\t', 1, size(data.input,2));
    for ii=1:len_catch_sample
        k = ind_P(ii);
        fprintf(fid, ['%8d\t%8.3f\t' fmt_string fmt_data_input '%d\n'],k,score_whole(k,id_ave_score),P_cell_string{ii,:},...
            data.input(k,:),data.output(k));
        %  the order of P_cell_string has been set
    end    
    fclose(fid);
else % do not put out the results to text files
    if arg.verbose>=1
        fprintf(1,'Identification results have been saved to %s  %s\n',resultFile_mat,hintStr);
    end
end
if arg.verbose>=1
    fprintf('Identified TP  | FP  |:  %d |\t %d |\n',num{id_act_set}(id_ave_score).TP,   num{id_act_set}(id_ave_score).FP)
    if flag_split
        fprintf('TP (test set) | FP (test set)|: %d |\t %d |\n',num{2}(id_ave_score).TP,   num{2}(id_ave_score).FP);
    end
end