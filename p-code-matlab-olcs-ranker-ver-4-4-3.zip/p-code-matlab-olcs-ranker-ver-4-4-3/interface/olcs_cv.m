function [result_opt,par_opt] = olcs_cv(varargin)
% Inputs:
%    varargin{2*i-1}: a string, the parameter name;
%    varargin{2*i}: the parameter value of varargin{2*i-1}; for i=1, 2, ...
%    the optional arguments are as follows:
%       '-k': value of k for k-fold cross validation, default 5;
%       '-z': a positive integer,  maximum number of samples used for cross validation, default 5000;
%       '-v':  0, 1
%        0: do not print any information to command window;
%        1: put out progress information briefly to command window;
%
%
%   The last one or two or three inputs
%  matTrainFile: mat train file name
%  par_search: a struct indicating the parameters to determine the numerical values by   cross validation
%      set [] to use the following default value;
%    par_search = struct( 'cdecoy',[  2^(-2) 2^(-1) 1  2^1  2^2   2^4 ],...
%        'ctarget_cdecoy_ratio', [0.1 0.2 0.5 0.75  1],...        % ratios of ctarget to  cdecoy
%        'r1',[2^(-2) 2^(-1) 1  2^1  2^2   2^4  2^6]);
%    Supported fields of par_search for cross validation:
%        'cdecoy':     weight of empirical loss of the decoys
%        'ctarget_cdecoy_ratio':  ratio of ctarget to cdecoy
%        'lambda_ctarget_ratio':  ratio of lambda to ctarget
%        'kernelType', kernel name, eg.  'rbf', 'linear', default value  'rbf'
%          'r1',   	   kernel parameter;
%  bestResult: a function handle to find the best result with format
%           i_opt = bestResult(result_st)
%        with result_st a struct array with four fields .TP, .FP, .TN, .FN.
%           i_opt: an index of result_st indicating the best result
%
% usage 1.
%    olcs_cv(matTrainFile);
%
% usage 2.
%    par_search = struct( 'cdecoy',[  2^(-2) 2^(-1) 1  2^1  2^2   2^4 ],...
%        'ctarget_cdecoy_ratio', [0.1 0.2 0.5 0.75  1],...        % ratios of ctarget to  cdecoy
%        'r1',[2^(-2) 2^(-1) 1  2^1  2^2   2^4  2^6]);
%    olcs_cv(matTrainFile,par_search);
%
% usage 3.
%
%    olcs_cv(matTrainFile,par_search,@findBestResult);
%
% Outputs:
%   result_opt: the optimal reach result on validation sets
%   par_opt: a struct indicating the parameter values with optimal accuracy
% version:
%   2019.12.11 donot conduct the second round cross validation
%   2018.11.1 Fix a bug to support 'kernelType' setting
%   2018.9.11 Add the second-phrase k-fold cross validation

% 0.0 default parameter values
[fold_k,maxTrainSize_cv, num_test_r1_2nd_round, verbose,cdecoy,ctarget,kernelType,r1,svm_theta_solver] = ...
    problemArg('fold_k','maxTrainSize_cv', 'num_test_r1_2nd_round', 'verbose','cdecoy','ctarget','kernelType','r1','svm_theta_solver');

% 0.1 get arguments
[par_new,varargin_par ] = identifyPar(varargin{:});

arg = struct();
len_arg = length(par_new);
if len_arg>0
    arg = assignStruct('', par_new(1:2:len_arg),par_new(2:2:len_arg));
end

% get  Inputs
if isempty(varargin_par)
    error('There should be at least one input:  matDataFile.');
end
if length(varargin_par)>=1
    matTrainFile = varargin_par{1};
end
if length(varargin_par)>=2
    par_search = varargin_par{2};
else
    par_search = struct( 'cdecoy',[  2^(-2) 2^(-1) 1  2^1  2^2   2^4 ],...
        'ctarget_cdecoy_ratio', [0.1 0.2 0.5 0.75  1],...        % ratios of ctarget to  cdecoy
        'lambda_ctarget_ratio', 2.0,...
        'r1',[2^(-2) 2^(-1) 1  2^1  2^2   2^4  2^6]);
end
par_search = completeArg(par_search,{'cdecoy','r1'},{cdecoy,r1});

h_bestResult = [];
if length(varargin_par)>=3
    h_bestResult = varargin_par{3};
end

if ~isa(h_bestResult, 'function_handle')&& length(varargin_par)>=3
    warning('The specified 3rd Input should be a function .');
end

if ~isa(h_bestResult, 'function_handle')
    h_bestResult = @findBestResult;
end

arg = completeArg(arg, ...
    {'fold_k','maxTrainSize_cv','verbose'},...
    {fold_k,maxTrainSize_cv,verbose});

lambda = 2*ctarget;

% set kernelType 
if  isfield(par_search,'kernelType') && ~isempty(par_search.kernelType)
    kernelType = par_search.kernelType;
end

par_alg = ... % parameters for each dataset
    struct('cdecoy',  cdecoy, ...
    'ctarget', ctarget,...
    'lambda',    lambda,...
    'kernelType', kernelType,... % 'linear';%
    'r1',   r1,...
    'svm_theta_solver',  svm_theta_solver);


% construct the parmeter struct for cross validation
if ~isfield(par_search,'lambda_ctarget_ratio')
    par_search.lambda_ctarget_ratio = 2.0;
end
if ~isfield(par_search,'ctarget_cdecoy_ratio')
    par_search.ctarget_cdecoy_ratio = 0.5;
end

% 1st rough grid-search
h = @(x) max(length(x),1);
n_parVal_v = structfun(h, par_search);
n_parVal_total = prod(n_parVal_v);

ratio_base = [0 1 0 2];
% ratio_base(4)==2: the 4-th field (lambda) is setting based on the ratio to 2nd field (ctarget)
par1_search = struct( 'cdecoy',par_search.cdecoy,...
    'ctarget', par_search.ctarget_cdecoy_ratio,...        % ratios of ctarget to  cdecoy
    'r1', par_search.r1,...
    'lambda', par_search.lambda_ctarget_ratio,...
    'ratio_base',ratio_base); %,...
    %'kernelType',par_search.kernelType);
alg = @cranker_predict;


% % %[result_opt,par_opt]= crossValidate(alg,matTrainFile, par_alg, par1_search,...
% % %        'k',arg.fold_k,'n',arg.maxTrainSize_cv,'bestResult',h_bestResult,'par_second_round','r1');

[result_opt,par_opt]= crossValidate(alg,matTrainFile, par_alg, par1_search,...
        'k',arg.fold_k,'n',arg.maxTrainSize_cv,'bestResult',h_bestResult);
end


