% demo2_cranker.m
% A demo to call 
%       olcs_read, olcs_solve and olcs_write
% and illustrate parameter settings

clear
 
 rawFileName = 'yeast.xlsx';  % data file containing records of PSMs
%fileName = 'ups1.xlsx';  
 

matDataFile = 'myPSMdata.mat'; % Mat file name to store PSM records
matScoreFile = 'myPSMscore.mat'; % Mat file name to store the scores of identified PSMs

% 1. read PSM records
olcs_read(rawFileName,matDataFile); 
 
% 2. identify reliable target PSMs
% * users can also set 'flag_split_train_test' by '-f' parameter 
% e.g. Identify PSMs with 'flag_split_train_test==0' as follows
% olcs_solve('-f','0',matDataFile,matScoreFile); %-f: whether split train and test     
%
% * users can also set 'train_test_rate' by '-t' parameter 
% e.g. Identify PSMs with cdecoy=4.8, ctarget=2.4, lambda=2.4, flag_split_train_test==1, train_test_rate==2 as follows
 olcs_solve('-cdecoy','4.8', '-ctarget','2.4', '-lambda','2.4', '-f','1','-t','2',matDataFile,matScoreFile); %-t: train/test rate,
 
% 3. put out identified PSM records 
 resultFile = olcs_write(matDataFile,matScoreFile);
  
 
