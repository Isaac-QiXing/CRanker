import matlab.engine
eng = matlab.engine.start_matlab()

rawFileName = 'yeast.xlsx'
matDataFile = 'myPSMdata.mat'
matScoreFile = 'myPSMscore.mat'

eng.olcs_read(rawFileName,matDataFile,nargout=0)
eng.olcs_solve('-cdecoy','4.8', '-ctarget','2.4', '-lambda','2.4', '-f','1','-t','2',matDataFile,matScoreFile,nargout=0)

resultFile = olcs_write(matDataFile,matScoreFile,nargout=0)

eng.quit()