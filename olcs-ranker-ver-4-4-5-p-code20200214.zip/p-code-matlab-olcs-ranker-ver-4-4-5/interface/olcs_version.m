function ver = olcs_version(varargin)
% get the C-Ranker version
% Inputs:
%  arg: '': return the version;
%       '-date': return the release date of the C-Ranker software
% Outputs: 
%   version

ver = '4.4.5';
if nargin>0
    % print the publication date 
	arg = varargin{1};
    if strcmpi(arg,'-date')
        ver = 'Feb 13, 2020';        
    end
end
%fprintf(1,'%s',ver);

end
