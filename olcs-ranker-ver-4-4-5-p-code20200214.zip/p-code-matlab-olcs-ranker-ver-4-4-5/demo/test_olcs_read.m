% demo_cranker.m
% A demo to call
%       olcs_read, olcs_solve and olcs_write

clear

fileID = 9;
dataPath = ['C:\Users\Xijun-Wolfe\Desktop\PSM-Test-Data\'];
switch fileID
    case 1
        rawFileName = 'yeast.xlsx';  % data file containing records of PSMs
    case 2        
        rawFileName = 'ups1.xlsx';
    case 3        
        rawFileName = 'tal08.xlsx';
    case 4
        rawFileName = 'tal08_large.xlsx';
    case 5
        %         rawFileName = 'yeast-demo.xlsx';
        rawFileName = 'yeast-demo.txt';
    case 6
        rawFileName = 'yeast_test.xls';
    case 7
        rawFileName = 'pfu-tide-2.txt';        
    case 8
        rawFileName = 'pfu-comet-label.xlsx';
    case 9        
        rawFileName = 'pfu-comet-2.txt';
end

rawFileName = [dataPath, rawFileName];
matDataFile = 'myPSMdata.mat'; % Mat file name to store PSM records
matScoreFile = 'myPSMscore.mat'; % Mat file name to store the scores of identified PSMs


% 1. read PSM records
olcs_read(rawFileName,matDataFile);

% 2. identify reliable target PSMs
%olcs_solve(matDataFile,matScoreFile);

% 3. put out identified PSM records
%resultFile = olcs_write(matDataFile,matScoreFile);



